﻿-- EffectLua01
-- Author: Bottlep
-- DateCreated: 2/9/2021 11:36:08 PM
--------------------------------------------------------------

--
--function Citynameset01(iPlayerID,iCityID,PlotX,PlotY)
--
	--if (PlotX==64 and PlotY==27) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANJING'))
    --end
--
	--if (PlotX==47 and PlotY==34) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANYANG'))
    --end
--
	--if (PlotX==60 and PlotY==47) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEIJING'))
    --end
--
	--if (PlotX==76 and PlotY==41) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEOUL'))
    --end
--
	--if (PlotX==64 and PlotY==27) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANJING'))
    --end
--
	--if (PlotX==55 and PlotY==11) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGZHOU'))
    --end
--
	--if (PlotX==98 and PlotY==36) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKYO'))
    --end
--
	--if (PlotX==92 and PlotY==34) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYOTO'))
    --end
--
	--if (PlotX==55 and PlotY==18) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGSHA'))
    --end
--
	--if (PlotX==42 and PlotY==6) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANOI'))
    --end
--
--
	--if (PlotX==2 and PlotY==19) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELHI'))
    --end
	--if (PlotX==7 and PlotY==56) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ILI'))
    --end
--
	--if (PlotX==53 and PlotY==28) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGYANG'))
    --end
--
	--if (PlotX==44 and PlotY==31) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANZHONG'))
    --end
	--if (PlotX==39 and PlotY==24) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGDU'))
    --end
	--if (PlotX==43 and PlotY==22) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGQING'))
    --end
--
	--if (PlotX==68 and PlotY==25) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGHAI'))
    --end
--
	--if (PlotX==66 and PlotY==23) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGZHOU'))
    --end
--
	--if (PlotX==54 and PlotY==16) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HENGYANG'))
    --end
--
	--if (PlotX==57 and PlotY==23) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUCHANG'))
    --end
	--if (PlotX==56 and PlotY==25) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANKOU'))
    --end
	--if (PlotX==55 and PlotY==23) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANYANG'))
    --end
--
	--if (PlotX==57 and PlotY==39) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANDAN'))
    --end
--
	--if (PlotX==68 and PlotY==45) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALIAN'))
    --end
	--if (PlotX==71 and PlotY==52) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENYANG'))
    --end
	--if (PlotX==74 and PlotY==57) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGCHUN'))
    --end
	--if (PlotX==76 and PlotY==61) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HARBIN'))
    --end
	--if (PlotX==48 and PlotY==34) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAN'))
    --end
--
	--if (PlotX==53 and PlotY==23) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGZHOU'))
    --end
--
	--if (PlotX==63 and PlotY==13) then
        --local pCity=CityManager.GetCityAt(PlotX,PlotY)
		--pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAMEN'))
    --end
--


function Citynameset02(iPlayerID,iCityID,PlotX,PlotY)

if (PlotX==70 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIPEI'))
    end
if (PlotX==69 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAOYUAN'))
    end
if (PlotX==68 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HSINCHU'))
    end
if (PlotX==68 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAICHUNG'))
    end
if (PlotX==67 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIAYI'))
    end
if (PlotX==67 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAINAN'))
    end
if (PlotX==67 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAOHSIUNG'))
    end
if (PlotX==68 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HENGCHUN'))
    end
if (PlotX==69 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_TAIPEI'))
    end
if (PlotX==70 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YILAN_TAIWAN'))
    end
if (PlotX==69 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUALIEN'))
    end
if (PlotX==69 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUADONG_VALLEY'))
    end
if (PlotX==68 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAITUNG'))
    end
if (PlotX==68 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANTOU'))
    end
if (PlotX==68 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOUNT_YU'))
    end
if (PlotX==69 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOUNT_SYLVIA'))
    end
if (PlotX==65 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PENGHU'))
    end
if (PlotX==61 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PRATAS_ISLAND'))
    end
if (PlotX==72 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DIAOYU_ISLAND'))
    end
if (PlotX==51 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIKOU'))
    end
if (PlotX==50 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANYA'))
    end
if (PlotX==50 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANZHOU'))
    end
if (PlotX==51 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIONGZHONG'))
    end
if (PlotX==52 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENCHANG'))
    end
if (PlotX==52 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIONGHAI'))
    end
if (PlotX==52 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WANNING'))
    end
if (PlotX==51 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGSHUI'))
    end
if (PlotX==49 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LEDONG'))
    end
if (PlotX==49 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGFANG'))
    end
if (PlotX==49 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGPU'))
    end
if (PlotX==50 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGAO'))
    end
if (PlotX==51 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINGAN'))
    end
if (PlotX==50 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUZHISHAN'))
    end
if (PlotX==68 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VIGAN'))
    end
if (PlotX==69 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KABUGAO'))
    end
if (PlotX==70 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUGUEGARAO'))
    end
if (PlotX==68 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAOAG'))
    end
if (PlotX==69 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_APARRI'))
    end
if (PlotX==70 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANTA_ANA'))
    end
if (PlotX==69 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BABUYAN_ISLANDS'))
    end
if (PlotX==98 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKYO'))
    end
if (PlotX==97 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YOKOHAMA'))
    end
if (PlotX==97 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAKONE'))
    end
if (PlotX==97 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IZU'))
    end
if (PlotX==96 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGANO'))
    end
if (PlotX==96 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JOETSU'))
    end
if (PlotX==97 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGAMIHARA'))
    end
if (PlotX==99 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIBA'))
    end
if (PlotX==100 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOSHI'))
    end
if (PlotX==99 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUJUKURI'))
    end
if (PlotX==99 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINAMIBOSO'))
    end
if (PlotX==97 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAITAMA'))
    end
if (PlotX==97 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAKASAKI'))
    end
if (PlotX==96 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHICHIBU'))
    end
if (PlotX==97 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIIGATA'))
    end
if (PlotX==97 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGAOKA'))
    end
if (PlotX==96 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SADO'))
    end
if (PlotX==100 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SENDAI'))
    end
if (PlotX==99 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUKUSHIMA'))
    end
if (PlotX==100 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IWAKI'))
    end
if (PlotX==99 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTSUNOMIYA'))
    end
if (PlotX==98 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSUKUBA'))
    end
if (PlotX==100 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MITO'))
    end
if (PlotX==99 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HITACHI'))
    end
if (PlotX==99 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KASHIMA'))
    end
if (PlotX==101 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ISHINOMAKI'))
    end
if (PlotX==99 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORIYAMA'))
    end
if (PlotX==98 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NASUSHIOBARA'))
    end
if (PlotX==96 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOUNT_FUJI'))
    end
if (PlotX==96 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAMANASHI'))
    end
if (PlotX==98 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIKKO'))
    end
if (PlotX==98 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AIZUWAKAMATSU'))
    end
if (PlotX==97 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TADAMI'))
    end
if (PlotX==98 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONEZAWA'))
    end
if (PlotX==99 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAMAGATA'))
    end
if (PlotX==98 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MURAKAMI'))
    end
if (PlotX==98 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSURUOKA'))
    end
if (PlotX==99 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAKATA'))
    end
if (PlotX==99 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINJO'))
    end
if (PlotX==101 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORIOKA'))
    end
if (PlotX==99 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKITA'))
    end
if (PlotX==102 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIYAKO'))
    end
if (PlotX==102 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HACHINOHE'))
    end
if (PlotX==100 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AOMORI'))
    end
if (PlotX==99 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HIROSAKI'))
    end
if (PlotX==99 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOSHIRO'))
    end
if (PlotX==99 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YURIHONJO'))
    end
if (PlotX==100 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEMBOKU'))
    end
if (PlotX==100 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OSAKI'))
    end
if (PlotX==101 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ICHINOSEKI'))
    end
if (PlotX==100 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KITAKAMI'))
    end
if (PlotX==101 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAMAISHI'))
    end
if (PlotX==100 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUZAWA'))
    end
if (PlotX==101 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINOHE'))
    end
if (PlotX==100 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HACHIMANTAI'))
    end
if (PlotX==101 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOWADA'))
    end
if (PlotX==99 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IMABETSU'))
    end
if (PlotX==101 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAKE_OGAWARA'))
    end
if (PlotX==101 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUTSU'))
    end
if (PlotX==91 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OSAKA'))
    end
if (PlotX==92 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYOTO'))
    end
if (PlotX==92 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NARA'))
    end
if (PlotX==91 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WAKAYAMA'))
    end
if (PlotX==92 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUSHIMOTO'))
    end
if (PlotX==92 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUMANO'))
    end
if (PlotX==93 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ISE'))
    end
if (PlotX==93 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YOKKAICHI'))
    end
if (PlotX==92 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSU'))
    end
if (PlotX==94 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGOYA'))
    end
if (PlotX==93 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGAHAMA'))
    end
if (PlotX==94 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GIFU'))
    end
if (PlotX==96 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIZUOKA'))
    end
if (PlotX==95 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMAMATSU'))
    end
if (PlotX==94 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOYOHASHI'))
    end
if (PlotX==95 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAKUMA'))
    end
if (PlotX==95 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOFU'))
    end
if (PlotX==95 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUWA'))
    end
if (PlotX==95 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATSUMOTO'))
    end
if (PlotX==95 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ITOIGAWA'))
    end
if (PlotX==95 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOYAMA'))
    end
if (PlotX==94 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAKAOKA'))
    end
if (PlotX==93 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANAZAWA'))
    end
if (PlotX==93 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUKUI'))
    end
if (PlotX==94 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HIDA'))
    end
if (PlotX==94 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IBIGAWA'))
    end
if (PlotX==93 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANAO'))
    end
if (PlotX==94 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOTO'))
    end
if (PlotX==93 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSURUGA'))
    end
if (PlotX==90 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOBE'))
    end
if (PlotX==90 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HIMEJI'))
    end
if (PlotX==89 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OKAYAMA'))
    end
if (PlotX==88 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KURASHIKI'))
    end
if (PlotX==87 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUKUYAMA'))
    end
if (PlotX==86 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HIROSHIMA'))
    end
if (PlotX==86 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANAI'))
    end
if (PlotX==85 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UBE'))
    end
if (PlotX==84 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIMONOSEKI'))
    end
if (PlotX==85 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAMAGUCHI'))
    end
if (PlotX==85 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGATO'))
    end
if (PlotX==86 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MASUDA'))
    end
if (PlotX==86 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOTSU'))
    end
if (PlotX==87 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIYOSHI'))
    end
if (PlotX==87 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IZUMO'))
    end
if (PlotX==88 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIIMI'))
    end
if (PlotX==88 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATSUE'))
    end
if (PlotX==89 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONAGO'))
    end
if (PlotX==89 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSUYAMA'))
    end
if (PlotX==90 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOTTORI'))
    end
if (PlotX==90 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOYOOKA'))
    end
if (PlotX==91 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAIZURU'))
    end
if (PlotX==92 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WAKASA'))
    end
if (PlotX==91 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANTAN'))
    end
if (PlotX==87 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NISHINOSHIMA'))
    end
if (PlotX==88 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OKINOSHIMA'))
    end
if (PlotX==83 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUKUOKA'))
    end
if (PlotX==83 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KITAKYUSHU'))
    end
if (PlotX==82 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGASAKI'))
    end
if (PlotX==81 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSUSHIMA1'))
    end
if (PlotX==82 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSUSHIMA2'))
    end
if (PlotX==83 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGA'))
    end
if (PlotX==83 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YATSUSHIRO'))
    end
if (PlotX==84 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUMAMOTO'))
    end
if (PlotX==83 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAGOSHIMA'))
    end
if (PlotX==83 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SATSUMASENDAI'))
    end
if (PlotX==84 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIYAKONOJO'))
    end
if (PlotX==84 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KIRISHIMA'))
    end
if (PlotX==84 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ASO'))
    end
if (PlotX==85 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIYAZAKI'))
    end
if (PlotX==85 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OITA'))
    end
if (PlotX==84 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAKATSU'))
    end
if (PlotX==85 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIKI'))
    end
if (PlotX==85 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOBEOKA'))
    end
if (PlotX==84 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HYUGA'))
    end
if (PlotX==83 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAKUSHIMA'))
    end

	if (PlotX==84 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAKUSHIMA'))
    end

if (PlotX==89 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAKAMATSU'))
    end
if (PlotX==88 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIKOKUCHUO'))
    end
if (PlotX==87 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATSUYAMA'))
    end
if (PlotX==97 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAWATAHAMA'))
    end
if (PlotX==87 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIMANTO'))
    end
if (PlotX==88 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOCHI'))
    end
if (PlotX==89 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUROTO'))
    end
if (PlotX==89 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKUSHIMA'))
    end
if (PlotX==100 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAPPORO'))
    end
if (PlotX==100 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAKODATE'))
    end
if (PlotX==99 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOKUTO'))
    end
if (PlotX==98 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATSUMAE'))
    end
if (PlotX==98 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAKUMO'))
    end
if (PlotX==99 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAKE_TOYA'))
    end
if (PlotX==98 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTARU'))
    end
if (PlotX==100 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MURORAN'))
    end
if (PlotX==101 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOMAKOMAI'))
    end
if (PlotX==100 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ISHIKARI'))
    end
if (PlotX==101 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAKIKAWA'))
    end
if (PlotX==100 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUMOI'))
    end
if (PlotX==101 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ASAHIKAWA'))
    end
if (PlotX==100 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TESHIO'))
    end
if (PlotX==101 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAYORO'))
    end
if (PlotX==100 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAKE_KUTCHARO'))
    end
if (PlotX==100 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WAKKANAI'))
    end
if (PlotX==101 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUBARI'))
    end
if (PlotX==102 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HIDAKA'))
    end
if (PlotX==102 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERIMO'))
    end
if (PlotX==102 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FURANO'))
    end
if (PlotX==102 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KITAMI'))
    end
if (PlotX==102 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONBETSU'))
    end
if (PlotX==103 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAKASHIBETSU'))
    end
if (PlotX==103 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABASHIRI'))
    end
if (PlotX==104 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIRETOKO'))
    end
if (PlotX==102 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OBIHIRO'))
    end
if (PlotX==103 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKACHI'))
    end
if (PlotX==103 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUSHIRO'))
    end
if (PlotX==104 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEMURO'))
    end
if (PlotX==105 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUNASHIR_ISLAND'))
    end
if (PlotX==97 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OKUSHIRI'))
    end
if (PlotX==79 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAHA'))
    end
if (PlotX==79 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGO'))
    end
if (PlotX==74 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ISHIGAKI'))
    end
if (PlotX==75 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIYAKOJIMA'))
    end
if (PlotX==82 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMAMI'))
    end
if (PlotX==80 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKUNOSHIMA'))
    end
if (PlotX==84 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAITO_ISLANDS'))
    end
if (PlotX==98 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HACHIJO_JIMA'))
    end
if (PlotX==102 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHICHIJIMA'))
    end
if (PlotX==102 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAHAJIMA'))
    end
if (PlotX==101 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IWO_JIMA'))
    end
if (PlotX==104 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AGRIHAN_ISLAND'))
    end
if (PlotX==104 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAGAN_ISLAND'))
    end
if (PlotX==101 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUZHNO_SAKHALINSK'))
    end
if (PlotX==101 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORSAKOV'))
    end
if (PlotX==100 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANIVA'))
    end
if (PlotX==101 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DOLINSK'))
    end
if (PlotX==100 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOLMSK'))
    end
if (PlotX==100 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHEKHOV'))
    end
if (PlotX==100 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GORNOZAVODSK'))
    end
if (PlotX==102 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOVIKOVO'))
    end
if (PlotX==77 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEOUL'))
    end
if (PlotX==77 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_INCHEON'))
    end
if (PlotX==76 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANGHWA'))
    end
if (PlotX==78 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POCHEON'))
    end
if (PlotX==79 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUNCHEON'))
    end
if (PlotX==79 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SOKCHO'))
    end
if (PlotX==80 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANGNEUNG'))
    end
if (PlotX==78 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGPYEONG'))
    end
if (PlotX==79 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PYEONGCHANG'))
    end
if (PlotX==80 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGHAE'))
    end
if (PlotX==78 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUWON'))
    end
if (PlotX==79 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WONJU'))
    end
if (PlotX==80 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAEBAEK'))
    end
if (PlotX==76 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEOSAN'))
    end
if (PlotX==77 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEJONG'))
    end
if (PlotX==78 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHEONGJU'))
    end
if (PlotX==79 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUNGYEONG'))
    end
if (PlotX==80 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULJIN'))
    end
if (PlotX==77 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BORYEONG'))
    end
if (PlotX==78 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAEJEON'))
    end
if (PlotX==79 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANGJU'))
    end
if (PlotX==80 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANDONG'))
    end
if (PlotX==81 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POHANG'))
    end
if (PlotX==77 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JEONJU'))
    end
if (PlotX==78 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GIMCHEON'))
    end
if (PlotX==79 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAEGU'))
    end
if (PlotX==80 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GYEONGJU'))
    end
if (PlotX==77 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JEONGEUP'))
    end
if (PlotX==78 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAMWON'))
    end
if (PlotX==79 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAPCHEON'))
    end
if (PlotX==80 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIRYANG'))
    end
if (PlotX==81 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULSAN'))
    end
if (PlotX==76 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOKPO'))
    end
if (PlotX==77 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GWANGJU'))
    end
if (PlotX==78 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GWANGYANG'))
    end
if (PlotX==79 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGWON'))
    end
if (PlotX==80 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUSAN'))
    end
if (PlotX==77 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAENAM'))
    end
if (PlotX==78 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOHEUNG'))
    end
if (PlotX==77 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JEJU'))
    end
if (PlotX==78 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HALLASAN'))
    end
if (PlotX==84 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULLEUNG'))
    end
if (PlotX==75 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PYONGYANG'))
    end
if (PlotX==81 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONSONG'))
    end
if (PlotX==81 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOERYONG'))
    end
if (PlotX==82 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYONGHUNG'))
    end
if (PlotX==79 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAMJIYON'))
    end
if (PlotX==80 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAEHONGDAN'))
    end
if (PlotX==81 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PURYONG'))
    end
if (PlotX==82 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAJIN'))
    end
if (PlotX==83 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONBONG'))
    end
if (PlotX==80 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POCHON'))
    end
if (PlotX==81 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONSA'))
    end
if (PlotX==82 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGJIN'))
    end
if (PlotX==77 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUNGGANG'))
    end
if (PlotX==76 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHASONG'))
    end
if (PlotX==77 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KIMHYONGJIK'))
    end
if (PlotX==78 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KIMJONGSUK'))
    end
if (PlotX==79 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HYESAN'))
    end
if (PlotX==80 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAEGAM'))
    end
if (PlotX==81 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYONGSONG'))
    end
if (PlotX==76 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANPHO'))
    end
if (PlotX==77 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HWAPYONG'))
    end
if (PlotX==78 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RANGNIM'))
    end
if (PlotX==79 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUNGSO'))
    end
if (PlotX==80 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAPSAN'))
    end
if (PlotX==81 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KILJU'))
    end
if (PlotX==75 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOSAN'))
    end
if (PlotX==76 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANGGYE'))
    end
if (PlotX==77 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGJIN'))
    end
if (PlotX==78 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUJON'))
    end
if (PlotX==79 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KIMHYONGGWON'))
    end
if (PlotX==80 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KIMCHAEK'))
    end
if (PlotX==81 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HWADAE'))
    end
if (PlotX==74 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAKJU'))
    end
if (PlotX==75 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PYOKTONG'))
    end
if (PlotX==76 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUICHON'))
    end
if (PlotX==77 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAEHUNG'))
    end
if (PlotX==78 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SINHUNG'))
    end
if (PlotX==79 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SINPHO'))
    end
if (PlotX==80 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANCHON'))
    end
if (PlotX==73 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SINUIJU'))
    end
if (PlotX==74 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUSONG'))
    end
if (PlotX==75 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAECHON'))
    end
if (PlotX==76 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKCHON'))
    end
if (PlotX==77 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YODOK'))
    end
if (PlotX==78 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMHUNG'))
    end
if (PlotX==75 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANJU'))
    end
if (PlotX==76 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUNCHON'))
    end
if (PlotX==77 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUDONG'))
    end
if (PlotX==78 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUNCHON'))
    end
if (PlotX==76 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGDOK'))
    end
if (PlotX==77 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WONSAN'))
    end
if (PlotX==75 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAMPO'))
    end
if (PlotX==76 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGNIM'))
    end
if (PlotX==77 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOKSAN'))
    end
if (PlotX==78 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOEYANG'))
    end
if (PlotX==79 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOSONG'))
    end
if (PlotX==74 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGHWA'))
    end
if (PlotX==75 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SARIWON'))
    end
if (PlotX==76 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PYONGSAN'))
    end
if (PlotX==77 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PYONGGANG'))
    end
if (PlotX==78 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUMGANG'))
    end
if (PlotX==75 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONGJIN'))
    end
if (PlotX==76 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAEJU'))
    end
if (PlotX==77 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAESONG'))
    end
if (PlotX==68 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGHAI'))
    end
if (PlotX==68 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGMING'))
    end
if (PlotX==69 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGTAN'))
    end
if (PlotX==68 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINSHAN'))
    end
if (PlotX==64 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANJING'))
    end
if (PlotX==65 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIXING'))
    end
if (PlotX==67 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUZHOU'))
    end
if (PlotX==65 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIYANG'))
    end
if (PlotX==66 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGZHOU'))
    end
if (PlotX==67 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUXI'))
    end
if (PlotX==65 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENJIANG'))
    end
if (PlotX==67 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGJIANG'))
    end
if (PlotX==68 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANTONG'))
    end
if (PlotX==69 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIDONG'))
    end
if (PlotX==64 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIZHENG'))
    end
if (PlotX==65 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGZHOU'))
    end
if (PlotX==66 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIZHOU_JIANGSU'))
    end
if (PlotX==67 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIAN'))
    end
if (PlotX==64 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUYI'))
    end
if (PlotX==67 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGHUA'))
    end
if (PlotX==68 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGTAI'))
    end
if (PlotX==65 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINHU'))
    end
if (PlotX==66 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANHU'))
    end
if (PlotX==67 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANCHENG'))
    end
if (PlotX==63 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUQIAN'))
    end
if (PlotX==64 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAIAN'))
    end
if (PlotX==67 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHEYANG'))
    end
if (PlotX==62 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUZHOU'))
    end
if (PlotX==63 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUYANG'))
    end
if (PlotX==64 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANSHUI'))
    end
if (PlotX==65 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANNAN'))
    end
if (PlotX==61 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PEIXIAN'))
    end
if (PlotX==64 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYI_JIANGSU'))
    end
if (PlotX==65 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANYUN'))
    end
if (PlotX==66 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGSHUI'))
    end
if (PlotX==67 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BINHAI'))
    end
if (PlotX==65 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANYUNGANG'))
    end
if (PlotX==66 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGZHOU'))
    end
if (PlotX==67 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CANGNAN'))
    end
if (PlotX==65 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGQUAN'))
    end
if (PlotX==66 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENCHENG'))
    end
if (PlotX==67 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENZHOU'))
    end
if (PlotX==65 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUICHANG'))
    end
if (PlotX==66 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LISHUI'))
    end
if (PlotX==67 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANJU'))
    end
if (PlotX==68 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIZHOU_ZHEJIANG'))
    end
if (PlotX==64 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUZHOU'))
    end
if (PlotX==65 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINHUA'))
    end
if (PlotX==66 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIWU'))
    end
if (PlotX==67 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENGZHOU'))
    end
if (PlotX==68 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGSHAN'))
    end
if (PlotX==65 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUNAN'))
    end
if (PlotX==66 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGLU'))
    end
if (PlotX==67 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAOXING'))
    end
if (PlotX==68 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGBO'))
    end
if (PlotX==65 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINAN'))
    end
if (PlotX==69 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHOUSHAN'))
    end
if (PlotX==66 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUZHOU'))
    end
if (PlotX==67 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAXING'))
    end
if (PlotX==65 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUZHOU'))
    end
if (PlotX==62 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGPU'))
    end
if (PlotX==63 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGHAI'))
    end
if (PlotX==61 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGDING'))
    end
if (PlotX==62 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGZHOU'))
    end
if (PlotX==63 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAMEN'))
    end
if (PlotX==61 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGHANG'))
    end
if (PlotX==62 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGYAN'))
    end
if (PlotX==63 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANXI'))
    end
if (PlotX==64 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUANZHOU'))
    end
if (PlotX==65 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUTIAN'))
    end
if (PlotX==61 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANZHI_MOUT'))
    end
if (PlotX==62 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGAN'))
    end
if (PlotX==63 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEHUA'))
    end
if (PlotX==64 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINQING'))
    end
if (PlotX==62 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGHUA'))
    end
if (PlotX==63 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANMING'))
    end
if (PlotX==64 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANPING'))
    end
if (PlotX==65 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUTIAN'))
    end
if (PlotX==66 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANJIANG'))
    end
if (PlotX==62 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAINING'))
    end
if (PlotX==63 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUNCHANG'))
    end
if (PlotX==64 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANOU'))
    end
if (PlotX==65 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGDE'))
    end
if (PlotX==63 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAOWU'))
    end
if (PlotX==64 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANPING'))
    end
if (PlotX==65 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGHE'))
    end
if (PlotX==66 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAPU'))
    end
if (PlotX==63 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUYISHAN'))
    end
if (PlotX==64 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUCHENG_FJ'))
    end
if (PlotX==61 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEFEI'))
    end
if (PlotX==63 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIMEN'))
    end
if (PlotX==64 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGSHAN'))
    end
if (PlotX==63 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIZHOU'))
    end
if (PlotX==64 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIXI_COUNTY'))
    end
if (PlotX==61 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUSONG'))
    end
if (PlotX==62 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANQING'))
    end
if (PlotX==64 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGLING'))
    end
if (PlotX==65 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUANCHENG'))
    end
if (PlotX==60 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUEXI'))
    end
if (PlotX==61 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAINING'))
    end
if (PlotX==62 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZONGYANG'))
    end
if (PlotX==64 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUHU'))
    end
if (PlotX==61 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGCHENG'))
    end
if (PlotX==62 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUWEI_ANHUI'))
    end
if (PlotX==64 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAANSHAN'))
    end
if (PlotX==59 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINZHAI'))
    end
if (PlotX==60 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUOSHAN'))
    end
if (PlotX==61 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUJIANG'))
    end
if (PlotX==62 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAOHU'))
    end
if (PlotX==60 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUAN'))
    end
if (PlotX==63 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUANJIAO'))
    end
if (PlotX==59 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUOQIU'))
    end
if (PlotX==60 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAINAN'))
    end
if (PlotX==61 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGFENG'))
    end
if (PlotX==62 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINGYUAN'))
    end
if (PlotX==63 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUZHOU'))
    end
if (PlotX==62 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BENGBU'))
    end
if (PlotX==63 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINGGUANG'))
    end
if (PlotX==65 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANCHANG'))
    end
if (PlotX==59 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYANG'))
    end
if (PlotX==60 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGTAI'))
    end
if (PlotX==59 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIESHOU'))
    end
if (PlotX==60 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUOYANG'))
    end
if (PlotX==61 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MENGCHENG'))
    end
if (PlotX==62 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUZHOU_ANHUI'))
    end
if (PlotX==59 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOZHOU'))
    end
if (PlotX==61 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAIBEI'))
    end
if (PlotX==57 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KONG_KONG'))
    end
if (PlotX==55 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MACAU'))
    end
if (PlotX==55 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGZHOU'))
    end
if (PlotX==51 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUWEN'))
    end
if (PlotX==50 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LEIZHOU'))
    end
if (PlotX==51 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANJIANG'))
    end
if (PlotX==52 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAOMING'))
    end
if (PlotX==53 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGJIANG'))
    end
if (PlotX==54 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAISHAN'))
    end
if (PlotX==51 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYI_GUANGDONG'))
    end
if (PlotX==52 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUNFU'))
    end
if (PlotX==53 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGMEN'))
    end
if (PlotX==54 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGSHAN'))
    end
if (PlotX==52 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUNAN'))
    end
if (PlotX==57 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENZHEN'))
    end
if (PlotX==58 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUIYANG'))
    end
if (PlotX==59 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANWEI'))
    end
if (PlotX==60 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUFENG'))
    end
if (PlotX==61 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAOYANG_GUANGDONG'))
    end
if (PlotX==53 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOQING'))
    end
if (PlotX==54 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FOSHAN'))
    end
if (PlotX==56 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGGUAN'))
    end
if (PlotX==57 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUIZHOU'))
    end
if (PlotX==58 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUIDONG'))
    end
if (PlotX==59 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUHE'))
    end
if (PlotX==60 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIEYANG'))
    end
if (PlotX==61 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANTOU'))
    end
if (PlotX==53 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGKAI'))
    end
if (PlotX==54 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGNING'))
    end
if (PlotX==55 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGYUAN'))
    end
if (PlotX==56 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CONGHUA'))
    end
if (PlotX==57 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOLUO'))
    end
if (PlotX==58 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEYUAN'))
    end
if (PlotX==59 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZIJIN'))
    end
if (PlotX==60 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGSHUN'))
    end
if (PlotX==61 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAOZHOU'))
    end
if (PlotX==53 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAIJI'))
    end
if (PlotX==54 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGSHAN'))
    end
if (PlotX==55 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGDE'))
    end
if (PlotX==56 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUJIANG'))
    end
if (PlotX==57 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANPING'))
    end
if (PlotX==58 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGCHUAN'))
    end
if (PlotX==59 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGNING'))
    end
if (PlotX==60 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEIZHOU'))
    end
if (PlotX==54 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANZHOU'))
    end
if (PlotX==55 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUYUAN'))
    end
if (PlotX==56 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAOGUAN'))
    end
if (PlotX==57 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIHEUNG'))
    end
if (PlotX==56 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RENHUA'))
    end
if (PlotX==57 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANXIONG'))
    end
if (PlotX==85 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VLADIVOSTOK'))
    end
if (PlotX==84 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHASAN'))
    end
if (PlotX==83 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZARUBINO'))
    end
if (PlotX==87 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FOKINO'))
    end
if (PlotX==88 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAKHODKA'))
    end
if (PlotX==84 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SLAVYANKA'))
    end
if (PlotX==85 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NADEZHDINSKOYE'))
    end
if (PlotX==86 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARTYOM'))
    end
if (PlotX==87 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOLSHOY_KAMEN'))
    end
if (PlotX==88 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PARTIZANSK'))
    end
if (PlotX==89 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAZO1'))
    end
if (PlotX==90 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAZO2'))
    end
if (PlotX==84 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_USSURIYSK1'))
    end
if (PlotX==85 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_USSURIYSK2'))
    end
if (PlotX==86 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHERNIGOVKA'))
    end
if (PlotX==87 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANUCHINO'))
    end
if (PlotX==88 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARSENYEV1'))
    end
if (PlotX==89 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARSENYEV2'))
    end
if (PlotX==90 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARSENYEV3'))
    end
if (PlotX==90 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OLGA1'))
    end
if (PlotX==91 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OLGA2'))
    end
if (PlotX==84 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POGRANICHNY'))
    end
if (PlotX==85 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOROL'))
    end
if (PlotX==87 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SPASSK_DALNY'))
    end
if (PlotX==89 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAKOVLEVKA'))
    end
if (PlotX==91 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAVALEROVO'))
    end
if (PlotX==92 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAVALEROVO2'))
    end
if (PlotX==84 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAMEN_RYBOLOV'))
    end
if (PlotX==87 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KIROVSKY'))
    end
if (PlotX==88 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KIROVSKY2'))
    end
if (PlotX==90 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALNEGORSK'))
    end
if (PlotX==91 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALNEGORSK2'))
    end
if (PlotX==91 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALNEGORSK3'))
    end
if (PlotX==88 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LESOZAVODSK'))
    end
if (PlotX==89 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LESOZAVODSK2'))
    end
if (PlotX==93 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TERNEY'))
    end
if (PlotX==94 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TERNEY2'))
    end
if (PlotX==94 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TERNEY3'))
    end
if (PlotX==88 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALNERECHENSK'))
    end
if (PlotX==89 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALNERECHENSKY_D'))
    end
if (PlotX==90 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALNERECHENSKY_D2'))
    end
if (PlotX==91 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALNERECHENSKY_D3'))
    end
if (PlotX==90 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOVOPOKROVKA'))
    end
if (PlotX==92 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRASNOARMEYSKY_D'))
    end
if (PlotX==93 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRASNOARMEYSKY_D2'))
    end
if (PlotX==93 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRASNOARMEYSKY_D3'))
    end
if (PlotX==89 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUCHEGORSK'))
    end
if (PlotX==89 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUCHEGORSK2'))
    end
if (PlotX==91 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRASNY_YAR'))
    end
if (PlotX==92 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VOSTOK'))
    end
if (PlotX==92 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VOSTOK2'))
    end
if (PlotX==93 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POZHARSKY_DISTRICT'))
    end
if (PlotX==94 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POZHARSKY_DISTRICT2'))
    end
if (PlotX==94 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POZHARSKY_DISTRICT3'))
    end
if (PlotX==95 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SVETLAYA'))
    end
if (PlotX==95 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SVETLAYA2'))
    end
if (PlotX==94 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AGZU'))
    end
if (PlotX==95 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AGZU2'))
    end
if (PlotX==88 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHABAROVSK'))
    end
if (PlotX==89 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHABAROVSK2'))
    end
if (PlotX==88 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIKIN'))
    end
if (PlotX==88 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VYAZEMSKY'))
    end
if (PlotX==89 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PEREYASLAVKA'))
    end
if (PlotX==91 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IMENI_LAZO'))
    end
if (PlotX==92 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IMENI_LAZO2'))
    end
if (PlotX==93 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IMENI_LAZO3'))
    end
if (PlotX==91 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANAYSKY'))
    end
if (PlotX==93 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANAYSKY2'))
    end
if (PlotX==95 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SOVETSKAYA_GAVAN'))
    end
if (PlotX==96 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SOVETSKAYA_GAVAN2'))
    end
if (PlotX==96 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SOVETSKAYA_GAVAN3'))
    end
if (PlotX==57 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUCHANG'))
    end
if (PlotX==48 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAIFENG'))
    end
if (PlotX==47 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANFENG'))
    end
if (PlotX==48 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUANEN'))
    end
if (PlotX==56 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIBI'))
    end
if (PlotX==57 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGSHAN'))
    end
if (PlotX==47 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LICHUAN'))
    end
if (PlotX==48 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ENSHI'))
    end
if (PlotX==49 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEFENG'))
    end
if (PlotX==50 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUFENG'))
    end
if (PlotX==52 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGZI'))
    end
if (PlotX==55 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANLI'))
    end
if (PlotX==57 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAYU'))
    end
if (PlotX==58 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANNING'))
    end
if (PlotX==59 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGSHI'))
    end
if (PlotX==48 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANSHI'))
    end
if (PlotX==49 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YESANGUAN'))
    end
if (PlotX==50 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGYANG'))
    end
if (PlotX==51 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIDU'))
    end
if (PlotX==53 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGZHOU'))
    end
if (PlotX==54 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGLING'))
    end
if (PlotX==55 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANYANG'))
    end
if (PlotX==58 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EZHOU'))
    end
if (PlotX==60 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGMEI'))
    end
if (PlotX==53 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIJIANG_HUBEI'))
    end
if (PlotX==54 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIANJIANG_HUBEI'))
    end
if (PlotX==60 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QICHUN'))
    end
if (PlotX==51 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHANG'))
    end
if (PlotX==52 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAOTING'))
    end
if (PlotX==53 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAYANG'))
    end
if (PlotX==55 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANCHUAN'))
    end
if (PlotX==56 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANKOU'))
    end
if (PlotX==57 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANKOU2'))
    end
if (PlotX==58 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINZHOU_HUBEI'))
    end
if (PlotX==59 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGGANG'))
    end
if (PlotX==50 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADONG'))
    end
if (PlotX==51 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZIGUI'))
    end
if (PlotX==52 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANGYANG'))
    end
if (PlotX==53 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGMEN'))
    end
if (PlotX==55 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANMEN'))
    end
if (PlotX==56 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAOGAN'))
    end
if (PlotX==57 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGPI'))
    end
if (PlotX==58 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HONGAN'))
    end
if (PlotX==59 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MACHENG'))
    end
if (PlotX==60 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGSHAN_HUBEI'))
    end
if (PlotX==49 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENNONGJIA'))
    end
if (PlotX==50 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENNONGJIA2'))
    end
if (PlotX==50 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGSHAN'))
    end
if (PlotX==51 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANAN'))
    end
if (PlotX==52 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHENG_HUBEI'))
    end
if (PlotX==54 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGXIANG'))
    end
if (PlotX==55 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUIZHOU'))
    end
if (PlotX==56 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAOCHANG'))
    end
if (PlotX==57 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAWU'))
    end
if (PlotX==49 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUXI'))
    end
if (PlotX==51 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAOKANG'))
    end
if (PlotX==52 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANZHANG'))
    end
if (PlotX==53 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGYANG'))
    end
if (PlotX==55 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAOYANG'))
    end
if (PlotX==56 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGSHUI'))
    end
if (PlotX==49 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUSHAN'))
    end
if (PlotX==50 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANGXIAN'))
    end
if (PlotX==51 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUCHENG'))
    end
if (PlotX==49 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUNXI'))
    end
if (PlotX==50 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIYAN'))
    end
if (PlotX==51 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANJIANGKOU'))
    end
if (PlotX==52 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAOHEKOU'))
    end
if (PlotX==55 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGSHA'))
    end
if (PlotX==52 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGYONG'))
    end
if (PlotX==53 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGYUAN'))
    end
if (PlotX==54 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAHE'))
    end
if (PlotX==55 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENZHOU'))
    end
if (PlotX==51 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINNING'))
    end
if (PlotX==52 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGZHOU'))
    end
if (PlotX==53 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIYANG'))
    end
if (PlotX==54 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HENGYANG'))
    end
if (PlotX==55 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LEIYANG'))
    end
if (PlotX==56 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANLING'))
    end
if (PlotX==49 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGZHOU_HUNAN'))
    end
if (PlotX==50 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUGANG_HUNAN'))
    end
if (PlotX==51 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAOYANG'))
    end
if (PlotX==52 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAODONG'))
    end
if (PlotX==53 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOUNT_HENG'))
    end
if (PlotX==55 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUZHOU'))
    end
if (PlotX==56 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YOUXIAN'))
    end
if (PlotX==49 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIJIANG_HUNAN'))
    end
if (PlotX==50 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAIHUA'))
    end
if (PlotX==51 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGSHUIJIANG'))
    end
if (PlotX==52 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOUDI'))
    end
if (PlotX==53 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGTAN'))
    end
if (PlotX==56 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIUYANG'))
    end
if (PlotX==48 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGHUANG'))
    end
if (PlotX==49 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JISHOU'))
    end
if (PlotX==50 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANLING'))
    end
if (PlotX==51 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANHUA'))
    end
if (PlotX==52 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANJIANG'))
    end
if (PlotX==53 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIYANG'))
    end
if (PlotX==55 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MILUO'))
    end
if (PlotX==56 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGJIANG'))
    end
if (PlotX==49 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGSHAN'))
    end
if (PlotX==50 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUZHANG'))
    end
if (PlotX==51 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAOYUAN_HUNAN'))
    end
if (PlotX==52 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGDE'))
    end
if (PlotX==55 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUEYANG'))
    end
if (PlotX==56 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINXIANG'))
    end
if (PlotX==49 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANGZHI'))
    end
if (PlotX==50 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGJIAJIE'))
    end
if (PlotX==51 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINLI'))
    end
if (PlotX==52 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINSHI'))
    end
if (PlotX==53 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUARONG'))
    end
if (PlotX==51 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIMEN'))
    end
if (PlotX==60 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANCHANG'))
    end
if (PlotX==58 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGNAN_JIANGXI'))
    end
if (PlotX==59 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANYUAN'))
    end
if (PlotX==60 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUNWU'))
    end
if (PlotX==58 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANZHOU'))
    end
if (PlotX==59 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUDU'))
    end
if (PlotX==60 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUIJIN'))
    end
if (PlotX==57 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGMINGSHAN'))
    end
if (PlotX==58 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WANAN'))
    end
if (PlotX==60 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGGUO'))
    end
if (PlotX==61 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHICHENG'))
    end
if (PlotX==57 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGGANGSHAN'))
    end
if (PlotX==58 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIHE'))
    end
if (PlotX==60 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGFENG'))
    end
if (PlotX==61 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANFENG'))
    end
if (PlotX==57 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGXIANG'))
    end
if (PlotX==58 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHUN_JIANGXI'))
    end
if (PlotX==59 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAN'))
    end
if (PlotX==61 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGCHENG_JIANGXI'))
    end
if (PlotX==62 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUZHOU_JIANGXI'))
    end
if (PlotX==57 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGGU'))
    end
if (PlotX==58 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYU'))
    end
if (PlotX==61 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUGAN'))
    end
if (PlotX==62 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGTAN'))
    end
if (PlotX==57 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIUSHUI'))
    end
if (PlotX==58 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUNING'))
    end
if (PlotX==59 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGXIU'))
    end
if (PlotX==62 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POYANG'))
    end
if (PlotX==63 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGRAO'))
    end
if (PlotX==64 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGFENG'))
    end
if (PlotX==58 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUICHANG'))
    end
if (PlotX==59 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIUJIANG'))
    end
if (PlotX==61 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUKOU'))
    end
if (PlotX==62 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGDEZHEN'))
    end
if (PlotX==63 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUYUAN_JIANGXI'))
    end
if (PlotX==62 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PENGZE'))
    end
if (PlotX==60 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEIJING'))
    end
if (PlotX==60 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANGSHAN'))
    end
if (PlotX==60 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANQING'))
    end
if (PlotX==62 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIYUN'))
    end
if (PlotX==61 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANJIN'))
    end
if (PlotX==62 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGU'))
    end
if (PlotX==62 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAODI'))
    end
if (PlotX==63 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGHE'))
    end
if (PlotX==62 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIZHOU'))
    end
if (PlotX==58 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIJIAZHUANG'))
    end
if (PlotX==57 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHEXIAN'))
    end
if (PlotX==58 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANDAN'))
    end
if (PlotX==59 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEIXIAN'))
    end
if (PlotX==60 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAMING'))
    end
if (PlotX==57 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGTAI'))
    end
if (PlotX==58 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JULU'))
    end
if (PlotX==59 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANGONG'))
    end
if (PlotX==60 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGHE'))
    end
if (PlotX==57 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGXING'))
    end
if (PlotX==59 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINJI'))
    end
if (PlotX==60 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HENGSHUI'))
    end
if (PlotX==61 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUQIAO'))
    end
if (PlotX==62 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANSHAN_HEBEI'))
    end
if (PlotX==57 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGSHOU'))
    end
if (PlotX==58 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINGZHOU'))
    end
if (PlotX==59 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANGUO'))
    end
if (PlotX==60 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEJIAN'))
    end
if (PlotX==61 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CANGZHOU'))
    end
if (PlotX==62 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIXING'))
    end
if (PlotX==57 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGXIAN'))
    end
if (PlotX==58 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUNPING'))
    end
if (PlotX==59 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAODING'))
    end
if (PlotX==60 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RENQIU'))
    end
if (PlotX==61 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DACHENG'))
    end
if (PlotX==62 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGHUA'))
    end
if (PlotX==58 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIXIAN_HEBEI'))
    end
if (PlotX==59 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAOBEIDIAN'))
    end
if (PlotX==60 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAZHOU'))
    end
if (PlotX==58 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAIYUAN'))
    end
if (PlotX==61 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANGFANG'))
    end
if (PlotX==64 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CAOFEIDIAN'))
    end
if (PlotX==57 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGYUAN'))
    end
if (PlotX==61 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANHE'))
    end
if (PlotX==63 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGSHAN'))
    end
if (PlotX==64 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGLI'))
    end
if (PlotX==65 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINHUANGDAO'))
    end
if (PlotX==58 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUANHUA'))
    end
if (PlotX==59 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUOLU'))
    end
if (PlotX==64 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIANXI_HB'))
    end
if (PlotX==66 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANHAIGUAN'))
    end
if (PlotX==57 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAIAN_HEBEI'))
    end
if (PlotX==58 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGJIAKOU'))
    end
if (PlotX==59 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAILAI'))
    end
if (PlotX==62 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGLONG'))
    end
if (PlotX==64 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGLONG'))
    end
if (PlotX==57 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGYI'))
    end
if (PlotX==59 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGLI'))
    end
if (PlotX==60 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHICHENG'))
    end
if (PlotX==62 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUANPING'))
    end
if (PlotX==63 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGDE'))
    end
if (PlotX==62 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGDE2'))
    end
if (PlotX==64 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUANCHENG'))
    end
if (PlotX==57 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGBEI'))
    end
if (PlotX==58 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUYUAN_HEBEI'))
    end
if (PlotX==60 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGNING'))
    end
if (PlotX==61 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGHUA'))
    end
if (PlotX==61 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGHUA2'))
    end
if (PlotX==64 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HIRAIZUMI'))
    end
if (PlotX==58 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANGBAO'))
    end
if (PlotX==61 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PADDOCK'))
    end
if (PlotX==62 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINAN'))
    end
if (PlotX==63 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIERZHUANG'))
    end
if (PlotX==60 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANXIAN'))
    end
if (PlotX==62 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAOZHUANG'))
    end
if (PlotX==63 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANLING'))
    end
if (PlotX==64 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANCHENG'))
    end
if (PlotX==60 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEZE'))
    end
if (PlotX==61 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINING'))
    end
if (PlotX==62 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZOUCHENG'))
    end
if (PlotX==63 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FEIXIAN'))
    end
if (PlotX==64 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINYI'))
    end
if (PlotX==65 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINSHU'))
    end
if (PlotX==66 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RIZHAO'))
    end
if (PlotX==60 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANGSHAN'))
    end
if (PlotX==61 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANZHOU'))
    end
if (PlotX==62 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUFU'))
    end
if (PlotX==63 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MENGYIN'))
    end
if (PlotX==64 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YISHUI'))
    end
if (PlotX==65 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUXIAN'))
    end
if (PlotX==66 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGDAO'))
    end
if (PlotX==61 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGYIN'))
    end
if (PlotX==62 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIAN'))
    end
if (PlotX==63 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOUNT_TAI'))
    end
if (PlotX==64 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIYUAN'))
    end
if (PlotX==65 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YISHAN'))
    end
if (PlotX==66 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUCHENG'))
    end
if (PlotX==67 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGDAO'))
    end
if (PlotX==60 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIAOCHENG'))
    end
if (PlotX==61 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIPING'))
    end
if (PlotX==63 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAIWU'))
    end
if (PlotX==64 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGZHOU'))
    end
if (PlotX==65 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEIFANG'))
    end
if (PlotX==66 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAOMI'))
    end
if (PlotX==67 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIMO'))
    end
if (PlotX==68 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIYANG'))
    end
if (PlotX==61 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINQING'))
    end
if (PlotX==62 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUCHENG'))
    end
if (PlotX==63 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGQIU'))
    end
if (PlotX==64 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZIBO'))
    end
if (PlotX==65 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHOUGUANG'))
    end
if (PlotX==66 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGYI'))
    end
if (PlotX==67 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGDU'))
    end
if (PlotX==68 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAIYANG'))
    end
if (PlotX==69 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUSHAN'))
    end
if (PlotX==70 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RONGCHENG'))
    end
if (PlotX==61 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEZHOU'))
    end
if (PlotX==62 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUIMIN'))
    end
if (PlotX==63 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BINZHOU'))
    end
if (PlotX==64 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KENLI'))
    end
if (PlotX==66 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAIZHOU'))
    end
if (PlotX==67 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIXIA'))
    end
if (PlotX==68 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANTAI'))
    end
if (PlotX==69 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEIHAI'))
    end
if (PlotX==63 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUDI'))
    end
if (PlotX==64 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGYING'))
    end
if (PlotX==67 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGKOU'))
    end
if (PlotX==68 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PENGLAI'))
    end
if (PlotX==54 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIYUAN'))
    end
if (PlotX==50 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGJI'))
    end
if (PlotX==51 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUNCHENG'))
    end
if (PlotX==53 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANQU'))
    end
if (PlotX==51 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEJIN'))
    end
if (PlotX==52 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINJIANG'))
    end
if (PlotX==53 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHENG_SHANXI'))
    end
if (PlotX==55 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINCHENG'))
    end
if (PlotX==51 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIXIAN'))
    end
if (PlotX==52 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINFEN'))
    end
if (PlotX==53 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANZE'))
    end
if (PlotX==54 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGZI'))
    end
if (PlotX==55 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGZHI'))
    end
if (PlotX==51 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGHE'))
    end
if (PlotX==53 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENYANG'))
    end
if (PlotX==55 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINXIAN'))
    end
if (PlotX==51 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LYULIANG'))
    end
if (PlotX==53 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAOCHENG'))
    end
if (PlotX==54 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINZHONG'))
    end
if (PlotX==55 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHOUYANG'))
    end
if (PlotX==52 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANGSHAN_SHANXI'))
    end
if (PlotX==56 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGQUAN'))
    end
if (PlotX==51 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGXIAN'))
    end
if (PlotX==54 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGQU'))
    end
if (PlotX==52 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KELAN'))
    end
if (PlotX==53 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGLE'))
    end
if (PlotX==54 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINZHOU'))
    end
if (PlotX==52 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGWU'))
    end
if (PlotX==54 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANPING'))
    end
if (PlotX==55 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUTAI'))
    end
if (PlotX==56 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGQIU'))
    end
if (PlotX==52 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEQU'))
    end
if (PlotX==53 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENCHI'))
    end
if (PlotX==54 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUOZHOU'))
    end
if (PlotX==57 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGLING'))
    end
if (PlotX==53 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGLU'))
    end
if (PlotX==54 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGXIAN'))
    end
if (PlotX==55 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUNYUAN'))
    end
if (PlotX==55 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DATONG'))
    end
if (PlotX==56 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGGAO'))
    end
if (PlotX==57 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANZHEN'))
    end
if (PlotX==55 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGZHOU'))
    end
if (PlotX==58 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGCHENG'))
    end
if (PlotX==58 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGSHAN'))
    end
if (PlotX==59 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUSHI'))
    end
if (PlotX==54 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGBAI'))
    end
if (PlotX==56 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYANG'))
    end
if (PlotX==57 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUOSHAN'))
    end
if (PlotX==58 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGCHUAN'))
    end
if (PlotX==53 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYE'))
    end
if (PlotX==54 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGHE'))
    end
if (PlotX==55 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIYANG'))
    end
if (PlotX==56 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUESHAN'))
    end
if (PlotX==51 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XICHUAN'))
    end
if (PlotX==52 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DENGZHOU'))
    end
if (PlotX==53 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANYANG'))
    end
if (PlotX==54 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHEQI'))
    end
if (PlotX==55 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUGANG_HENAN'))
    end
if (PlotX==56 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUMADIAN'))
    end
if (PlotX==57 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGYANG'))
    end
if (PlotX==58 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAIBIN'))
    end
if (PlotX==51 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIXIA'))
    end
if (PlotX==53 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENPING'))
    end
if (PlotX==54 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANZHAO'))
    end
if (PlotX==55 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YEXIAN'))
    end
if (PlotX==56 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUYANG'))
    end
if (PlotX==57 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGCAI'))
    end
if (PlotX==58 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGYU'))
    end
if (PlotX==52 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUANCHUAN'))
    end
if (PlotX==53 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGXIAN'))
    end
if (PlotX==54 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGDINGSHAN'))
    end
if (PlotX==55 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINYING'))
    end
if (PlotX==56 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUOHE'))
    end
if (PlotX==57 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHOUKOU'))
    end
if (PlotX==58 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANCHENG'))
    end
if (PlotX==60 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGCHENG'))
    end
if (PlotX==52 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUONING'))
    end
if (PlotX==53 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIYANG_HENAN'))
    end
if (PlotX==54 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGSHAN'))
    end
if (PlotX==55 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUZHOU'))
    end
if (PlotX==56 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUCHANG'))
    end
if (PlotX==57 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUGOU'))
    end
if (PlotX==58 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIKANG'))
    end
if (PlotX==59 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUYI'))
    end
if (PlotX==60 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGQIU'))
    end
if (PlotX==51 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANMENXIA'))
    end
if (PlotX==52 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIANCHI'))
    end
if (PlotX==53 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUOYANG'))
    end
if (PlotX==54 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGYI'))
    end
if (PlotX==56 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGMU'))
    end
if (PlotX==57 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAIFENG'))
    end
if (PlotX==58 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUXIANG'))
    end
if (PlotX==59 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANKAO'))
    end
if (PlotX==54 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIYUAN'))
    end
if (PlotX==55 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAOZUO'))
    end
if (PlotX==56 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINXIANG'))
    end
if (PlotX==57 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANJIN'))
    end
if (PlotX==58 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGQIU'))
    end
if (PlotX==59 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGYUAN'))
    end
if (PlotX==55 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIUWU'))
    end
if (PlotX==56 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEIHUI'))
    end
if (PlotX==57 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIXIAN'))
    end
if (PlotX==58 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAXIAN'))
    end
if (PlotX==59 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANXIAN'))
    end
if (PlotX==57 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEBI'))
    end
if (PlotX==58 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUNXIAN'))
    end
if (PlotX==59 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUYANG'))
    end
if (PlotX==60 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIQIAN'))
    end
if (PlotX==56 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINZHOU'))
    end
if (PlotX==57 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANYANG'))
    end
if (PlotX==58 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEIHUANG'))
    end
if (PlotX==59 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANLE'))
    end
if (PlotX==46 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANNING'))
    end
if (PlotX==47 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANNING2'))
    end
if (PlotX==46 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGXING'))
    end
if (PlotX==48 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NORTH_SEA'))
    end
if (PlotX==45 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGXIANG_GUANGXI'))
    end
if (PlotX==47 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANGCHENGGANG'))
    end
if (PlotX==48 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINZHOU'))
    end
if (PlotX==49 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEPU'))
    end
if (PlotX==50 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIESHANGANG'))
    end
if (PlotX==45 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGZUO'))
    end
if (PlotX==46 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGSI'))
    end
if (PlotX==47 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANGQING'))
    end
if (PlotX==48 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGSHAN'))
    end
if (PlotX==49 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUBEI'))
    end
if (PlotX==50 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULIN_GUANGXI'))
    end
if (PlotX==42 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAPO'))
    end
if (PlotX==42 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAPO2'))
    end
if (PlotX==44 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGXI'))
    end
if (PlotX==43 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGXI2'))
    end
if (PlotX==45 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAXIN'))
    end
if (PlotX==46 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUSUI'))
    end
if (PlotX==50 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGYE'))
    end
if (PlotX==51 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CENXI'))
    end
if (PlotX==44 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANDONG'))
    end
if (PlotX==45 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGGUO'))
    end
if (PlotX==48 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUIGANG'))
    end
if (PlotX==43 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAISE'))
    end
if (PlotX==44 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAISE2'))
    end
if (PlotX==45 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAMA'))
    end
if (PlotX==46 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUMING'))
    end
if (PlotX==47 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BINYANG'))
    end
if (PlotX==49 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUIPING'))
    end
if (PlotX==50 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGNAN'))
    end
if (PlotX==51 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGXIAN'))
    end
if (PlotX==52 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUZHOU'))
    end
if (PlotX==41 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XILIN'))
    end
if (PlotX==42 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGLIN'))
    end
if (PlotX==46 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MASHAN'))
    end
if (PlotX==47 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAIBIN'))
    end
if (PlotX==48 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGZHOU'))
    end
if (PlotX==49 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIPU'))
    end
if (PlotX==50 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGLE'))
    end
if (PlotX==51 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOPING'))
    end
if (PlotX==46 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANDAN'))
    end
if (PlotX==47 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HECHI'))
    end
if (PlotX==48 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIUZHOU'))
    end
if (PlotX==50 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGSHUO'))
    end
if (PlotX==52 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUCHUAN'))
    end
if (PlotX==53 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEZHOU'))
    end
if (PlotX==48 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RONGAN'))
    end
if (PlotX==49 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUILIN'))
    end
if (PlotX==50 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGAN'))
    end
if (PlotX==51 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANYANG'))
    end
if (PlotX==50 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGSHENG'))
    end
if (PlotX==44 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUIYANG'))
    end
if (PlotX==40 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PANZHOU'))
    end
if (PlotX==41 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGYI'))
    end
if (PlotX==42 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANLONG'))
    end
if (PlotX==43 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CEHENG'))
    end
if (PlotX==45 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUODIAN'))
    end
if (PlotX==41 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIUZHI'))
    end
if (PlotX==42 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANSHUN'))
    end
if (PlotX==43 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGSHUN'))
    end
if (PlotX==44 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUISHUI'))
    end
if (PlotX==45 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGTANG'))
    end
if (PlotX==46 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUYUN'))
    end
if (PlotX==47 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RONGJIANG'))
    end
if (PlotX==40 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIUPANSHUI'))
    end
if (PlotX==41 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAYONG'))
    end
if (PlotX==42 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIJIN'))
    end
if (PlotX==43 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGZHEN'))
    end
if (PlotX==46 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUQUAN'))
    end
if (PlotX==47 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAILI'))
    end
if (PlotX==48 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINPING'))
    end
if (PlotX==39 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEINING'))
    end
if (PlotX==41 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIJIE'))
    end
if (PlotX==42 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIANXI'))
    end
if (PlotX==43 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIUWEN'))
    end
if (PlotX==44 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAIYANG'))
    end
if (PlotX==45 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENGAN'))
    end
if (PlotX==46 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUQING'))
    end
if (PlotX==48 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANZHU'))
    end
if (PlotX==42 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINSHA'))
    end
if (PlotX==44 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZUNYI'))
    end
if (PlotX==45 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEITAN'))
    end
if (PlotX==46 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGGANG'))
    end
if (PlotX==47 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGKOU'))
    end
if (PlotX==48 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGREN'))
    end
if (PlotX==42 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RENHUAI'))
    end
if (PlotX==43 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGZI'))
    end
if (PlotX==46 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEJIANG'))
    end
if (PlotX==42 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHISHUI'))
    end
if (PlotX==43 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGQING'))
    end
if (PlotX==43 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGQING2'))
    end
if (PlotX==41 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YOUYANG'))
    end
if (PlotX==43 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIJIANG'))
    end
if (PlotX==44 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANCHUAN'))
    end
if (PlotX==45 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WULONG'))
    end
if (PlotX==46 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PENGSHUI'))
    end
if (PlotX==42 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGJIN'))
    end
if (PlotX==44 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FULING'))
    end
if (PlotX==45 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGDU'))
    end
if (PlotX==46 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIANJIANG_CHONGQING'))
    end
if (PlotX==42 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGCHUAN'))
    end
if (PlotX==46 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIZHU'))
    end
if (PlotX==41 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAZU'))
    end
if (PlotX==42 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HECHUAN'))
    end
if (PlotX==44 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGSHOU'))
    end
if (PlotX==46 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGXIAN'))
    end
if (PlotX==45 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGXIAN2'))
    end
if (PlotX==42 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGNAN'))
    end
if (PlotX==48 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUIMEN'))
    end
if (PlotX==44 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANGPING'))
    end
if (PlotX==45 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WANZHOU'))
    end
if (PlotX==46 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WANZHOU2'))
    end
if (PlotX==47 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUNYANG'))
    end
if (PlotX==48 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGJIE'))
    end
if (PlotX==49 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUSHAN'))
    end
if (PlotX==46 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAIZHOU'))
    end
if (PlotX==48 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUXI_COUNTY'))
    end
if (PlotX==47 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGKOU'))
    end
if (PlotX==39 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGDU'))
    end
if (PlotX==41 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GULIN'))
    end
if (PlotX==40 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIBIN'))
    end
if (PlotX==41 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGAN'))
    end
if (PlotX==38 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EBIAN'))
    end
if (PlotX==39 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIANWEI'))
    end
if (PlotX==40 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUSHUN_SICHUAN'))
    end
if (PlotX==41 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUZHOU'))
    end
if (PlotX==37 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANYUAN'))
    end
if (PlotX==39 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LESHAN'))
    end
if (PlotX==40 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZIGONG'))
    end
if (PlotX==41 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGCHANG'))
    end
if (PlotX==37 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAAN'))
    end
if (PlotX==38 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEISHAN'))
    end
if (PlotX==39 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZIYANG'))
    end
if (PlotX==40 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEIJIANG'))
    end
if (PlotX==38 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGZHOU'))
    end
if (PlotX==40 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAYING'))
    end
if (PlotX==41 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUINING'))
    end
if (PlotX==44 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAYING'))
    end
if (PlotX==38 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUJIANGYAN'))
    end
if (PlotX==39 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEYANG'))
    end
if (PlotX==40 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHEHONG'))
    end
if (PlotX==41 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANCHONG'))
    end
if (PlotX==42 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUECHI'))
    end
if (PlotX==43 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGAN'))
    end
if (PlotX==39 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIANZHU'))
    end
if (PlotX==40 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIANYANG'))
    end
if (PlotX==41 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANTING'))
    end
if (PlotX==42 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YILONG'))
    end
if (PlotX==43 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGSHAN_SICHUAN'))
    end
if (PlotX==44 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUXIAN'))
    end
if (PlotX==39 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEICHUAN'))
    end
if (PlotX==40 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGYOU'))
    end
if (PlotX==41 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANGZHONG'))
    end
if (PlotX==42 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAZHONG'))
    end
if (PlotX==44 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAZHOU'))
    end
if (PlotX==39 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGWU'))
    end
if (PlotX==41 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGE'))
    end
if (PlotX==45 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUANHAN'))
    end
if (PlotX==41 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGYUAN'))
    end
if (PlotX==42 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGYUAN2'))
    end
if (PlotX==44 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANJIANG'))
    end
if (PlotX==35 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PANZHIHUA'))
    end
if (PlotX==35 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIYI'))
    end
if (PlotX==35 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XICHANG'))
    end
if (PlotX==36 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUILI'))
    end
if (PlotX==35 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DECHANG'))
    end
if (PlotX==36 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIANNING'))
    end
if (PlotX==36 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANLUO'))
    end
if (PlotX==35 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARKAM'))
    end
if (PlotX==37 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGXIU'))
    end
if (PlotX==34 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINCHUAN'))
    end
if (PlotX==36 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIXIAN_SICHUAN'))
    end
if (PlotX==37 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENCHUAN'))
    end
if (PlotX==37 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAOXIAN'))
    end
if (PlotX==34 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAMTHANG'))
    end
if (PlotX==33 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAMTHANG2'))
    end
if (PlotX==34 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAWA'))
    end
if (PlotX==34 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAWA2'))
    end
if (PlotX==35 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAWA3'))
    end
if (PlotX==37 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEISHUI'))
    end
if (PlotX==36 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEISHUI2'))
    end
if (PlotX==36 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HONGYUAN'))
    end
if (PlotX==36 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HONGYUAN2'))
    end
if (PlotX==37 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGPAN'))
    end
if (PlotX==38 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGLONG'))
    end
if (PlotX==38 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIUZHAIGOU'))
    end
if (PlotX==39 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIUZHAIGOU2'))
    end
if (PlotX==35 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZOIGE'))
    end
if (PlotX==36 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZOIGE2'))
    end
if (PlotX==37 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZOIGE3'))
    end
if (PlotX==35 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANGDING'))
    end
if (PlotX==30 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DERONG'))
    end
if (PlotX==30 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BATANG'))
    end
if (PlotX==31 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAOCHENG'))
    end
if (PlotX==31 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LITANG'))
    end
if (PlotX==31 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LITANG2'))
    end
if (PlotX==33 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAJIANG'))
    end
if (PlotX==34 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINDUQIAO'))
    end
if (PlotX==36 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUDING'))
    end
if (PlotX==33 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINLONG'))
    end
if (PlotX==31 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINLONG2'))
    end
if (PlotX==30 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIYU'))
    end
if (PlotX==29 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEGE'))
    end
if (PlotX==30 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEGE2'))
    end
if (PlotX==29 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEGE3'))
    end
if (PlotX==32 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARZE'))
    end
if (PlotX==31 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARZE2'))
    end
if (PlotX==31 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARZE3'))
    end
if (PlotX==30 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARZE4'))
    end
if (PlotX==32 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUHUO'))
    end
if (PlotX==33 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUHUO2'))
    end
if (PlotX==32 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERTAR'))
    end
if (PlotX==33 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERTAR2'))
    end
if (PlotX==32 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERTAR3'))
    end
if (PlotX==31 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERTAR4'))
    end
if (PlotX==32 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERTAR5'))
    end
if (PlotX==29 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU'))
    end
if (PlotX==30 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU2'))
    end
if (PlotX==28 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU3'))
    end
if (PlotX==29 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU4'))
    end
if (PlotX==30 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU5'))
    end
if (PlotX==28 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU6'))
    end
if (PlotX==29 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU7'))
    end
if (PlotX==28 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SERXU8'))
    end
if (PlotX==36 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUNMING'))
    end
if (PlotX==37 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUNMING2'))
    end
if (PlotX==35 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUNMING3'))
    end
if (PlotX==32 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MENGHAI'))
    end
if (PlotX==33 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGHONG'))
    end
if (PlotX==32 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANCANG'))
    end
if (PlotX==33 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUER'))
    end
if (PlotX==33 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUER2'))
    end
if (PlotX==34 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YEXIANGGU'))
    end
if (PlotX==35 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MENGWANG'))
    end
if (PlotX==36 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANGCHENG'))
    end
if (PlotX==32 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GENGMA'))
    end
if (PlotX==34 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANJIANG_YUNNAN'))
    end
if (PlotX==36 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANYANG'))
    end
if (PlotX==37 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGBIAN'))
    end
if (PlotX==38 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEKOU'))
    end
if (PlotX==32 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENKANG'))
    end
if (PlotX==33 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGGU'))
    end
if (PlotX==35 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINPING'))
    end
if (PlotX==36 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEJIU'))
    end
if (PlotX==37 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MENGZI'))
    end
if (PlotX==39 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENSHAN'))
    end
if (PlotX==40 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MALIPO'))
    end
if (PlotX==30 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUILI'))
    end
if (PlotX==32 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINCANG'))
    end
if (PlotX==34 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGBAI'))
    end
if (PlotX==35 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUXI'))
    end
if (PlotX==36 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGJIANG'))
    end
if (PlotX==38 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIUBEI'))
    end
if (PlotX==39 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANSHAN_YUNNAN'))
    end
if (PlotX==40 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XICHOU'))
    end
if (PlotX==41 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUNING'))
    end
if (PlotX==29 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGJIANG'))
    end
if (PlotX==29 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANGHE'))
    end
if (PlotX==32 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGQING'))
    end
if (PlotX==34 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUXIONG'))
    end
if (PlotX==34 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUXIONG2'))
    end
if (PlotX==35 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANNING'))
    end
if (PlotX==38 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MILE'))
    end
if (PlotX==39 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIZONG'))
    end
if (PlotX==40 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGNAN'))
    end
if (PlotX==41 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUANGNAN2'))
    end
if (PlotX==30 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGCHONG'))
    end
if (PlotX==30 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGCHONG2'))
    end
if (PlotX==31 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAOSHAN'))
    end
if (PlotX==31 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAOSHAN2'))
    end
if (PlotX==32 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEISHAN'))
    end
if (PlotX==33 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANJIAN'))
    end
if (PlotX==37 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LULIANG'))
    end
if (PlotX==38 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUJING'))
    end
if (PlotX==38 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUJING2'))
    end
if (PlotX==39 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUOPING'))
    end
if (PlotX==32 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALI'))
    end
if (PlotX==33 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALI2'))
    end
if (PlotX==33 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALI3'))
    end
if (PlotX==34 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANHUA'))
    end
if (PlotX==35 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUANMOU'))
    end
if (PlotX==36 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUDING'))
    end
if (PlotX==37 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUNDIAN'))
    end
if (PlotX==39 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUAN_YUNNAN'))
    end
if (PlotX==29 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUSHUI'))
    end
if (PlotX==30 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUSHUI2'))
    end
if (PlotX==30 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CAOJIAN'))
    end
if (PlotX==36 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGCHUAN'))
    end
if (PlotX==37 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUIZE'))
    end
if (PlotX==39 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XUANWEI'))
    end
if (PlotX==31 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANPING'))
    end
if (PlotX==33 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEQING'))
    end
if (PlotX==34 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAPING'))
    end
if (PlotX==38 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIAOJIA'))
    end
if (PlotX==30 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUGONG'))
    end
if (PlotX==30 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUGONG2'))
    end
if (PlotX==32 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIJIANG'))
    end
if (PlotX==33 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGSHENG'))
    end
if (PlotX==38 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUDIAN'))
    end
if (PlotX==32 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIGER_LEAPING_GORGE'))
    end
if (PlotX==39 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOTONG'))
    end
if (PlotX==29 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEIXI'))
    end
if (PlotX==31 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGRI_LA'))
    end
if (PlotX==31 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGRI_LA2'))
    end
if (PlotX==39 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUIFU'))
    end
if (PlotX==29 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGSHAN'))
    end
if (PlotX==28 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEQIN'))
    end
if (PlotX==48 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAN'))
    end
if (PlotX==46 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANGAO'))
    end
if (PlotX==43 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGQIANG'))
    end
if (PlotX==45 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENBA'))
    end
if (PlotX==46 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZIYANG_SHAANXI'))
    end
if (PlotX==47 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANKANG'))
    end
if (PlotX==48 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIHE'))
    end
if (PlotX==43 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIANXIAN'))
    end
if (PlotX==44 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANZHONG'))
    end
if (PlotX==45 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGGU'))
    end
if (PlotX==46 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIQUAN'))
    end
if (PlotX==43 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUEYANG'))
    end
if (PlotX==45 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FOPING'))
    end
if (PlotX==47 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGSHAN'))
    end
if (PlotX==48 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENAN'))
    end
if (PlotX==43 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGXIAN'))
    end
if (PlotX==45 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHOUZHI'))
    end
if (PlotX==48 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANTIAN'))
    end
if (PlotX==49 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGLUO'))
    end
if (PlotX==50 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANFENG'))
    end
if (PlotX==43 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENCANG'))
    end
if (PlotX==44 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAOJI'))
    end
if (PlotX==45 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUFENG'))
    end
if (PlotX==46 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGPING'))
    end
if (PlotX==47 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANYANG'))
    end
if (PlotX==49 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEINAN'))
    end
if (PlotX==44 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGXIANG'))
    end
if (PlotX==45 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGSHOU'))
    end
if (PlotX==46 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIQUAN'))
    end
if (PlotX==47 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANYUAN'))
    end
if (PlotX==48 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANLIANG'))
    end
if (PlotX==49 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUAYIN'))
    end
if (PlotX==50 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGGUAN'))
    end
if (PlotX==44 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGXIAN'))
    end
if (PlotX==46 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BINZHOU_SHAANXI'))
    end
if (PlotX==47 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUNHUA'))
    end
if (PlotX==48 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGCHUAN'))
    end
if (PlotX==49 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUCHENG_SHAANXI'))
    end
if (PlotX==50 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALI_SHAANXI'))
    end
if (PlotX==47 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIJUN'))
    end
if (PlotX==49 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEYANG'))
    end
if (PlotX==47 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGLING'))
    end
if (PlotX==48 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUOCHUAN'))
    end
if (PlotX==49 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHUAN'))
    end
if (PlotX==47 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANQUAN'))
    end
if (PlotX==48 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANAN'))
    end
if (PlotX==49 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANAN2'))
    end
if (PlotX==49 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANCHANG'))
    end
if (PlotX==47 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIDAN'))
    end
if (PlotX==48 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANSAI'))
    end
if (PlotX==50 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANCHUAN'))
    end
if (PlotX==44 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINGBAIN'))
    end
if (PlotX==45 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINGBIAN'))
    end
if (PlotX==46 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUQI'))
    end
if (PlotX==48 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZICHANG'))
    end
if (PlotX==49 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUIDE'))
    end
if (PlotX==50 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUBAO'))
    end
if (PlotX==46 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGBIAN'))
    end
if (PlotX==47 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGBIAN2'))
    end
if (PlotX==48 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HENGSHAN'))
    end
if (PlotX==49 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZIZHOU'))
    end
if (PlotX==50 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIZHI'))
    end
if (PlotX==48 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULIN_SHAANXI'))
    end
if (PlotX==49 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULIN_SHAANXI2'))
    end
if (PlotX==49 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULIN_SHAANXI3'))
    end
if (PlotX==50 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAXIAN'))
    end
if (PlotX==50 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENMU'))
    end
if (PlotX==49 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENMU2'))
    end
if (PlotX==50 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUGU'))
    end
if (PlotX==51 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUGU2'))
    end
if (PlotX==42 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINCHUAN'))
    end
if (PlotX==43 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGYUAN_NINGXIA'))
    end
if (PlotX==41 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIJI'))
    end
if (PlotX==42 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUYUAN'))
    end
if (PlotX==43 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PENGYANG'))
    end
if (PlotX==42 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIYUAN'))
    end
if (PlotX==43 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGXIN'))
    end
if (PlotX==40 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIKOU'))
    end
if (PlotX==41 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGNING'))
    end
if (PlotX==42 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUZHONG'))
    end
if (PlotX==43 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUI’ANPU'))
    end
if (PlotX==40 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAPOTOU'))
    end
if (PlotX==41 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGWEI'))
    end
if (PlotX==42 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGTONGXIA'))
    end
if (PlotX==43 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGWU'))
    end
if (PlotX==44 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANCHI'))
    end
if (PlotX==43 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HELAN'))
    end
if (PlotX==42 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIZUISHAN'))
    end
if (PlotX==38 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANZHOU'))
    end
if (PlotX==37 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANZHOU2'))
    end
if (PlotX==40 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENXIAN'))
    end
if (PlotX==40 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGNAN'))
    end
if (PlotX==40 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGNAN2'))
    end
if (PlotX==41 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGNAN3'))
    end
if (PlotX==35 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAQU'))
    end
if (PlotX==34 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAQU2'))
    end
if (PlotX==35 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAQU3'))
    end
if (PlotX==39 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHOUQU'))
    end
if (PlotX==42 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANGXIAN'))
    end
if (PlotX==37 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TEWO'))
    end
if (PlotX==38 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANCHANG'))
    end
if (PlotX==41 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHENGXIAN'))
    end
if (PlotX==36 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUQU'))
    end
if (PlotX==37 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JONE'))
    end
if (PlotX==38 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINXIAN'))
    end
if (PlotX==39 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIXIAN_GANSU'))
    end
if (PlotX==41 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIHE'))
    end
if (PlotX==42 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANSHUI'))
    end
if (PlotX==41 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANSHUI2'))
    end
if (PlotX==36 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEZUO'))
    end
if (PlotX==38 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGXIAN'))
    end
if (PlotX==39 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUSHAN_GANSU'))
    end
if (PlotX==40 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANGU'))
    end
if (PlotX==42 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAIJI'))
    end
if (PlotX==36 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIAHE'))
    end
if (PlotX==37 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINXIA'))
    end
if (PlotX==38 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINTAO'))
    end
if (PlotX==39 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEIYUAN'))
    end
if (PlotX==40 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGXI'))
    end
if (PlotX==41 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINAN'))
    end
if (PlotX==42 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGSHUI'))
    end
if (PlotX==36 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGJING'))
    end
if (PlotX==37 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGJING2'))
    end
if (PlotX==39 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINGXI'))
    end
if (PlotX==40 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINGXI2'))
    end
if (PlotX==40 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGWEI'))
    end
if (PlotX==41 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGNING'))
    end
if (PlotX==42 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUANGLANG'))
    end
if (PlotX==43 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUATING'))
    end
if (PlotX==45 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGTAI'))
    end
if (PlotX==39 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUZHONG'))
    end
if (PlotX==41 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUINING'))
    end
if (PlotX==40 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUINING2'))
    end
if (PlotX==44 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGLIANG'))
    end
if (PlotX==45 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHONGXIN'))
    end
if (PlotX==46 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGXIAN'))
    end
if (PlotX==36 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGDENG'))
    end
if (PlotX==37 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGDENG2'))
    end
if (PlotX==38 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAOLAN'))
    end
if (PlotX==39 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGYUAN_GANSU'))
    end
if (PlotX==39 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGYUAN_GANSU2'))
    end
if (PlotX==44 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENYUAN'))
    end
if (PlotX==45 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGYANG'))
    end
if (PlotX==46 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HESHUI'))
    end
if (PlotX==38 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGTAI'))
    end
if (PlotX==38 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGTAI2'))
    end
if (PlotX==39 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIYIN'))
    end
if (PlotX==40 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGCHUAN'))
    end
if (PlotX==41 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINGCHUAN2'))
    end
if (PlotX==45 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANXIAN'))
    end
if (PlotX==46 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUACHI'))
    end
if (PlotX==36 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUWEI'))
    end
if (PlotX==37 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUWEI2'))
    end
if (PlotX==37 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIRI'))
    end
if (PlotX==36 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GULANG'))
    end
if (PlotX==35 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YONGCHANG'))
    end
if (PlotX==34 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINCHANG'))
    end
if (PlotX==35 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINCHANG2'))
    end
if (PlotX==36 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINQIN'))
    end
if (PlotX==36 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINQIN2'))
    end
if (PlotX==37 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINQIN3'))
    end
if (PlotX==36 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINQIN4'))
    end
if (PlotX==33 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANDAN'))
    end
if (PlotX==33 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANDAN2'))
    end
if (PlotX==34 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANDAN3'))
    end
if (PlotX==33 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINLE'))
    end
if (PlotX==32 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINLE2'))
    end
if (PlotX==31 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGYE'))
    end
if (PlotX==32 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGYE2'))
    end
if (PlotX==32 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGYE3'))
    end
if (PlotX==31 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINZE'))
    end
if (PlotX==32 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINZE2'))
    end
if (PlotX==30 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAOTAI'))
    end
if (PlotX==31 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAOTAI2'))
    end
if (PlotX==30 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAOTAI3'))
    end
if (PlotX==28 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUNAN'))
    end
if (PlotX==29 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUNAN2'))
    end
if (PlotX==29 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIUQUAN'))
    end
if (PlotX==29 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIUQUAN2'))
    end
if (PlotX==30 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIUQUAN3'))
    end
if (PlotX==28 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAYUGUAN'))
    end
if (PlotX==29 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINTA'))
    end
if (PlotX==30 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINTA2'))
    end
if (PlotX==31 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINTA3'))
    end
if (PlotX==29 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINTA4'))
    end
if (PlotX==30 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINTA5'))
    end
if (PlotX==31 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGTIAN'))
    end
if (PlotX==31 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGTIAN2'))
    end
if (PlotX==32 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGTIAN3'))
    end
if (PlotX==27 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGMA'))
    end
if (PlotX==22 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAY'))
    end
if (PlotX==23 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAY2'))
    end
if (PlotX==23 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAY3'))
    end
if (PlotX==21 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAY4'))
    end
if (PlotX==22 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAY5'))
    end
if (PlotX==24 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUBEI'))
    end
if (PlotX==25 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUBEI2'))
    end
if (PlotX==24 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUBEI3'))
    end
if (PlotX==25 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUBEI4'))
    end

	if (PlotX==22 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG'))
    end
if (PlotX==23 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG2'))
    end
if (PlotX==24 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG3'))
    end
if (PlotX==21 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG4'))
    end
if (PlotX==22 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG5'))
    end
if (PlotX==23 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG6'))
    end
if (PlotX==24 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG7'))
    end
if (PlotX==22 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG8'))
    end
if (PlotX==23 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG9'))
    end
if (PlotX==24 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG10'))
    end
if (PlotX==22 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG11'))
    end
if (PlotX==23 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUANG12'))
    end
if (PlotX==25 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU'))
    end
if (PlotX==25 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU2'))
    end
if (PlotX==26 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU3'))
    end
if (PlotX==24 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU4'))
    end
if (PlotX==25 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU5'))
    end
if (PlotX==26 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU6'))
    end
if (PlotX==25 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU7'))
    end
if (PlotX==26 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUAZHOU8'))
    end
if (PlotX==26 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMEN'))
    end
if (PlotX==27 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMEN2'))
    end
if (PlotX==27 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMEN3'))
    end
if (PlotX==28 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMEN4'))
    end
if (PlotX==27 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMEN5'))
    end
if (PlotX==28 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMEN6'))
    end
if (PlotX==28 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMEN7'))
    end
if (PlotX==26 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN'))
    end
if (PlotX==27 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN2'))
    end
if (PlotX==26 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN3'))
    end
if (PlotX==27 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN4'))
    end
if (PlotX==28 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN5'))
    end
if (PlotX==25 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN6'))
    end
if (PlotX==26 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN7'))
    end
if (PlotX==27 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN8'))
    end
if (PlotX==26 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN9'))
    end
if (PlotX==27 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN10'))
    end
if (PlotX==24 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIUYUAN'))
    end
if (PlotX==25 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIUYUAN2'))
    end
if (PlotX==84 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENINSKOYE'))
    end
if (PlotX==83 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMURZET'))
    end
if (PlotX==76 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HARBIN'))
    end
if (PlotX==76 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HARBIN2'))
    end
if (PlotX==80 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGAN'))
    end
if (PlotX==81 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGAN2'))
    end
if (PlotX==80 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGAN3'))
    end
if (PlotX==78 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUCHANG_HEILONGJIANG'))
    end
if (PlotX==83 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUIFENHE'))
    end
if (PlotX==82 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MULING'))
    end
if (PlotX==82 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MULING2'))
    end
if (PlotX==80 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUDANJIANG'))
    end
if (PlotX==81 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUDANJIANG2'))
    end
if (PlotX==81 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUDANJIANG3'))
    end
if (PlotX==78 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGZHI'))
    end
if (PlotX==78 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGZHI2'))
    end
if (PlotX==79 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAILIN'))
    end
if (PlotX==80 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAILIN2'))
    end
if (PlotX==76 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGCHENG'))
    end
if (PlotX==77 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ACHENG'))
    end
if (PlotX==82 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINKOU'))
    end
if (PlotX==83 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIXI'))
    end
if (PlotX==84 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIXI2'))
    end
if (PlotX==85 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIDONG'))
    end
if (PlotX==87 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MISHAN'))
    end
if (PlotX==85 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MISHAN2'))
    end
if (PlotX==86 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MISHAN3'))
    end
if (PlotX==73 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOYUAN'))
    end
if (PlotX==74 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOYUAN2'))
    end
if (PlotX==75 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOZHOU'))
    end
if (PlotX==75 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOZHOU2'))
    end
if (PlotX==77 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BINXIAN'))
    end
if (PlotX==78 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BINXIAN2'))
    end
if (PlotX==79 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANGZHENG'))
    end
if (PlotX==80 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANGZHENG2'))
    end
if (PlotX==81 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YILAN_HLJ'))
    end
if (PlotX==81 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YILAN_HLJ2'))
    end
if (PlotX==82 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YILAN_HLJ3'))
    end
if (PlotX==82 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOLI'))
    end
if (PlotX==83 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QITAIHE'))
    end
if (PlotX==84 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QITAIHE2'))
    end
if (PlotX==87 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HULIN'))
    end
if (PlotX==73 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD'))
    end
if (PlotX==73 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD2'))
    end
if (PlotX==74 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAQING'))
    end
if (PlotX==74 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAQING2'))
    end
if (PlotX==77 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HULAN'))
    end
if (PlotX==80 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGHE'))
    end
if (PlotX==83 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANAN'))
    end
if (PlotX==84 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANAN2'))
    end
if (PlotX==85 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAUNGYASHAN'))
    end
if (PlotX==87 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAOHE'))
    end
if (PlotX==87 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAOHE2'))
    end
if (PlotX==71 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAILAI'))
    end
if (PlotX==72 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIQIHAR'))
    end
if (PlotX==73 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIQIHAR2'))
    end
if (PlotX==75 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANDA'))
    end
if (PlotX==76 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANXI'))
    end
if (PlotX==77 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUIHUA'))
    end
if (PlotX==79 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUIHUA2'))
    end
if (PlotX==78 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGAN'))
    end
if (PlotX==79 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGAN2'))
    end
if (PlotX==79 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIELI'))
    end
if (PlotX==80 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIELI2'))
    end
if (PlotX==81 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGYUAN'))
    end
if (PlotX==82 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAMUSI'))
    end
if (PlotX==83 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAMUSI2'))
    end
if (PlotX==84 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUACHUAN'))
    end
if (PlotX==85 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUJIN'))
    end
if (PlotX==71 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGJIANG'))
    end
if (PlotX==71 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LONGJIANG2'))
    end
if (PlotX==72 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEILISI'))
    end
if (PlotX==74 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINDIAN'))
    end
if (PlotX==75 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINDIAN2'))
    end
if (PlotX==76 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGGANG'))
    end
if (PlotX==77 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WANGKUI'))
    end
if (PlotX==80 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHUN_HEILONGJIANG'))
    end
if (PlotX==81 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHUN_HEILONGJIANG2'))
    end
if (PlotX==80 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHUN_HEILONGJIANG3'))
    end
if (PlotX==81 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YICHUN_HEILONGJIANG4'))
    end
if (PlotX==82 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEGANG'))
    end
if (PlotX==83 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEGANG2'))
    end
if (PlotX==82 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEGANG3'))
    end
if (PlotX==84 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUOBEI'))
    end
if (PlotX==85 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUIBIN'))
    end
if (PlotX==86 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGJIANG'))
    end
if (PlotX==87 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGJIANG2'))
    end
if (PlotX==88 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUAN_HEILONGJIANG'))
    end
if (PlotX==72 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANNAN'))
    end
if (PlotX==73 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYU_HEILONGJIANG'))
    end
if (PlotX==74 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIAN'))
    end
if (PlotX==75 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIQUAN'))
    end
if (PlotX==76 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINGSHUI'))
    end
if (PlotX==77 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAILUN'))
    end
if (PlotX==78 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUILENG'))
    end
if (PlotX==79 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUILENG2'))
    end
if (PlotX==75 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGCHUN'))
    end
if (PlotX==74 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGCHUN2'))
    end
if (PlotX==75 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGCHUN3'))
    end
if (PlotX==75 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAN_JILIN'))
    end
if (PlotX==75 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAN_JILIN2'))
    end
if (PlotX==75 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGHUA'))
    end
if (PlotX==76 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAISHAN'))
    end
if (PlotX==75 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAISHAN2'))
    end
if (PlotX==78 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGBAI'))
    end
if (PlotX==74 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIUHE'))
    end
if (PlotX==76 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINJIANG'))
    end
if (PlotX==77 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINJIANG2'))
    end
if (PlotX==74 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIAOYUAN'))
    end
if (PlotX==75 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUINAN'))
    end
if (PlotX==77 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGYU'))
    end
if (PlotX==79 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANTU'))
    end
if (PlotX==79 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANTU2'))
    end
if (PlotX==79 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANTU3'))
    end
if (PlotX==80 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HELONG'))
    end
if (PlotX==83 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FANGCHUAN'))
    end
if (PlotX==72 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIPING'))
    end
if (PlotX==73 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIPING2'))
    end
if (PlotX==73 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGLIAO'))
    end
if (PlotX==74 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YITONG'))
    end
if (PlotX==74 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YITONG2'))
    end
if (PlotX==75 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PANSHI'))
    end
if (PlotX==76 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUADIAN'))
    end
if (PlotX==78 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUADIAN2'))
    end
if (PlotX==77 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUSONG'))
    end
if (PlotX==78 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUSONG2'))
    end
if (PlotX==80 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANJI'))
    end
if (PlotX==80 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANJI2'))
    end
if (PlotX==71 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGLIAO'))
    end
if (PlotX==71 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGLIAO2'))
    end
if (PlotX==72 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LISHU'))
    end
if (PlotX==81 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMEN'))
    end
if (PlotX==82 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMEN2'))
    end
if (PlotX==82 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUNCHUN'))
    end
if (PlotX==83 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUNCHUN2'))
    end
if (PlotX==72 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGZHULING'))
    end
if (PlotX==73 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGZHULING2'))
    end
if (PlotX==76 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JILIN'))
    end
if (PlotX==75 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JILIN2'))
    end
if (PlotX==77 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAOHE'))
    end
if (PlotX==78 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIAOHE2'))
    end
if (PlotX==79 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUA'))
    end
if (PlotX==79 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUNHUA2'))
    end
if (PlotX==82 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WANGQING'))
    end
if (PlotX==71 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGLING'))
    end
if (PlotX==72 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGLING2'))
    end
if (PlotX==73 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIAN_GORLOS'))
    end
if (PlotX==73 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIAN_GORLOS2'))
    end
if (PlotX==74 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NONGAN'))
    end
if (PlotX==74 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NONGAN2'))
    end
if (PlotX==75 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEHUI'))
    end
if (PlotX==76 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHULAN'))
    end
if (PlotX==76 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHULAN2'))
    end
if (PlotX==69 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGYU'))
    end
if (PlotX==70 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGYU2'))
    end
if (PlotX==71 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIANAN'))
    end
if (PlotX==72 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIANAN2'))
    end
if (PlotX==73 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGYUAN'))
    end
if (PlotX==74 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONGYUAN2'))
    end
if (PlotX==75 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUSHU_JILIN'))
    end
if (PlotX==75 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYU_JILIN'))
    end
if (PlotX==70 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAONAN'))
    end
if (PlotX==71 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAONAN2'))
    end
if (PlotX==69 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAONAN3'))
    end
if (PlotX==72 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAAN'))
    end
if (PlotX==72 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAAN2'))
    end
if (PlotX==70 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAICHENG'))
    end
if (PlotX==71 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAICHENG2'))
    end
if (PlotX==71 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENLAI'))
    end
if (PlotX==72 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENLAI2'))
    end
if (PlotX==70 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENYANG'))
    end
if (PlotX==71 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENYANG2'))
    end
if (PlotX==70 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENYANG3'))
    end
if (PlotX==68 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LYUSHUN'))
    end
if (PlotX==69 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALIAN'))
    end
if (PlotX==70 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALIAN2'))
    end
if (PlotX==68 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WAFANGDIAN'))
    end
if (PlotX==69 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PULANDIAN'))
    end
if (PlotX==70 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUANGHE'))
    end
if (PlotX==71 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGGANG'))
    end
if (PlotX==72 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANDONG'))
    end
if (PlotX==73 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANDONG2'))
    end
if (PlotX==69 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYUQUAN'))
    end
if (PlotX==70 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAIZHOU'))
    end
if (PlotX==72 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGCHENG_LIAONING'))
    end
if (PlotX==73 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGCHENG_LIAONING2'))
    end
if (PlotX==66 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUIZHONG'))
    end
if (PlotX==69 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGKOU'))
    end
if (PlotX==70 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAICHENG'))
    end
if (PlotX==71 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIUYAN'))
    end
if (PlotX==73 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUANDIAN'))
    end
if (PlotX==74 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUANDIAN2'))
    end
if (PlotX==67 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HULUDAO'))
    end
if (PlotX==68 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINZHOU'))
    end
if (PlotX==69 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PANJIN'))
    end
if (PlotX==70 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANSHAN'))
    end
if (PlotX==71 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIAOYANG'))
    end
if (PlotX==72 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BENXI'))
    end
if (PlotX==71 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BENXI2'))
    end
if (PlotX==65 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HARQIN_ZUOYI'))
    end
if (PlotX==67 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YIXIAN_LN'))
    end
if (PlotX==68 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEIZHEN'))
    end
if (PlotX==69 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIAOZHONG'))
    end
if (PlotX==70 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DENGTA'))
    end
if (PlotX==73 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANREN'))
    end
if (PlotX==65 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINGYUAN'))
    end
if (PlotX==66 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAOYANG'))
    end
if (PlotX==67 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEIPIAO'))
    end
if (PlotX==69 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEISHAN'))
    end
if (PlotX==72 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUSHUN'))
    end
if (PlotX==73 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUSHUN2'))
    end
if (PlotX==74 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINBIN'))
    end
if (PlotX==65 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIANPING'))
    end
if (PlotX==67 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUXIN'))
    end
if (PlotX==69 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINMIN'))
    end
if (PlotX==71 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIELING'))
    end
if (PlotX==71 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIELING2'))
    end
if (PlotX==72 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAIYUAN'))
    end
if (PlotX==72 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAIYUAN2'))
    end
if (PlotX==73 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGYUAN_LIAONING'))
    end
if (PlotX==69 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHANGWU'))
    end
if (PlotX==70 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FAKU'))
    end
if (PlotX==73 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIFENG'))
    end
if (PlotX==71 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGTU'))
    end
if (PlotX==34 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINING'))
    end
if (PlotX==33 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUANGYUAN'))
    end
if (PlotX==34 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DATONG_XINING'))
    end
if (PlotX==35 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIDONG'))
    end
if (PlotX==36 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINHE'))
    end
if (PlotX==35 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUZHU'))
    end
if (PlotX==33 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIYAN'))
    end
if (PlotX==32 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAIYAN2'))
    end
if (PlotX==33 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MENYUAN'))
    end
if (PlotX==31 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANGCHA'))
    end
if (PlotX==30 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANGCA'))
    end
if (PlotX==30 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANGCA2'))
    end
if (PlotX==30 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QILIAN'))
    end
if (PlotX==29 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QILIAN2'))
    end
if (PlotX==28 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QILIAN3'))
    end
if (PlotX==32 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGHE'))
    end
if (PlotX==31 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGHE2'))
    end
if (PlotX==30 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGHE3'))
    end
if (PlotX==30 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGHE4'))
    end
if (PlotX==33 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGHE5'))
    end
if (PlotX==33 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGDE'))
    end
if (PlotX==34 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUINAN'))
    end
if (PlotX==35 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUIDE'))
    end
if (PlotX==31 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGHAI'))
    end
if (PlotX==32 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGHAI2'))
    end
if (PlotX==31 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGHAI3'))
    end
if (PlotX==32 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGHAI4'))
    end
if (PlotX==35 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGREN_QINGHAI'))
    end
if (PlotX==34 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAINCA'))
    end
if (PlotX==35 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZEKOG'))
    end
if (PlotX==31 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAQEN'))
    end
if (PlotX==32 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAQEN2'))
    end
if (PlotX==33 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAQEN3'))
    end
if (PlotX==34 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAQEN4'))
    end
if (PlotX==32 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADE'))
    end
if (PlotX==33 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADE2'))
    end
if (PlotX==33 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIMA'))
    end
if (PlotX==32 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIMA2'))
    end
if (PlotX==33 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIMA3'))
    end
if (PlotX==34 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIGZHI'))
    end
if (PlotX==34 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIGZHI2'))
    end
if (PlotX==31 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARLAG'))
    end
if (PlotX==30 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARLAG2'))
    end
if (PlotX==31 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARLAG3'))
    end
if (PlotX==32 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARLAG4'))
    end
if (PlotX==33 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARLAG5'))
    end
if (PlotX==30 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARLAG6'))
    end
if (PlotX==31 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARLAG7'))
    end
if (PlotX==29 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADOI'))
    end
if (PlotX==29 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADOI2'))
    end
if (PlotX==30 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADOI3'))
    end
if (PlotX==28 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADOI4'))
    end
if (PlotX==29 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADOI5'))
    end
if (PlotX==26 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA'))
    end
if (PlotX==27 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA2'))
    end
if (PlotX==26 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA3'))
    end
if (PlotX==27 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA4'))
    end
if (PlotX==28 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA5'))
    end
if (PlotX==25 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA6'))
    end
if (PlotX==26 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA7'))
    end
if (PlotX==27 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA8'))
    end
if (PlotX==26 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELINGHA9'))
    end
if (PlotX==23 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD'))
    end
if (PlotX==24 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD2'))
    end
if (PlotX==23 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD3'))
    end
if (PlotX==25 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD4'))
    end
if (PlotX==22 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD5'))
    end
if (PlotX==23 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD6'))
    end
if (PlotX==24 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD7'))
    end
if (PlotX==23 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLMUD8'))
    end
if (PlotX==27 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DULAN'))
    end
if (PlotX==28 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DULAN2'))
    end
if (PlotX==26 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DULAN3'))
    end
if (PlotX==27 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DULAN4'))
    end
if (PlotX==27 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DULAN5'))
    end
if (PlotX==26 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZONGJIA'))
    end
if (PlotX==25 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZONGJIA2'))
    end
if (PlotX==29 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAN'))
    end
if (PlotX==28 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAN2'))
    end
if (PlotX==29 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAN3'))
    end
if (PlotX==28 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAN4'))
    end
if (PlotX==28 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANJUN'))
    end
if (PlotX==29 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANJUN2'))
    end
if (PlotX==28 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TIANJUN3'))
    end
if (PlotX==26 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SULI'))
    end
if (PlotX==27 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SULI2'))
    end
if (PlotX==27 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SULI3'))
    end
if (PlotX==24 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XITIESHAN'))
    end
if (PlotX==25 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XITIESHAN2'))
    end
if (PlotX==23 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DA_QAIDAM'))
    end
if (PlotX==24 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DA_QAIDAM2'))
    end
if (PlotX==23 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DA_QAIDAM3'))
    end
if (PlotX==24 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DA_QAIDAM4'))
    end
if (PlotX==25 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DA_QAIDAM5'))
    end
if (PlotX==22 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGHU'))
    end
if (PlotX==21 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGHU2'))
    end
if (PlotX==22 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGHU3'))
    end
if (PlotX==21 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGHU4'))
    end
if (PlotX==22 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGHU5'))
    end
if (PlotX==20 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGHU6'))
    end
if (PlotX==21 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LENGHU7'))
    end
if (PlotX==19 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN'))
    end
if (PlotX==20 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN2'))
    end
if (PlotX==21 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN3'))
    end
if (PlotX==19 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN4'))
    end
if (PlotX==20 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN5'))
    end
if (PlotX==21 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN6'))
    end
if (PlotX==19 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN7'))
    end
if (PlotX==20 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN8'))
    end
if (PlotX==21 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTU_MEIREN9'))
    end
if (PlotX==19 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANGNAI'))
    end
if (PlotX==18 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANGNAI2'))
    end
if (PlotX==19 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANGNAI3'))
    end
if (PlotX==20 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANGNAI4'))
    end
if (PlotX==20 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANGNAI5'))
    end
if (PlotX==19 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANGNAI6'))
    end
if (PlotX==21 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA'))
    end
if (PlotX==22 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA2'))
    end
if (PlotX==19 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA3'))
    end
if (PlotX==20 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA4'))
    end
if (PlotX==21 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA5'))
    end
if (PlotX==22 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA6'))
    end
if (PlotX==20 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA7'))
    end
if (PlotX==21 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA8'))
    end
if (PlotX==22 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA9'))
    end
if (PlotX==20 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA10'))
    end
if (PlotX==21 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGGULA11'))
    end
if (PlotX==18 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GELADAINDONG'))
    end
if (PlotX==18 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GELADAINDONG2'))
    end
if (PlotX==19 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GELADAINDONG3'))
    end
if (PlotX==17 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GELADAINDONG4'))
    end
if (PlotX==18 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GELADAINDONG5'))
    end
if (PlotX==19 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GELADAINDONG6'))
    end
if (PlotX==26 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUSHU_QINGHAI'))
    end
if (PlotX==26 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUSHU_QINGHAI2'))
    end
if (PlotX==27 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUSHU_QINGHAI3'))
    end
if (PlotX==26 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUSHU_QINGHAI4'))
    end
if (PlotX==26 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUSHU_QINGHAI5'))
    end
if (PlotX==26 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANGQEN'))
    end
if (PlotX==26 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANGQEN2'))
    end
if (PlotX==23 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZADOI'))
    end
if (PlotX==24 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZADOI2'))
    end
if (PlotX==25 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZADOI3'))
    end
if (PlotX==23 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZADOI4'))
    end
if (PlotX==23 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIDOI'))
    end
if (PlotX==22 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIDOI2'))
    end
if (PlotX==24 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIDOI3'))
    end
if (PlotX==22 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIDOI4'))
    end
if (PlotX==23 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIDOI5'))
    end
if (PlotX==24 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHIDOI6'))
    end
if (PlotX==27 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHINDU'))
    end
if (PlotX==27 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHINDU2'))
    end
if (PlotX==26 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHINDU3'))
    end
if (PlotX==27 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHINDU4'))
    end
if (PlotX==27 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHINDU5'))
    end
if (PlotX==28 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHINDU6'))
    end
if (PlotX==26 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADUO'))
    end
if (PlotX==27 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADUO2'))
    end
if (PlotX==25 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB'))
    end
if (PlotX==25 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB2'))
    end
if (PlotX==26 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB3'))
    end
if (PlotX==23 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB4'))
    end
if (PlotX==24 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB5'))
    end
if (PlotX==25 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB6'))
    end
if (PlotX==24 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB7'))
    end
if (PlotX==25 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUMARLEB8'))
    end
if (PlotX==22 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUDONGQUAN'))
    end
if (PlotX==23 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUDONGQUAN2'))
    end
if (PlotX==20 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL'))
    end
if (PlotX==21 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL2'))
    end
if (PlotX==20 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL3'))
    end
if (PlotX==21 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL4'))
    end
if (PlotX==20 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL5'))
    end
if (PlotX==21 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL6'))
    end
if (PlotX==22 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL7'))
    end
if (PlotX==17 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE'))
    end
if (PlotX==18 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE2'))
    end
if (PlotX==19 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE3'))
    end
if (PlotX==17 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE4'))
    end
if (PlotX==18 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE5'))
    end
if (PlotX==19 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE6'))
    end
if (PlotX==17 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE7'))
    end
if (PlotX==18 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE8'))
    end
if (PlotX==19 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_LAKE9'))
    end
if (PlotX==19 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LHASA'))
    end
if (PlotX==18 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LHASA2'))
    end
if (PlotX==20 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAIZHOKUNGGAR'))
    end
if (PlotX==21 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAIZHOKUNGGAR2'))
    end
if (PlotX==17 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYEMO'))
    end
if (PlotX==17 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGBAJAIN'))
    end
if (PlotX==18 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANGBAJAIN2'))
    end
if (PlotX==19 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAMXUNG'))
    end
if (PlotX==20 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAMXUNG2'))
    end
if (PlotX==15 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIGATSE'))
    end
if (PlotX==16 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIGATSE2'))
    end
if (PlotX==17 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YADONG'))
    end
if (PlotX==13 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYALAM'))
    end
if (PlotX==16 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAMBA'))
    end
if (PlotX==17 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANGMAR'))
    end
if (PlotX==11 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GYIRONG'))
    end
if (PlotX==12 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GYIRONG2'))
    end
if (PlotX==14 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TINGRI'))
    end
if (PlotX==15 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGYA'))
    end
if (PlotX==16 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINANG'))
    end
if (PlotX==11 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGA_COUNTY'))
    end
if (PlotX==12 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGA_COUNTY2'))
    end
if (PlotX==12 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGA_COUNTY3'))
    end
if (PlotX==14 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LHATSE'))
    end
if (PlotX==17 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RINBUNG'))
    end
if (PlotX==15 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAMLING'))
    end
if (PlotX==16 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAMLING2'))
    end
if (PlotX==14 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAITONGMOIN'))
    end
if (PlotX==15 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAITONGMOIN2'))
    end
if (PlotX==13 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAMRING'))
    end
if (PlotX==13 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAMRING2'))
    end
if (PlotX==14 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAMRING3'))
    end
if (PlotX==13 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAMRING4'))
    end
if (PlotX==13 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAMRING5'))
    end
if (PlotX==14 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGAMRING6'))
    end
if (PlotX==11 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGBA'))
    end
if (PlotX==10 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGBA2'))
    end
if (PlotX==8 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGBA3'))
    end
if (PlotX==9 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGBA4'))
    end
if (PlotX==10 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHONGBA5'))
    end
if (PlotX==9 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNGGAR'))
    end
if (PlotX==10 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNGGAR2'))
    end
if (PlotX==9 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNGGAR3'))
    end
if (PlotX==20 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANNAN'))
    end
if (PlotX==18 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGARZE'))
    end
if (PlotX==19 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGGAR'))
    end
if (PlotX==21 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GYACA'))
    end
if (PlotX==19 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COMAI'))
    end
if (PlotX==20 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LHUNZE'))
    end
if (PlotX==21 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CONA'))
    end
if (PlotX==22 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CONA2'))
    end
if (PlotX==23 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CONA3'))
    end
if (PlotX==24 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYINGCHI'))
    end
if (PlotX==23 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYINGCHI2'))
    end
if (PlotX==22 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANG_COUNTY'))
    end
if (PlotX==23 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAINLING'))
    end
if (PlotX==22 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGBO_GYAMDA'))
    end
if (PlotX==23 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGBO_GYAMDA2'))
    end
if (PlotX==24 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGMAI'))
    end
if (PlotX==25 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOME'))
    end
if (PlotX==25 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEDOG'))
    end
if (PlotX==25 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEDOG2'))
    end
if (PlotX==23 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEDOG3'))
    end
if (PlotX==24 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEDOG4'))
    end
if (PlotX==25 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEDOG5'))
    end
if (PlotX==26 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAYU'))
    end
if (PlotX==26 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAYU2'))
    end
if (PlotX==27 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAMDO'))
    end
if (PlotX==26 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAMDO2'))
    end
if (PlotX==26 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAWU'))
    end
if (PlotX==27 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAXOI'))
    end
if (PlotX==28 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZOGANG'))
    end
if (PlotX==29 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MARKAM'))
    end
if (PlotX==27 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAMDA'))
    end
if (PlotX==28 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAGYAB'))
    end
if (PlotX==28 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JOMDA'))
    end
if (PlotX==26 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RIWOQE'))
    end
if (PlotX==25 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DENGQEN'))
    end
if (PlotX==24 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DENGQEN2'))
    end
if (PlotX==20 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGQU'))
    end
if (PlotX==21 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGQU2'))
    end
if (PlotX==20 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGQU3'))
    end
if (PlotX==21 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGQU4'))
    end
if (PlotX==21 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LHARI'))
    end
if (PlotX==22 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LHARI2'))
    end
if (PlotX==22 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIRU'))
    end
if (PlotX==22 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIRU2'))
    end
if (PlotX==23 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAQEN'))
    end
if (PlotX==22 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SOG_COUNTY'))
    end
if (PlotX==21 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYAINRONG'))
    end
if (PlotX==19 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO'))
    end
if (PlotX==20 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO2'))
    end
if (PlotX==19 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO3'))
    end
if (PlotX==20 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO4'))
    end
if (PlotX==21 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO5'))
    end
if (PlotX==18 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO6'))
    end
if (PlotX==19 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO7'))
    end
if (PlotX==20 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMDO8'))
    end
if (PlotX==18 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEWU'))
    end
if (PlotX==17 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEWU2'))
    end
if (PlotX==17 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEWU3'))
    end
if (PlotX==16 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DOKE_TSORING'))
    end
if (PlotX==16 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DOKE_TSORING2'))
    end
if (PlotX==16 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DOKE_TSORING3'))
    end
if (PlotX==16 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DOKE_TSORING4'))
    end
if (PlotX==16 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN'))
    end
if (PlotX==17 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN2'))
    end
if (PlotX==18 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN3'))
    end
if (PlotX==19 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN4'))
    end
if (PlotX==16 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN5'))
    end
if (PlotX==17 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN6'))
    end
if (PlotX==18 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN7'))
    end
if (PlotX==18 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAINGOIN8'))
    end
if (PlotX==14 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAINZA'))
    end
if (PlotX==15 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAINZA2'))
    end
if (PlotX==15 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAINZA3'))
    end
if (PlotX==16 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAINZA4'))
    end
if (PlotX==14 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAINZA5'))
    end
if (PlotX==15 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU'))
    end
if (PlotX==16 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU2'))
    end
if (PlotX==17 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU3'))
    end
if (PlotX==14 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU4'))
    end
if (PlotX==15 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU5'))
    end
if (PlotX==16 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU6'))
    end
if (PlotX==17 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU7'))
    end
if (PlotX==15 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU8'))
    end
if (PlotX==16 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU9'))
    end
if (PlotX==16 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGHU10'))
    end
if (PlotX==14 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARCO'))
    end
if (PlotX==14 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARCO2'))
    end
if (PlotX==16 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARCO3'))
    end
if (PlotX==15 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARCO4'))
    end
if (PlotX==14 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN'))
    end
if (PlotX==13 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN2'))
    end
if (PlotX==14 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN3'))
    end
if (PlotX==15 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN4'))
    end
if (PlotX==13 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN5'))
    end
if (PlotX==14 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN6'))
    end
if (PlotX==15 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN7'))
    end
if (PlotX==13 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN8'))
    end
if (PlotX==14 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN9'))
    end
if (PlotX==15 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOH_XIL_SHAN10'))
    end
if (PlotX==12 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA'))
    end
if (PlotX==12 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA2'))
    end
if (PlotX==13 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA3'))
    end
if (PlotX==14 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA4'))
    end
if (PlotX==11 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA5'))
    end
if (PlotX==12 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA6'))
    end
if (PlotX==13 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA7'))
    end
if (PlotX==12 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA8'))
    end
if (PlotX==13 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA9'))
    end
if (PlotX==14 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYIMA10'))
    end
if (PlotX==13 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RONGMA'))
    end
if (PlotX==14 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RONGMA2'))
    end
if (PlotX==13 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RONGMA3'))
    end
if (PlotX==13 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RONGMA4'))
    end
if (PlotX==6 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAR'))
    end
if (PlotX==7 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAR2'))
    end
if (PlotX==5 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAR3'))
    end
if (PlotX==5 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAR4'))
    end
if (PlotX==6 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUNSA'))
    end
if (PlotX==6 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUNSA2'))
    end
if (PlotX==7 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURANG'))
    end
if (PlotX==8 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURANG2'))
    end
if (PlotX==6 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURANG3'))
    end
if (PlotX==7 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURANG4'))
    end
if (PlotX==8 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURANG5'))
    end
if (PlotX==5 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZANDA'))
    end
if (PlotX==5 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZANDA2'))
    end
if (PlotX==6 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZANDA3'))
    end
if (PlotX==4 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZANDA4'))
    end
if (PlotX==5 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZANDA5'))
    end
if (PlotX==4 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZANDA6'))
    end
if (PlotX==11 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COQEN'))
    end
if (PlotX==11 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COQEN2'))
    end
if (PlotX==12 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COQEN3'))
    end
if (PlotX==10 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COQEN4'))
    end
if (PlotX==10 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COQEN5'))
    end
if (PlotX==11 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COQEN6'))
    end
if (PlotX==8 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEGYAI'))
    end
if (PlotX==7 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEGYAI2'))
    end
if (PlotX==8 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEGYAI3'))
    end
if (PlotX==8 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEGYAI4'))
    end
if (PlotX==9 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEGYAI5'))
    end
if (PlotX==7 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEGYAI6'))
    end
if (PlotX==8 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GEGYAI7'))
    end
if (PlotX==8 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAGRA'))
    end
if (PlotX==9 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAGRA2'))
    end
if (PlotX==9 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANHU'))
    end
if (PlotX==8 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANHU2'))
    end
if (PlotX==9 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GERZE'))
    end
if (PlotX==10 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GERZE2'))
    end
if (PlotX==10 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GERZE3'))
    end
if (PlotX==11 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GERZE4'))
    end
if (PlotX==11 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GERZE5'))
    end
if (PlotX==10 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GERZE6'))
    end
if (PlotX==11 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GERZE7'))
    end
if (PlotX==12 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOMO'))
    end
if (PlotX==12 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOMO2'))
    end
if (PlotX==12 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOMO3'))
    end
if (PlotX==11 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG'))
    end
if (PlotX==12 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG2'))
    end
if (PlotX==10 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG3'))
    end
if (PlotX==11 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG4'))
    end
if (PlotX==12 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG5'))
    end
if (PlotX==10 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG6'))
    end
if (PlotX==11 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG7'))
    end
if (PlotX==12 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG8'))
    end
if (PlotX==11 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG9'))
    end
if (PlotX==12 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHABUG10'))
    end
if (PlotX==9 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENCHEN'))
    end
if (PlotX==10 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENCHEN2'))
    end
if (PlotX==9 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENCHEN3'))
    end
if (PlotX==8 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENCHEN4'))
    end
if (PlotX==9 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENCHEN5'))
    end
if (PlotX==9 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHENCHEN6'))
    end
if (PlotX==4 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG'))
    end
if (PlotX==4 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG2'))
    end
if (PlotX==5 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG3'))
    end
if (PlotX==6 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG4'))
    end
if (PlotX==5 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG5'))
    end
if (PlotX==6 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG6'))
    end
if (PlotX==4 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG7'))
    end
if (PlotX==5 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUTOG8'))
    end
if (PlotX==7 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RABANG'))
    end
if (PlotX==8 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RABANG2'))
    end
if (PlotX==7 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUNGRU'))
    end
if (PlotX==7 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUNGRU2'))
    end
if (PlotX==5 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUNGRU3'))
    end
if (PlotX==6 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUNGRU4'))
    end
if (PlotX==7 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUNGRU5'))
    end
if (PlotX==8 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUNGRU6'))
    end
if (PlotX==52 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOHHOT'))
    end
if (PlotX==53 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOHHOT2'))
    end
if (PlotX==53 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOHHOT3'))
    end
if (PlotX==52 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGSHUIHE'))
    end
if (PlotX==52 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOGTOH'))
    end
if (PlotX==53 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORINGER'))
    end
if (PlotX==51 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMED_LEFT_BANNER'))
    end
if (PlotX==52 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMED_LEFT_BANNER2'))
    end
if (PlotX==52 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUCHUAN'))
    end
if (PlotX==48 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAOTOU'))
    end
if (PlotX==49 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAOTOU2'))
    end
if (PlotX==50 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMED_RIGHT_BANNER'))
    end
if (PlotX==50 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMED_RIGHT_BANNER2'))
    end
if (PlotX==48 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUYANG'))
    end
if (PlotX==48 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUYANG2'))
    end
if (PlotX==49 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUYANG3'))
    end
if (PlotX==47 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANOBO'))
    end
if (PlotX==48 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANOBO2'))
    end
if (PlotX==50 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARHAN_MUMINGGAN'))
    end
if (PlotX==51 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARHAN_MUMINGGAN2'))
    end
if (PlotX==48 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARHAN_MUMINGGAN3'))
    end
if (PlotX==49 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARHAN_MUMINGGAN4'))
    end
if (PlotX==50 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARHAN_MUMINGGAN5'))
    end
if (PlotX==49 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARHAN_MUMINGGAN6'))
    end
if (PlotX==50 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARHAN_MUMINGGAN7'))
    end
if (PlotX==55 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULANQAB'))
    end
if (PlotX==54 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIANGCHENG'))
    end
if (PlotX==55 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENGZHEN'))
    end
if (PlotX==54 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUOZI'))
    end
if (PlotX==53 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHUOZI2'))
    end
if (PlotX==55 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_FRONT_BANNER'))
    end
if (PlotX==56 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGHE'))
    end
if (PlotX==56 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGDU'))
    end
if (PlotX==56 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANGDU2'))
    end
if (PlotX==57 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUADE'))
    end
if (PlotX==53 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_MIDDLE_BANNER'))
    end
if (PlotX==54 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_MIDDLE_BANNER2'))
    end
if (PlotX==53 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_MIDDLE_BANNER3'))
    end
if (PlotX==55 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_REAR_BANNER'))
    end
if (PlotX==54 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_REAR_BANNER2'))
    end
if (PlotX==55 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_REAR_BANNER3'))
    end
if (PlotX==54 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAHAR_RIGHT_REAR_BANNER4'))
    end
if (PlotX==51 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER'))
    end
if (PlotX==52 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER2'))
    end
if (PlotX==51 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER3'))
    end
if (PlotX==52 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER4'))
    end
if (PlotX==53 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER5'))
    end
if (PlotX==50 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER6'))
    end
if (PlotX==51 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER7'))
    end
if (PlotX==52 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER8'))
    end
if (PlotX==53 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER9'))
    end
if (PlotX==52 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORBOD_BANNER10'))
    end
if (PlotX==43 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANNUR'))
    end
if (PlotX==44 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANNUR2'))
    end
if (PlotX==42 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DENGKOU'))
    end
if (PlotX==43 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_REAR_BANNER'))
    end
if (PlotX==45 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUYUAN_BAYANNUR'))
    end
if (PlotX==47 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_FRONT_BANNER'))
    end
if (PlotX==46 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_FRONT_BANNER2'))
    end
if (PlotX==47 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_FRONT_BANNER3'))
    end
if (PlotX==44 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_MIDDLE_BANNER'))
    end
if (PlotX==45 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_MIDDLE_BANNER2'))
    end
if (PlotX==46 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_MIDDLE_BANNER3'))
    end
if (PlotX==45 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_MIDDLE_BANNER4'))
    end
if (PlotX==46 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_MIDDLE_BANNER5'))
    end
if (PlotX==47 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_MIDDLE_BANNER6'))
    end
if (PlotX==44 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANQIMAODU'))
    end
if (PlotX==41 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER'))
    end
if (PlotX==42 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER2'))
    end
if (PlotX==41 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER3'))
    end
if (PlotX==42 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER4'))
    end
if (PlotX==41 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER5'))
    end
if (PlotX==42 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER6'))
    end
if (PlotX==43 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER7'))
    end
if (PlotX==43 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URAD_REAR_BANNER8'))
    end
if (PlotX==43 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUHAI'))
    end
if (PlotX==43 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUHAI2'))
    end
if (PlotX==44 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUHAI3'))
    end
if (PlotX==43 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUHAI4'))
    end
if (PlotX==49 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ORDOS'))
    end
if (PlotX==47 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ORDOS2'))
    end
if (PlotX==48 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ORDOS3'))
    end
if (PlotX==49 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ORDOS4'))
    end
if (PlotX==50 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUNGAR_BANNER'))
    end
if (PlotX==50 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUNGAR_BANNER2'))
    end
if (PlotX==51 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUNGAR_BANNER3'))
    end
if (PlotX==51 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUNGAR_BANNER4'))
    end
if (PlotX==43 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_FRONT_BANNER'))
    end
if (PlotX==44 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_FRONT_BANNER2'))
    end
if (PlotX==45 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_FRONT_BANNER3'))
    end
if (PlotX==44 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_FRONT_BANNER4'))
    end
if (PlotX==45 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_FRONT_BANNER5'))
    end
if (PlotX==46 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_FRONT_BANNER6'))
    end
if (PlotX==46 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UXIN_BANNER'))
    end
if (PlotX==47 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UXIN_BANNER2'))
    end
if (PlotX==47 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UXIN_BANNER3'))
    end
if (PlotX==48 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UXIN_BANNER4'))
    end
if (PlotX==46 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UXIN_BANNER5'))
    end
if (PlotX==47 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UXIN_BANNER6'))
    end
if (PlotX==44 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_BANNER'))
    end
if (PlotX==45 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_BANNER2'))
    end
if (PlotX==45 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_BANNER3'))
    end
if (PlotX==46 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_BANNER4'))
    end
if (PlotX==44 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_BANNER5'))
    end
if (PlotX==45 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_BANNER6'))
    end
if (PlotX==44 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTOG_BANNER7'))
    end
if (PlotX==48 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EJIN_HORO_BANNER'))
    end
if (PlotX==47 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EJIN_HORO_BANNER2'))
    end
if (PlotX==48 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EJIN_HORO_BANNER3'))
    end
if (PlotX==46 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER'))
    end
if (PlotX==45 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER2'))
    end
if (PlotX==46 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER3'))
    end
if (PlotX==47 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER4'))
    end
if (PlotX==44 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER5'))
    end
if (PlotX==45 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER6'))
    end
if (PlotX==46 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER7'))
    end
if (PlotX==45 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER8'))
    end
if (PlotX==46 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANGGIN_BANNER9'))
    end
if (PlotX==48 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALAD_BANNER'))
    end
if (PlotX==49 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALAD_BANNER2'))
    end
if (PlotX==50 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALAD_BANNER3'))
    end
if (PlotX==47 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALAD_BANNER4'))
    end
if (PlotX==48 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALAD_BANNER5'))
    end
if (PlotX==49 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALAD_BANNER6'))
    end
if (PlotX==43 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MENGXI'))
    end
if (PlotX==43 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALAGONG'))
    end
if (PlotX==44 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUHEMUTU'))
    end
if (PlotX==63 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIFENG'))
    end
if (PlotX==64 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIFENG2'))
    end
if (PlotX==65 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIFENG3'))
    end
if (PlotX==63 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HARQIN_BANNER'))
    end
if (PlotX==64 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINGCHENG'))
    end
if (PlotX==66 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AOHAN_BANNER'))
    end
if (PlotX==66 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AOHAN_BANNER2'))
    end
if (PlotX==62 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEXIGTEN_BANNER'))
    end
if (PlotX==61 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEXIGTEN_BANNER2'))
    end
if (PlotX==62 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEXIGTEN_BANNER3'))
    end
if (PlotX==62 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEXIGTEN_BANNER4'))
    end
if (PlotX==61 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEXIGTEN_BANNER5'))
    end
if (PlotX==63 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONGNIUD_BANNER'))
    end
if (PlotX==64 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONGNIUD_BANNER2'))
    end
if (PlotX==65 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONGNIUD_BANNER3'))
    end
if (PlotX==63 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIRIN_RIGHT_BANNER'))
    end
if (PlotX==64 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIRIN_RIGHT_BANNER2'))
    end
if (PlotX==65 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAIRIN_LEFT_BANNER'))
    end
if (PlotX==64 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LIAOSHANGJING'))
    end
if (PlotX==66 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AR_HORQIN_BANNER'))
    end
if (PlotX==65 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AR_HORQIN_BANNER2'))
    end
if (PlotX==65 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AR_HORQIN_BANNER3'))
    end
if (PlotX==62 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LINXI'))
    end
if (PlotX==68 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGLIAO'))
    end
if (PlotX==69 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONGLIAO2'))
    end
if (PlotX==67 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAIMAN_BANNER'))
    end
if (PlotX==66 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAIMAN_BANNER2'))
    end
if (PlotX==68 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HURE_BANNER'))
    end
if (PlotX==67 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HURE_BANNER2'))
    end
if (PlotX==68 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_BACK_BANNER'))
    end
if (PlotX==69 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_BACK_BANNER2'))
    end
if (PlotX==70 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_BACK_BANNER3'))
    end
if (PlotX==70 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_BACK_BANNER4'))
    end
if (PlotX==67 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAILU'))
    end
if (PlotX==67 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_MIDDLE_BANNER'))
    end
if (PlotX==68 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_MIDDLE_BANNER2'))
    end
if (PlotX==69 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_MIDDLE_BANNER3'))
    end
if (PlotX==70 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_MIDDLE_BANNER4'))
    end
if (PlotX==70 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_LEFT_MIDDLE_BANNER5'))
    end
if (PlotX==66 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARUD_BANNER'))
    end
if (PlotX==66 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARUD_BANNER2'))
    end
if (PlotX==67 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARUD_BANNER3'))
    end
if (PlotX==64 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOLINGOL'))
    end
if (PlotX==65 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOLINGOL2'))
    end
if (PlotX==69 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULANHOT'))
    end
if (PlotX==70 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULANHOT2'))
    end
if (PlotX==68 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_MIDDLE_BANNER'))
    end
if (PlotX==69 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_MIDDLE_BANNER2'))
    end
if (PlotX==66 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_MIDDLE_BANNER3'))
    end
if (PlotX==67 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_MIDDLE_BANNER4'))
    end
if (PlotX==68 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_MIDDLE_BANNER5'))
    end
if (PlotX==68 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUQUAN'))
    end
if (PlotX==69 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUQUAN2'))
    end
if (PlotX==67 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_FRONT_BANNER'))
    end
if (PlotX==65 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_FRONT_BANNER2'))
    end
if (PlotX==66 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_FRONT_BANNER3'))
    end
if (PlotX==67 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_FRONT_BANNER4'))
    end
if (PlotX==68 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HORQIN_RIGHT_FRONT_BANNER5'))
    end
if (PlotX==65 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARXAN'))
    end
if (PlotX==66 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARXAN2'))
    end
if (PlotX==67 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARXAN3'))
    end
if (PlotX==68 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALAID_BANNER'))
    end
if (PlotX==68 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALAID_BANNER2'))
    end
if (PlotX==69 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALAID_BANNER3'))
    end
if (PlotX==70 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALAID_BANNER4'))
    end
if (PlotX==65 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAILAR'))
    end
if (PlotX==64 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OLD_BARAG_BANNER'))
    end
if (PlotX==63 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANZHOULI'))
    end
if (PlotX==61 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_BARAG_RIGHT_BANNER'))
    end
if (PlotX==61 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_BARAG_RIGHT_BANNER2'))
    end
if (PlotX==62 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_BARAG_RIGHT_BANNER3'))
    end
if (PlotX==61 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_BARAG_RIGHT_BANNER4'))
    end
if (PlotX==64 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_BARAG_LEFT_BANNER'))
    end
if (PlotX==63 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_BARAG_LEFT_BANNER2'))
    end
if (PlotX==64 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NEW_BARAG_LEFT_BANNER3'))
    end
if (PlotX==65 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EWENKI_BANNER'))
    end
if (PlotX==65 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EWENKI_BANNER2'))
    end
if (PlotX==67 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZALANTUN'))
    end
if (PlotX==68 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZALANTUN2'))
    end
if (PlotX==69 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZALANTUN3'))
    end
if (PlotX==70 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZALANTUN4'))
    end
if (PlotX==68 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZALANTUN5'))
    end
if (PlotX==69 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARUN_BANNER'))
    end
if (PlotX==70 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARUN_BANNER2'))
    end
if (PlotX==60 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XILINHOT'))
    end
if (PlotX==59 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XILINHOT2'))
    end
if (PlotX==60 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XILINHOT3'))
    end
if (PlotX==60 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XILINHOT4'))
    end
if (PlotX==59 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIBUS_BANNER'))
    end
if (PlotX==60 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAIBUS_BANNER2'))
    end
if (PlotX==56 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGHUANG_BANNAR'))
    end
if (PlotX==57 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGHUANG_BANNAR2'))
    end
if (PlotX==56 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGHUANG_BANNAR3'))
    end
if (PlotX==57 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGHUANG_BANNAR4'))
    end
if (PlotX==58 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGXIANGBAI_BANNER'))
    end
if (PlotX==58 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGXIANGBAI_BANNER2'))
    end
if (PlotX==57 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGXIANGBAI_BANNER3'))
    end
if (PlotX==58 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGXIANGBAI_BANNER4'))
    end
if (PlotX==59 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGLAN_BANNER'))
    end
if (PlotX==59 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGLAN_BANNER2'))
    end
if (PlotX==59 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGLAN_BANNER3'))
    end
if (PlotX==60 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHENGLAN_BANNER4'))
    end
if (PlotX==60 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUOLUN'))
    end
if (PlotX==61 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUOLUN2'))
    end
if (PlotX==60 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUAN_SHANGDU'))
    end
if (PlotX==53 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERENHOT'))
    end
if (PlotX==54 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERENHOT2'))
    end
if (PlotX==53 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERENHOT3'))
    end
if (PlotX==55 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_RIGHT_BANNER'))
    end
if (PlotX==54 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_RIGHT_BANNER2'))
    end
if (PlotX==55 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_RIGHT_BANNER3'))
    end
if (PlotX==56 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_RIGHT_BANNER4'))
    end
if (PlotX==55 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_RIGHT_BANNER5'))
    end
if (PlotX==56 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_RIGHT_BANNER6'))
    end
if (PlotX==54 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_RIGHT_BANNER7'))
    end
if (PlotX==57 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_LEFT_BANNER'))
    end
if (PlotX==55 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_LEFT_BANNER2'))
    end
if (PlotX==56 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_LEFT_BANNER3'))
    end
if (PlotX==55 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_LEFT_BANNER4'))
    end
if (PlotX==56 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONID_LEFT_BANNER5'))
    end
if (PlotX==54 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAGAN_OBO'))
    end
if (PlotX==53 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAGAN_OBO2'))
    end
if (PlotX==54 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAGAN_OBO3'))
    end
if (PlotX==58 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER'))
    end
if (PlotX==59 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER2'))
    end
if (PlotX==57 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER3'))
    end
if (PlotX==58 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER4'))
    end
if (PlotX==57 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER5'))
    end
if (PlotX==58 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER6'))
    end
if (PlotX==59 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER7'))
    end
if (PlotX==57 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER8'))
    end
if (PlotX==58 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ABAG_BANNER9'))
    end
if (PlotX==59 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADABUQI'))
    end
if (PlotX==60 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADABUQI2'))
    end
if (PlotX==60 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADABUQI3'))
    end
if (PlotX==61 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADABUQI4'))
    end
if (PlotX==61 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEST_UJIMQIN_BANNER'))
    end
if (PlotX==62 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEST_UJIMQIN_BANNER2'))
    end
if (PlotX==61 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEST_UJIMQIN_BANNER3'))
    end
if (PlotX==62 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WEST_UJIMQIN_BANNER4'))
    end
if (PlotX==62 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_UJIMQIN_BANNER'))
    end
if (PlotX==63 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_UJIMQIN_BANNER2'))
    end
if (PlotX==64 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_UJIMQIN_BANNER3'))
    end
if (PlotX==63 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_UJIMQIN_BANNER4'))
    end
if (PlotX==64 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_UJIMQIN_BANNER5'))
    end
if (PlotX==40 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_LEFT_BANNER'))
    end
if (PlotX==41 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_LEFT_BANNER2'))
    end
if (PlotX==40 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_LEFT_BANNER3'))
    end
if (PlotX==41 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_LEFT_BANNER4'))
    end
if (PlotX==40 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_LEFT_BANNER5'))
    end
if (PlotX==41 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_LEFT_BANNER6'))
    end
if (PlotX==42 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBUH'))
    end
if (PlotX==41 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBUH2'))
    end
if (PlotX==42 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBUH3'))
    end
if (PlotX==42 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBUH4'))
    end
if (PlotX==38 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT'))
    end
if (PlotX==39 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT2'))
    end
if (PlotX==37 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT3'))
    end
if (PlotX==38 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT4'))
    end
if (PlotX==39 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT5'))
    end
if (PlotX==38 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT6'))
    end
if (PlotX==39 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT7'))
    end
if (PlotX==40 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT8'))
    end
if (PlotX==38 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT9'))
    end
if (PlotX==39 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TENGGER_DESERT10'))
    end
if (PlotX==40 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JILANTAI'))
    end
if (PlotX==40 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JILANTAI2'))
    end
if (PlotX==41 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JILANTAI3'))
    end
if (PlotX==40 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JILANTAI4'))
    end
if (PlotX==39 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_NUORIGONG'))
    end
if (PlotX==38 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_NUORIGONG2'))
    end
if (PlotX==39 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_NUORIGONG3'))
    end
if (PlotX==39 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_NUORIGONG4'))
    end
if (PlotX==39 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_NUORIGONG5'))
    end
if (PlotX==40 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGEN_SUMU'))
    end
if (PlotX==39 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGEN_SUMU2'))
    end
if (PlotX==40 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGEN_SUMU3'))
    end
if (PlotX==40 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINGEN_SUMU4'))
    end
if (PlotX==39 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WULIJI_SUMU'))
    end
if (PlotX==38 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WULIJI_SUMU2'))
    end
if (PlotX==38 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WULIJI_SUMU3'))
    end
if (PlotX==39 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WULIJI_SUMU4'))
    end
if (PlotX==37 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WULIJI_SUMU5'))
    end
if (PlotX==38 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WULIJI_SUMU6'))
    end
if (PlotX==34 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_RIGHT_BANNER'))
    end
if (PlotX==35 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_RIGHT_BANNER2'))
    end
if (PlotX==34 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_RIGHT_BANNER3'))
    end
if (PlotX==35 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALXA_RIGHT_BANNER4'))
    end
if (PlotX==34 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT'))
    end
if (PlotX==35 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT2'))
    end
if (PlotX==34 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT3'))
    end
if (PlotX==35 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT4'))
    end
if (PlotX==36 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT5'))
    end
if (PlotX==33 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT6'))
    end
if (PlotX==34 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT7'))
    end
if (PlotX==35 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT8'))
    end
if (PlotX==36 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT9'))
    end
if (PlotX==35 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT10'))
    end
if (PlotX==36 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BADAIN_JARAN_DESERT11'))
    end
if (PlotX==36 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YABULAI'))
    end
if (PlotX==37 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YABULAI2'))
    end
if (PlotX==36 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YABULAI3'))
    end
if (PlotX==33 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGCHAOGE_SUMU'))
    end
if (PlotX==31 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGCHAOGE_SUMU2'))
    end
if (PlotX==32 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGCHAOGE_SUMU3'))
    end
if (PlotX==33 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGCHAOGE_SUMU4'))
    end
if (PlotX==32 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGCHAOGE_SUMU5'))
    end
if (PlotX==33 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGCHAOGE_SUMU6'))
    end
if (PlotX==38 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDELA_SUMU'))
    end
if (PlotX==37 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDELA_SUMU2'))
    end
if (PlotX==37 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDELA_SUMU3'))
    end
if (PlotX==38 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGAOBAO'))
    end
if (PlotX==37 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGAOBAO2'))
    end
if (PlotX==38 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGAOBAO3'))
    end
if (PlotX==37 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGAOBAO4'))
    end
if (PlotX==38 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALATENGAOBAO5'))
    end
if (PlotX==36 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TALMUSUBULAGE_SUMU'))
    end
if (PlotX==37 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TALMUSUBULAGE_SUMU2'))
    end
if (PlotX==37 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TALMUSUBULAGE_SUMU3'))
    end
if (PlotX==36 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TALMUSUBULAGE_SUMU4'))
    end
if (PlotX==32 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EJIN_BANNER'))
    end
if (PlotX==33 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EJIN_BANNER2'))
    end
if (PlotX==32 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EJIN_BANNER3'))
    end
if (PlotX==31 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGFENG_TOWN'))
    end
if (PlotX==32 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DONGFENG_TOWN2'))
    end
if (PlotX==34 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTAOLAI_SUMU'))
    end
if (PlotX==34 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUBONAOER_SUMU'))
    end
if (PlotX==33 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CEKE'))
    end
if (PlotX==34 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CEKE2'))
    end
if (PlotX==34 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUWENTUGAOLE_SUMU'))
    end
if (PlotX==35 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUWENTUGAOLE_SUMU2'))
    end
if (PlotX==35 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUWENTUGAOLE_SUMU3'))
    end
if (PlotX==36 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUWENTUGAOLE_SUMU4'))
    end
if (PlotX==35 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUWENTUGAOLE_SUMU5'))
    end
if (PlotX==32 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURANAY'))
    end
if (PlotX==33 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURANAY2'))
    end
if (PlotX==34 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURANAY3'))
    end
if (PlotX==33 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURANAY4'))
    end
if (PlotX==31 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIHANTAOLAI_SUMU'))
    end
if (PlotX==30 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIHANTAOLAI_SUMU2'))
    end
if (PlotX==31 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIHANTAOLAI_SUMU3'))
    end
if (PlotX==31 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIHANTAOLAI_SUMU4'))
    end
if (PlotX==32 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIHANTAOLAI_SUMU5'))
    end
if (PlotX==29 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN_SUMU'))
    end
if (PlotX==30 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN_SUMU2'))
    end
if (PlotX==28 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN_SUMU3'))
    end
if (PlotX==29 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN_SUMU4'))
    end
if (PlotX==30 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZONGSHAN_SUMU5'))
    end
if (PlotX==29 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEIYINGSHAN'))
    end
if (PlotX==30 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEIYINGSHAN2'))
    end
if (PlotX==28 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEIYINGSHAN3'))
    end
if (PlotX==29 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEIYINGSHAN4'))
    end
if (PlotX==28 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEIYINGSHAN5'))
    end
if (PlotX==29 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEIYINGSHAN6'))
    end
if (PlotX==30 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEIYINGSHAN7'))
    end
if (PlotX==15 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URUMQI'))
    end
if (PlotX==14 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URUMQI2'))
    end
if (PlotX==15 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URUMQI3'))
    end
if (PlotX==16 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URUMQI4'))
    end
if (PlotX==14 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URUMQI5'))
    end
if (PlotX==15 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URUMQI6'))
    end
if (PlotX==16 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URUMQI7'))
    end
if (PlotX==16 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DABANCHENG'))
    end
if (PlotX==17 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DABANCHENG2'))
    end
if (PlotX==13 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGJI'))
    end
if (PlotX==14 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGJI2'))
    end
if (PlotX==14 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANGJI3'))
    end
if (PlotX==15 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WUJIAQU'))
    end
if (PlotX==13 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIHEZI'))
    end
if (PlotX==13 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIHEZI2'))
    end
if (PlotX==16 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUKANG'))
    end
if (PlotX==17 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUKANG2'))
    end
if (PlotX==17 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIMSAR'))
    end
if (PlotX==18 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JIMSAR2'))
    end
if (PlotX==18 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QITAI'))
    end
if (PlotX==19 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QITAI2'))
    end
if (PlotX==19 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORI'))
    end
if (PlotX==20 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORI2'))
    end
if (PlotX==20 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORI3'))
    end
if (PlotX==6 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOLE'))
    end
if (PlotX==6 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOLE2'))
    end
if (PlotX==7 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOLE3'))
    end
if (PlotX==5 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WENQUAN'))
    end
if (PlotX==8 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALASHANKOU'))
    end
if (PlotX==9 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALASHANKOU2'))
    end
if (PlotX==8 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGHE'))
    end
if (PlotX==9 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGHE2'))
    end
if (PlotX==9 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINGHE3'))
    end
if (PlotX==7 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINING'))
    end
if (PlotX==8 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINING2'))
    end
if (PlotX==7 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YINING3'))
    end
if (PlotX==6 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUOCHENG'))
    end
if (PlotX==5 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORGAS'))
    end
if (PlotX==6 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAPQAL'))
    end
if (PlotX==7 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAPQAL2'))
    end
if (PlotX==8 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGLIU'))
    end
if (PlotX==9 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONGLIU2'))
    end
if (PlotX==9 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NILKA'))
    end
if (PlotX==10 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NILKA2'))
    end
if (PlotX==11 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NILKA3'))
    end
if (PlotX==9 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYUAN'))
    end
if (PlotX==10 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYUAN2'))
    end
if (PlotX==11 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINYUAN3'))
    end
if (PlotX==8 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TEKES'))
    end
if (PlotX==9 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TEKES2'))
    end
if (PlotX==7 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAOSU'))
    end
if (PlotX==10 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TACHENG'))
    end
if (PlotX==10 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TACHENG2'))
    end
if (PlotX==9 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUMIN'))
    end
if (PlotX==11 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EMIN'))
    end
if (PlotX==12 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EMIN2'))
    end
if (PlotX==11 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EMIN3'))
    end
if (PlotX==10 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOLI'))
    end
if (PlotX==11 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOLI2'))
    end
if (PlotX==10 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOLI3'))
    end
if (PlotX==11 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOLI4'))
    end
if (PlotX==12 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAMAY'))
    end
if (PlotX==12 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAMAY2'))
    end
if (PlotX==12 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAWAN'))
    end
if (PlotX==11 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUYTUN'))
    end
if (PlotX==11 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUSHANZI'))
    end
if (PlotX==10 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_USU'))
    end
if (PlotX==10 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_USU2'))
    end
if (PlotX==12 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOBOKSAR'))
    end
if (PlotX==13 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOBOKSAR2'))
    end
if (PlotX==14 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOBOKSAR3'))
    end
if (PlotX==13 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOBOKSAR4'))
    end
if (PlotX==14 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOBOKSAR5'))
    end
if (PlotX==13 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOBOKSAR6'))
    end
if (PlotX==14 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOBOKSAR7'))
    end
if (PlotX==15 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAY'))
    end
if (PlotX==16 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAY2'))
    end
if (PlotX==17 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAY3'))
    end
if (PlotX==15 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAY4'))
    end
if (PlotX==16 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAY5'))
    end
if (PlotX==13 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HABAHE'))
    end
if (PlotX==13 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JEMINAY'))
    end
if (PlotX==13 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JEMINAY2'))
    end
if (PlotX==14 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURQIN'))
    end
if (PlotX==14 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURQIN2'))
    end
if (PlotX==15 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEITUN'))
    end
if (PlotX==16 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUHAI'))
    end
if (PlotX==15 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUHAI2'))
    end
if (PlotX==16 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUHAI3'))
    end
if (PlotX==15 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUHAI4'))
    end
if (PlotX==15 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUHAI5'))
    end
if (PlotX==16 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUHAI6'))
    end
if (PlotX==18 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOKTOKAY'))
    end
if (PlotX==17 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN'))
    end
if (PlotX==17 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN2'))
    end
if (PlotX==18 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN3'))
    end
if (PlotX==16 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN4'))
    end
if (PlotX==17 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN5'))
    end
if (PlotX==18 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN6'))
    end
if (PlotX==17 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN7'))
    end
if (PlotX==18 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FUYUN8'))
    end
if (PlotX==19 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGGIL'))
    end
if (PlotX==19 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGGIL2'))
    end
if (PlotX==20 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGGIL3'))
    end
if (PlotX==19 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGGIL4'))
    end
if (PlotX==19 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGGIL5'))
    end
if (PlotX==20 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QINGGIL6'))
    end
if (PlotX==15 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURBANTUNGGUT'))
    end
if (PlotX==16 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURBANTUNGGUT2'))
    end
if (PlotX==17 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURBANTUNGGUT3'))
    end
if (PlotX==18 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURBANTUNGGUT4'))
    end
if (PlotX==18 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TURPAN'))
    end
if (PlotX==19 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TURPAN2'))
    end
if (PlotX==18 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TURPAN3'))
    end
if (PlotX==18 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TURPAN4'))
    end
if (PlotX==18 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TURPAN5'))
    end
if (PlotX==17 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKSUN'))
    end
if (PlotX==17 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKSUN2'))
    end
if (PlotX==17 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKSUN3'))
    end
if (PlotX==17 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKSUN4'))
    end
if (PlotX==19 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANSHAN'))
    end
if (PlotX==20 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANSHAN2'))
    end
if (PlotX==19 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANSHAN3'))
    end
if (PlotX==20 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANSHAN4'))
    end
if (PlotX==19 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANSHAN5'))
    end
if (PlotX==20 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANSHAN6'))
    end
if (PlotX==20 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHANSHAN7'))
    end
if (PlotX==21 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI'))
    end
if (PlotX==22 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI2'))
    end
if (PlotX==21 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI3'))
    end
if (PlotX==22 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI4'))
    end
if (PlotX==21 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI5'))
    end
if (PlotX==22 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI6'))
    end
if (PlotX==23 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI7'))
    end
if (PlotX==20 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI8'))
    end
if (PlotX==21 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI9'))
    end
if (PlotX==22 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAMI10'))
    end
if (PlotX==21 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAMANSU'))
    end
if (PlotX==22 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAMANSU2'))
    end
if (PlotX==23 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAMANSU3'))
    end
if (PlotX==23 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGXINGXIA'))
    end
if (PlotX==23 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGXINGXIA2'))
    end
if (PlotX==24 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGXINGXIA3'))
    end
if (PlotX==23 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XINGXINGXIA4'))
    end
if (PlotX==25 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGJINGZI'))
    end
if (PlotX==24 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGJINGZI2'))
    end
if (PlotX==24 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGJINGZI3'))
    end
if (PlotX==25 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHUANGJINGZI4'))
    end
if (PlotX==21 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARKOL'))
    end
if (PlotX==20 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARKOL2'))
    end
if (PlotX==21 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARKOL3'))
    end
if (PlotX==21 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARKOL4'))
    end
if (PlotX==22 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARKOL5'))
    end
if (PlotX==22 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARATURUK'))
    end
if (PlotX==23 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARATURUK2'))
    end
if (PlotX==24 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARATURUK3'))
    end
if (PlotX==0 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KASHGAR'))
    end
if (PlotX==0 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KASHGAR2'))
    end
if (PlotX==1 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KASHGAR3'))
    end
if (PlotX==1 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YENGISAR'))
    end
if (PlotX==1 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHULE'))
    end
if (PlotX==2 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHULE2'))
    end
if (PlotX==2 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YOPURGA'))
    end
if (PlotX==2 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAYZAWAT'))
    end
if (PlotX==3 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAYZAWAT2'))
    end
if (PlotX==1 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YARKANT'))
    end
if (PlotX==1 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YARKANT2'))
    end
if (PlotX==2 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YARKANT3'))
    end
if (PlotX==3 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YARKANT4'))
    end
if (PlotX==3 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YARKANT5'))
    end
if (PlotX==2 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POSKAM'))
    end
if (PlotX==2 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARGILIK'))
    end
if (PlotX==2 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARGILIK2'))
    end
if (PlotX==3 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARGILIK3'))
    end
if (PlotX==4 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARGILIK4'))
    end
if (PlotX==2 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIXSHU'))
    end
if (PlotX==2 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIXSHU2'))
    end
if (PlotX==1 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAXKORGAN'))
    end
if (PlotX==3 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAKIT'))
    end
if (PlotX==4 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAKIT2'))
    end
if (PlotX==4 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAKIT3'))
    end
if (PlotX==5 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAKIT4'))
    end
if (PlotX==3 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MARALBEXI'))
    end
if (PlotX==5 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MARALBEXI2'))
    end
if (PlotX==4 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MARALBEXI3'))
    end
if (PlotX==5 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MARALBEXI4'))
    end
if (PlotX==4 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MARALBEXI5'))
    end
if (PlotX==5 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MARALBEXI6'))
    end
if (PlotX==4 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMXUK'))
    end
if (PlotX==1 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARTUX'))
    end
if (PlotX==2 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARTUX2'))
    end
if (PlotX==1 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARTUX3'))
    end
if (PlotX==2 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARTUX4'))
    end
if (PlotX==0 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKTO'))
    end
if (PlotX==0 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULUGQAT'))
    end
if (PlotX==0 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULUGQAT2'))
    end
if (PlotX==3 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKQI'))
    end
if (PlotX==3 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKQI2'))
    end
if (PlotX==5 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN'))
    end
if (PlotX==6 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN2'))
    end
if (PlotX==6 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN3'))
    end
if (PlotX==6 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN4'))
    end
if (PlotX==7 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN5'))
    end
if (PlotX==6 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN_COUNTY'))
    end
if (PlotX==4 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN_COUNTY2'))
    end
if (PlotX==5 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN_COUNTY3'))
    end
if (PlotX==6 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOTAN_COUNTY4'))
    end
if (PlotX==3 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN'))
    end
if (PlotX==4 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN2'))
    end
if (PlotX==3 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN3'))
    end
if (PlotX==4 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN4'))
    end
if (PlotX==5 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN5'))
    end
if (PlotX==2 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN6'))
    end
if (PlotX==3 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN7'))
    end
if (PlotX==5 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSAI_CHIN8'))
    end
if (PlotX==3 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PISHAN'))
    end
if (PlotX==3 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PISHAN2'))
    end
if (PlotX==4 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PISHAN3'))
    end
if (PlotX==3 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PISHAN4'))
    end
if (PlotX==4 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PISHAN5'))
    end
if (PlotX==2 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAIDULLA'))
    end
if (PlotX==3 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAIDULLA2'))
    end
if (PlotX==5 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKAX'))
    end
if (PlotX==5 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKAX2'))
    end
if (PlotX==5 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKAX3'))
    end
if (PlotX==6 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKAX4'))
    end
if (PlotX==5 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKAX5'))
    end
if (PlotX==6 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKAX6'))
    end
if (PlotX==7 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOP'))
    end
if (PlotX==7 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOP2'))
    end
if (PlotX==8 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOP3'))
    end
if (PlotX==7 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOP4'))
    end
if (PlotX==6 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZARTAG'))
    end
if (PlotX==7 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZARTAG2'))
    end
if (PlotX==8 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZARTAG3'))
    end
if (PlotX==6 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZARTAG4'))
    end
if (PlotX==7 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAZARTAG5'))
    end
if (PlotX==7 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIRA'))
    end
if (PlotX==8 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIRA2'))
    end
if (PlotX==7 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIRA3'))
    end
if (PlotX==8 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIRA4'))
    end
if (PlotX==8 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIRA5'))
    end
if (PlotX==7 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_YURUNGKASH'))
    end
if (PlotX==7 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_YURUNGKASH2'))
    end
if (PlotX==8 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_EAST_YURUNGKASH3'))
    end
if (PlotX==9 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUMBULAK_KUM'))
    end
if (PlotX==8 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUMBULAK_KUM2'))
    end
if (PlotX==9 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUMBULAK_KUM3'))
    end
if (PlotX==8 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUMBULAK_KUM4'))
    end
if (PlotX==9 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUTIAN'))
    end
if (PlotX==8 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUTIAN2'))
    end
if (PlotX==9 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUTIAN3'))
    end
if (PlotX==9 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUTIAN4'))
    end
if (PlotX==10 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUTIAN5'))
    end
if (PlotX==9 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YUTIAN6'))
    end
if (PlotX==10 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARYA_BOYI'))
    end
if (PlotX==9 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARYA_BOYI2'))
    end
if (PlotX==10 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARYA_BOYI3'))
    end
if (PlotX==9 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARYA_BOYI4'))
    end
if (PlotX==9 and PlotY==35) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQAN'))
    end
if (PlotX==9 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQAN2'))
    end
if (PlotX==9 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQAN3'))
    end
if (PlotX==10 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQAN4'))
    end
if (PlotX==10 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIYA'))
    end
if (PlotX==11 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIYA2'))
    end
if (PlotX==11 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIYA3'))
    end
if (PlotX==10 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIYA4'))
    end
if (PlotX==11 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIYA5'))
    end
if (PlotX==12 and PlotY==36) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YEYIK'))
    end
if (PlotX==11 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YEYIK2'))
    end
if (PlotX==12 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YEYIK3'))
    end
if (PlotX==11 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANDIR'))
    end
if (PlotX==10 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANDIR2'))
    end
if (PlotX==5 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU'))
    end
if (PlotX==6 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU2'))
    end
if (PlotX==6 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU3'))
    end
if (PlotX==7 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU4'))
    end
if (PlotX==8 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU5'))
    end
if (PlotX==9 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU_SOUTH'))
    end
if (PlotX==8 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU_SOUTH2'))
    end
if (PlotX==9 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSU_SOUTH3'))
    end
if (PlotX==7 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARAL'))
    end
if (PlotX==8 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARAL2'))
    end
if (PlotX==8 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARAL3'))
    end
if (PlotX==9 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARAL4'))
    end
if (PlotX==6 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AWAT'))
    end
if (PlotX==7 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AWAT2'))
    end
if (PlotX==8 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AWAT3'))
    end
if (PlotX==6 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AWAT4'))
    end
if (PlotX==7 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AWAT5'))
    end
if (PlotX==6 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AWAT6'))
    end
if (PlotX==7 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AWAT7'))
    end
if (PlotX==4 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KALPIN'))
    end
if (PlotX==5 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KALPIN2'))
    end
if (PlotX==4 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UQTURPAN'))
    end
if (PlotX==5 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UQTURPAN2'))
    end
if (PlotX==5 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONSU'))
    end
if (PlotX==6 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONSU2'))
    end
if (PlotX==6 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONSU3'))
    end
if (PlotX==7 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAY_COUNTY'))
    end
if (PlotX==8 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAY_COUNTY2'))
    end
if (PlotX==8 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAY_COUNTY3'))
    end
if (PlotX==9 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOKSU'))
    end
if (PlotX==10 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUQA'))
    end
if (PlotX==11 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUQA2'))
    end
if (PlotX==9 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUQA3'))
    end
if (PlotX==10 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUQA4'))
    end
if (PlotX==10 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYAR'))
    end
if (PlotX==11 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYAR2'))
    end
if (PlotX==10 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYAR3'))
    end
if (PlotX==10 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYAR4'))
    end
if (PlotX==11 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYAR5'))
    end
if (PlotX==9 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYAR6'))
    end
if (PlotX==10 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYAR7'))
    end
if (PlotX==13 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORLA'))
    end
if (PlotX==14 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORLA2'))
    end
if (PlotX==13 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORLA3'))
    end
if (PlotX==14 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORLA4'))
    end
if (PlotX==13 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANQI'))
    end
if (PlotX==14 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YANQI2'))
    end
if (PlotX==12 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEJING'))
    end
if (PlotX==13 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEJING2'))
    end
if (PlotX==14 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEJING3'))
    end
if (PlotX==15 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HEJING4'))
    end
if (PlotX==12 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANBULAK'))
    end
if (PlotX==12 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANBULAK2'))
    end
if (PlotX==10 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANBULAK3'))
    end
if (PlotX==12 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNTAI'))
    end
if (PlotX==11 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNTAI2'))
    end
if (PlotX==12 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNTAI3'))
    end
if (PlotX==11 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNTAI4'))
    end
if (PlotX==12 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNTAI5'))
    end
if (PlotX==15 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAGRAX'))
    end
if (PlotX==15 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAGRAX2'))
    end
if (PlotX==16 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOXUD'))
    end
if (PlotX==16 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOXUD2'))
    end
if (PlotX==16 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOXUD3'))
    end
if (PlotX==16 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOXUD4'))
    end
if (PlotX==15 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI'))
    end
if (PlotX==16 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI2'))
    end
if (PlotX==14 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI3'))
    end
if (PlotX==15 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI4'))
    end
if (PlotX==16 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI5'))
    end
if (PlotX==14 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI6'))
    end
if (PlotX==15 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI7'))
    end
if (PlotX==16 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YULI8'))
    end
if (PlotX==12 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAERQUGA'))
    end
if (PlotX==13 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAERQUGA2'))
    end
if (PlotX==14 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAERQUGA3'))
    end
if (PlotX==11 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAERQUGA4'))
    end
if (PlotX==12 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAERQUGA5'))
    end
if (PlotX==13 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAERQUGA6'))
    end
if (PlotX==13 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAERQUGA7'))
    end
if (PlotX==17 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSOPI'))
    end
if (PlotX==18 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSOPI2'))
    end
if (PlotX==17 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSOPI3'))
    end
if (PlotX==18 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKSOPI4'))
    end
if (PlotX==12 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN'))
    end
if (PlotX==13 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN2'))
    end
if (PlotX==14 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN3'))
    end
if (PlotX==11 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN4'))
    end
if (PlotX==12 and PlotY==41) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN5'))
    end
if (PlotX==12 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN6'))
    end
if (PlotX==13 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN7'))
    end
if (PlotX==14 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN8'))
    end
if (PlotX==12 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QARQAN9'))
    end
if (PlotX==13 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUZTAGH'))
    end
if (PlotX==14 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUZTAGH2'))
    end
if (PlotX==14 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUZTAGH3'))
    end
if (PlotX==11 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TATIRANG'))
    end
if (PlotX==13 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TATIRANG2'))
    end
if (PlotX==12 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TATIRANG3'))
    end
if (PlotX==13 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TATIRANG4'))
    end
if (PlotX==14 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TATIRANG5'))
    end
if (PlotX==13 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TATIRANG6'))
    end
if (PlotX==11 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG'))
    end
if (PlotX==12 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG2'))
    end
if (PlotX==12 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG3'))
    end
if (PlotX==13 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG4'))
    end
if (PlotX==14 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG5'))
    end
if (PlotX==11 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG6'))
    end
if (PlotX==12 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG7'))
    end
if (PlotX==13 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAZHONG8'))
    end
if (PlotX==15 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK'))
    end
if (PlotX==16 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK2'))
    end
if (PlotX==15 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK3'))
    end
if (PlotX==16 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK4'))
    end
if (PlotX==17 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK5'))
    end
if (PlotX==14 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK6'))
    end
if (PlotX==16 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK7'))
    end
if (PlotX==15 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK8'))
    end
if (PlotX==16 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK9'))
    end
if (PlotX==17 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QAKILIK10'))
    end
if (PlotX==14 and PlotY==43) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WAXXARI'))
    end
if (PlotX==15 and PlotY==42) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WAXXARI2'))
    end
if (PlotX==18 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIRAN'))
    end
if (PlotX==19 and PlotY==44) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIRAN2'))
    end
if (PlotX==17 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIRAN3'))
    end
if (PlotX==18 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIRAN4'))
    end
if (PlotX==14 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAER_DABAN'))
    end
if (PlotX==15 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAER_DABAN2'))
    end
if (PlotX==16 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAER_DABAN3'))
    end
if (PlotX==18 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRORAN'))
    end
if (PlotX==17 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRORAN2'))
    end
if (PlotX==18 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRORAN3'))
    end
if (PlotX==17 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRORAN4'))
    end
if (PlotX==18 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRORAN5'))
    end
if (PlotX==19 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRORAN6'))
    end
if (PlotX==19 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR'))
    end
if (PlotX==20 and PlotY==45) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR2'))
    end
if (PlotX==20 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR3'))
    end
if (PlotX==21 and PlotY==46) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR4'))
    end
if (PlotX==20 and PlotY==47) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR5'))
    end
if (PlotX==20 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR6'))
    end
if (PlotX==21 and PlotY==48) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR7'))
    end
if (PlotX==19 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR_NORTH'))
    end
if (PlotX==20 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR_NORTH2'))
    end
if (PlotX==21 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR_NORTH3'))
    end
if (PlotX==19 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR_NORTH4'))
    end
if (PlotX==20 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR_NORTH5'))
    end
if (PlotX==21 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR_NORTH6'))
    end
if (PlotX==22 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOPNUR_NORTH7'))
    end
if (PlotX==16 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOMURLUK'))
    end
if (PlotX==16 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOMURLUK2'))
    end
if (PlotX==17 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOMURLUK3'))
    end
if (PlotX==18 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOMURLUK4'))
    end
if (PlotX==15 and PlotY==40) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOMURLUK5'))
    end
if (PlotX==17 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIMANTAG'))
    end
if (PlotX==18 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIMANTAG2'))
    end
if (PlotX==17 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIMANTAG3'))
    end
if (PlotX==18 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIMANTAG4'))
    end
if (PlotX==18 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QIMANTAG5'))
    end
if (PlotX==15 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQIKKOL'))
    end
if (PlotX==16 and PlotY==37) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQIKKOL2'))
    end
if (PlotX==15 and PlotY==38) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQIKKOL3'))
    end
if (PlotX==15 and PlotY==39) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AQQIKKOL4'))
    end
if (PlotX==12 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KATHMANDU'))
    end
if (PlotX==13 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KATHMANDU2'))
    end
if (PlotX==13 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JANAKPUR'))
    end
if (PlotX==14 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIRATNAGAR'))
    end
if (PlotX==11 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIRGUNJ'))
    end
if (PlotX==12 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIRGUNJ2'))
    end
if (PlotX==13 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUKLA'))
    end
if (PlotX==14 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ILAM'))
    end
if (PlotX==8 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TULSIPUR'))
    end
if (PlotX==9 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEUKHURI'))
    end
if (PlotX==10 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUTWAL'))
    end
if (PlotX==11 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHARATPUR_NEPAL'))
    end
if (PlotX==6 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHANGADHI'))
    end
if (PlotX==7 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIRENDRANAGAR'))
    end
if (PlotX==8 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JUMLA'))
    end
if (PlotX==9 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_POKHARA'))
    end
if (PlotX==7 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAINPUR'))
    end
if (PlotX==17 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THIMPHU'))
    end
if (PlotX==18 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THIMPHU2'))
    end
if (PlotX==19 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TRONGSA'))
    end
if (PlotX==20 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TRASHIGANG'))
    end
if (PlotX==19 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHAKA'))
    end
if (PlotX==17 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PORT_OF_MONGLA'))
    end
if (PlotX==18 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PATUAKHALI'))
    end
if (PlotX==21 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COXS_BAZAR'))
    end
if (PlotX==16 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHULNA'))
    end
if (PlotX==17 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHULNA2'))
    end
if (PlotX==18 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARISAL'))
    end
if (PlotX==21 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHITTAGONG'))
    end
if (PlotX==17 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JASHORE'))
    end
if (PlotX==18 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MADARIPUR'))
    end
if (PlotX==20 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOAKHALI'))
    end
if (PlotX==21 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FENI'))
    end
if (PlotX==22 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHAGRACHARI'))
    end
if (PlotX==16 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUSHTIA'))
    end
if (PlotX==17 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FARIDPUR'))
    end
if (PlotX==19 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDPUR'))
    end
if (PlotX==20 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COMILLA'))
    end
if (PlotX==20 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BRAHMANBARIA'))
    end
if (PlotX==16 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PABNA'))
    end
if (PlotX==18 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAMALPUR'))
    end
if (PlotX==19 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MYMENSINGH'))
    end
if (PlotX==21 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SYLHET'))
    end
if (PlotX==20 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SYLHET2'))
    end
if (PlotX==16 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAJSHAHI'))
    end
if (PlotX==17 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOGURA'))
    end
if (PlotX==15 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DINAJPUR'))
    end
if (PlotX==16 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RANGPUR'))
    end
if (PlotX==17 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KURIGRAM'))
    end
if (PlotX==0 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BISHKEK'))
    end
if (PlotX==2 and PlotY==49) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARA_SAY'))
    end
if (PlotX==1 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NARYN'))
    end
if (PlotX==2 and PlotY==50) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NARYN2'))
    end
if (PlotX==0 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOCHKOR'))
    end
if (PlotX==0 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOCHKOR2'))
    end
if (PlotX==1 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOKONBAEV'))
    end
if (PlotX==1 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOKONBAEV2'))
    end
if (PlotX==2 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARSKOON'))
    end
if (PlotX==3 and PlotY==51) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYZYL_SUU'))
    end
if (PlotX==0 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALYKCHY'))
    end
if (PlotX==1 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALYKCHY2'))
    end
if (PlotX==4 and PlotY==52) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKOL'))
    end
if (PlotX==4 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAKOL2'))
    end
if (PlotX==5 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AK_SUU'))
    end
if (PlotX==1 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALMATY'))
    end
if (PlotX==2 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALMATY2'))
    end
if (PlotX==3 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALMATY3'))
    end
if (PlotX==2 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALMATY4'))
    end
if (PlotX==3 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALMATY5'))
    end
if (PlotX==0 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHU'))
    end
if (PlotX==0 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHU2'))
    end
if (PlotX==4 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KEGEN'))
    end
if (PlotX==5 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KEGEN2'))
    end
if (PlotX==0 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAMBYL'))
    end
if (PlotX==1 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHAMBYL2'))
    end
if (PlotX==4 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHELEK'))
    end
if (PlotX==5 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUNDZHA'))
    end
if (PlotX==5 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHUNDZHA2'))
    end
if (PlotX==2 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QONAEV'))
    end
if (PlotX==3 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QONAEV2'))
    end
if (PlotX==4 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHARKENT'))
    end
if (PlotX==4 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZHARKENT2'))
    end
if (PlotX==1 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAKANAS'))
    end
if (PlotX==1 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAKANAS2'))
    end
if (PlotX==2 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAKANAS3'))
    end
if (PlotX==0 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAOY'))
    end
if (PlotX==0 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAOY2'))
    end
if (PlotX==1 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAOY3'))
    end
if (PlotX==1 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAOY4'))
    end
if (PlotX==2 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOKSU'))
    end
if (PlotX==3 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TALDYKORGAN'))
    end
if (PlotX==4 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TALDYKORGAN2'))
    end
if (PlotX==5 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TALDYKORGAN3'))
    end
if (PlotX==2 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_USHTOBE'))
    end
if (PlotX==3 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_USHTOBE2'))
    end
if (PlotX==4 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_USHTOBE3'))
    end
if (PlotX==4 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SARKAND'))
    end
if (PlotX==5 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SARKAND2'))
    end
if (PlotX==5 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SARKAND3'))
    end
if (PlotX==6 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SARKAND4'))
    end
if (PlotX==7 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALAQOL'))
    end
if (PlotX==8 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALAQOL2'))
    end
if (PlotX==0 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALKHASH'))
    end
if (PlotX==1 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALKHASH2'))
    end
if (PlotX==2 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAYAK'))
    end
if (PlotX==3 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKTOGAY'))
    end
if (PlotX==4 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKTOGAY2'))
    end
if (PlotX==0 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAGANDA'))
    end
if (PlotX==1 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAGANDA2'))
    end
if (PlotX==2 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAGANDA3'))
    end
if (PlotX==0 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAGANDA4'))
    end
if (PlotX==1 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAGANDA5'))
    end
if (PlotX==2 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAGANDA6'))
    end
if (PlotX==3 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARSHATAS'))
    end
if (PlotX==4 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARSHATAS2'))
    end
if (PlotX==3 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARSHATAS3'))
    end
if (PlotX==4 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARSHATAS4'))
    end
if (PlotX==5 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AYAGOZ'))
    end
if (PlotX==5 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AYAGOZ2'))
    end
if (PlotX==6 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AYAGOZ3'))
    end
if (PlotX==5 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AYAGOZ4'))
    end
if (PlotX==6 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AYAGOZ5'))
    end
if (PlotX==7 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AYAGOZ6'))
    end
if (PlotX==6 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URZHAR'))
    end
if (PlotX==7 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URZHAR2'))
    end
if (PlotX==8 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URZHAR3'))
    end
if (PlotX==9 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_URZHAR4'))
    end
if (PlotX==8 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TARBAGATAY'))
    end
if (PlotX==9 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TARBAGATAY2'))
    end
if (PlotX==10 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TARBAGATAY3'))
    end
if (PlotX==8 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TARBAGATAY4'))
    end
if (PlotX==9 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TARBAGATAY5'))
    end
if (PlotX==11 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAYSAN'))
    end
if (PlotX==12 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAYSAN2'))
    end
if (PlotX==12 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KURSHIM'))
    end
if (PlotX==42 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANOI'))
    end
if (PlotX==41 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VU_QUANG'))
    end
if (PlotX==42 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HA_TINH'))
    end
if (PlotX==39 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CON_CUONG'))
    end
if (PlotX==40 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DO_LUONG'))
    end
if (PlotX==41 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VINH'))
    end
if (PlotX==39 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KY_SON'))
    end
if (PlotX==41 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGHI_SON'))
    end
if (PlotX==40 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THUONG_XUAN'))
    end
if (PlotX==41 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THANH_HOA'))
    end
if (PlotX==40 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_QUAN_SON'))
    end
if (PlotX==41 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THACH_THANH'))
    end
if (PlotX==42 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NINH_BINH'))
    end
if (PlotX==43 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAM_DINH'))
    end
if (PlotX==39 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOC_CHAU'))
    end
if (PlotX==41 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NHO_QUAN'))
    end
if (PlotX==42 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHU_LY'))
    end
if (PlotX==38 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DIEN_BIEN_PHU'))
    end
if (PlotX==39 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SON_LA'))
    end
if (PlotX==41 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOA_BINH'))
    end
if (PlotX==44 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAI_PHONG'))
    end
if (PlotX==45 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HA_LONG'))
    end
if (PlotX==36 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUONG_NHE'))
    end
if (PlotX==37 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUONG_TE'))
    end
if (PlotX==38 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAI_CHAU'))
    end
if (PlotX==39 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NGHIA_LO'))
    end
if (PlotX==40 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAN_SON'))
    end
if (PlotX==43 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAI_DUONG'))
    end
if (PlotX==45 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONG_CAI'))
    end
if (PlotX==39 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAO_CAI'))
    end
if (PlotX==40 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YEN_BAI'))
    end
if (PlotX==41 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VIET_TRI'))
    end
if (PlotX==42 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THAI_NGUYEN'))
    end
if (PlotX==43 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAC_NINH'))
    end
if (PlotX==44 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANG_SON'))
    end
if (PlotX==40 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HA_GIANG'))
    end
if (PlotX==41 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HA_GIANG2'))
    end
if (PlotX==42 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CAO_BANG'))
    end
if (PlotX==43 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CAO_BANG2'))
    end
if (PlotX==35 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VIENTIANE'))
    end
if (PlotX==36 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VIENTIANE2'))
    end
if (PlotX==34 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XANAKHARM'))
    end
if (PlotX==35 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VANG_VIENG'))
    end
if (PlotX==36 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VANG_VIENG2'))
    end
if (PlotX==37 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAKXAN'))
    end
if (PlotX==37 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANOUVONG'))
    end
if (PlotX==38 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIANGKHOUANG'))
    end
if (PlotX==36 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHONSAVAN'))
    end
if (PlotX==34 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KENETHAO'))
    end
if (PlotX==33 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PARKLAI'))
    end
if (PlotX==34 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PARKLAI2'))
    end
if (PlotX==34 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYABURY'))
    end
if (PlotX==34 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XAYABURY2'))
    end
if (PlotX==33 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_XIENGHONE'))
    end
if (PlotX==35 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUANG_PRABANG'))
    end
if (PlotX==35 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUANG_PRABANG2'))
    end
if (PlotX==34 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOMPHET'))
    end
if (PlotX==36 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAM_BAK'))
    end
if (PlotX==33 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOUAYXAY'))
    end
if (PlotX==34 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUANG_NAMTHA'))
    end
if (PlotX==35 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUANG_XAY'))
    end
if (PlotX==36 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHONGSALI'))
    end
if (PlotX==30 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIANG_MAI'))
    end
if (PlotX==30 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIANG_MAI2'))
    end
if (PlotX==31 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIANG_MAI3'))
    end
if (PlotX==31 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIANG_MAI4'))
    end
if (PlotX==30 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAK'))
    end
if (PlotX==31 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUKHOTHAI'))
    end
if (PlotX==32 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUKHOTHAI2'))
    end
if (PlotX==33 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHITSANULOK'))
    end
if (PlotX==35 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOEI'))
    end
if (PlotX==36 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NONG_KHAI'))
    end
if (PlotX==37 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUENG_KAN'))
    end
if (PlotX==28 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAE_SARIANG'))
    end
if (PlotX==29 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SOP_MOEI'))
    end
if (PlotX==29 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAE_HONG_SON'))
    end
if (PlotX==29 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAE_HONG_SON2'))
    end
if (PlotX==30 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAI'))
    end
if (PlotX==30 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAMPHUN'))
    end
if (PlotX==31 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAMPANG'))
    end
if (PlotX==32 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UTTARADIT'))
    end
if (PlotX==32 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHRAE'))
    end
if (PlotX==33 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAN'))
    end
if (PlotX==32 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHAYAO'))
    end
if (PlotX==33 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHAYAO2'))
    end
if (PlotX==31 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIANG_RAI'))
    end
if (PlotX==32 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHIANG_RAI2'))
    end
if (PlotX==27 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAYPYIDAW'))
    end
if (PlotX==26 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAYPYIDAW2'))
    end
if (PlotX==25 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HINTHADA'))
    end
if (PlotX==28 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HPAPUN'))
    end
if (PlotX==23 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GWA'))
    end
if (PlotX==24 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GWA2'))
    end
if (PlotX==23 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THANDWE'))
    end
if (PlotX==24 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THANDWE2'))
    end
if (PlotX==23 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOUNGUP'))
    end
if (PlotX==22 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYAUKPYU'))
    end
if (PlotX==23 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYAUKPYU2'))
    end
if (PlotX==21 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SITTWE'))
    end
if (PlotX==22 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MRAUK_U'))
    end
if (PlotX==26 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THARRAWADDY'))
    end
if (PlotX==26 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NATTALIN'))
    end
if (PlotX==26 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PYAY'))
    end
if (PlotX==28 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MESE'))
    end
if (PlotX==29 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHADAW'))
    end
if (PlotX==28 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOIKAW'))
    end
if (PlotX==26 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THAYET'))
    end
if (PlotX==23 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINBU'))
    end
if (PlotX==25 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAGWAY'))
    end
if (PlotX==24 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEIKPHYU'))
    end
if (PlotX==24 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAKOKKU'))
    end
if (PlotX==23 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MINDAT'))
    end
if (PlotX==22 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PALETWA'))
    end
if (PlotX==23 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATUPI'))
    end
if (PlotX==23 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAKHA'))
    end
if (PlotX==26 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NYAUNG_U'))
    end
if (PlotX==27 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEIKTILA'))
    end
if (PlotX==26 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MYINGYAN'))
    end
if (PlotX==27 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDALAY'))
    end
if (PlotX==27 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SINGU'))
    end
if (PlotX==28 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PYIN_OO_LWIN'))
    end
if (PlotX==27 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THABEIKKYIN'))
    end
if (PlotX==29 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOMEIN'))
    end
if (PlotX==30 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONG_TON'))
    end
if (PlotX==28 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KALAW'))
    end
if (PlotX==29 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LANGHKO'))
    end
if (PlotX==30 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONG_PAN'))
    end
if (PlotX==31 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONG_HSAT'))
    end
if (PlotX==32 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TACHILEIK'))
    end
if (PlotX==28 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAUNGGYI'))
    end
if (PlotX==29 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LOILEN'))
    end
if (PlotX==30 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONG_PING'))
    end
if (PlotX==31 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KENGTUNG'))
    end
if (PlotX==30 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANGYAN'))
    end
if (PlotX==31 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PANGKHAM'))
    end
if (PlotX==28 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYAUKME'))
    end
if (PlotX==29 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LASHIO'))
    end
if (PlotX==30 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KUNLONG'))
    end
if (PlotX==31 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAMTIT'))
    end
if (PlotX==28 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MABEIN'))
    end
if (PlotX==29 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAMHKAM'))
    end
if (PlotX==30 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUSE'))
    end
if (PlotX==31 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOKANG'))
    end
if (PlotX==25 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MYAUNG'))
    end
if (PlotX==24 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONYWA'))
    end
if (PlotX==25 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGAING'))
    end
if (PlotX==24 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KALEMYO'))
    end
if (PlotX==26 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHWEBO'))
    end
if (PlotX==24 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAWLAIK'))
    end
if (PlotX==25 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANBALU'))
    end
if (PlotX==26 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HTIGYAING'))
    end
if (PlotX==25 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAUNGBYIN'))
    end
if (PlotX==26 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PINLEBU'))
    end
if (PlotX==27 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KATHA'))
    end
if (PlotX==25 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOMALIN'))
    end
if (PlotX==26 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BANMAUK'))
    end
if (PlotX==26 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HKAMTI'))
    end
if (PlotX==26 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LAHE'))
    end
if (PlotX==28 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANSI'))
    end
if (PlotX==27 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOHNYIN'))
    end
if (PlotX==28 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHAMO'))
    end
if (PlotX==27 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HPAKANT'))
    end
if (PlotX==28 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MYITKYINA'))
    end
if (PlotX==27 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MYITKYINA2'))
    end
if (PlotX==28 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MYITKYINA3'))
    end
if (PlotX==27 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINGBWIYANG'))
    end
if (PlotX==28 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TANAI'))
    end
if (PlotX==27 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUTAO'))
    end
if (PlotX==28 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUTAO2'))
    end
if (PlotX==28 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PUTAO3'))
    end
if (PlotX==0 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GILGIT'))
    end
if (PlotX==0 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GILGIT2'))
    end
if (PlotX==1 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SKARDU'))
    end
if (PlotX==1 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SKARDU2'))
    end
if (PlotX==1 and PlotY==34) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SKARDU3'))
    end
if (PlotX==2 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GHANCHE'))
    end
if (PlotX==2 and PlotY==33) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GHANCHE2'))
    end
if (PlotX==2 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELHI'))
    end
if (PlotX==2 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURUGRAM'))
    end
if (PlotX==3 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FARIDABAD'))
    end
if (PlotX==1 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ROHTAK'))
    end
if (PlotX==0 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIRSA'))
    end
if (PlotX==1 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HISAR'))
    end
if (PlotX==2 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PANIPAT'))
    end
if (PlotX==1 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAITHAL'))
    end
if (PlotX==2 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARNAL'))
    end
if (PlotX==3 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMBALA'))
    end
if (PlotX==2 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDIGARH'))
    end
if (PlotX==0 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANSA'))
    end
if (PlotX==0 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BATHINDA'))
    end
if (PlotX==1 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANGRUR'))
    end
if (PlotX==2 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PATIALA'))
    end
if (PlotX==0 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARNALA'))
    end
if (PlotX==1 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANNA'))
    end
if (PlotX==0 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOGA'))
    end
if (PlotX==1 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUDHIANA'))
    end
if (PlotX==2 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RUPNAGAR'))
    end
if (PlotX==0 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALANDHAR'))
    end
if (PlotX==0 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMRITSAR'))
    end
if (PlotX==4 and PlotY==22) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEHRADUN'))
    end
if (PlotX==5 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HALDWANI'))
    end
if (PlotX==4 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ROORKEE'))
    end
if (PlotX==5 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAURI'))
    end
if (PlotX==6 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PITHORAGARH'))
    end
if (PlotX==4 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HARIDWAR'))
    end
if (PlotX==3 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHIMLA'))
    end
if (PlotX==4 and PlotY==24) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KINNAUR'))
    end
if (PlotX==1 and PlotY==25) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UNA'))
    end
if (PlotX==3 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAZA'))
    end
if (PlotX==2 and PlotY==26) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDI'))
    end
if (PlotX==1 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHARAMSHALA'))
    end
if (PlotX==2 and PlotY==27) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KYELANG'))
    end
if (PlotX==0 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SRINAGAR'))
    end
if (PlotX==0 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SRINAGAR2'))
    end
if (PlotX==0 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAMMU'))
    end
if (PlotX==1 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAMMU2'))
    end
if (PlotX==1 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARGIL'))
    end
if (PlotX==0 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARGIL2'))
    end
if (PlotX==3 and PlotY==30) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LEH'))
    end
if (PlotX==2 and PlotY==31) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LEH2'))
    end
if (PlotX==3 and PlotY==32) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LEH3'))
    end
if (PlotX==2 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LADAKH'))
    end
if (PlotX==3 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LADAKH2'))
    end
if (PlotX==4 and PlotY==28) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LADAKH3'))
    end
if (PlotX==1 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LADAKH4'))
    end
if (PlotX==2 and PlotY==29) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LADAKH5'))
    end
if (PlotX==1 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAIPUR'))
    end
if (PlotX==1 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAIPUR2'))
    end
if (PlotX==0 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHITTORGARH'))
    end
if (PlotX==1 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUNDI'))
    end
if (PlotX==2 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOTA'))
    end
if (PlotX==0 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHILWARA'))
    end
if (PlotX==1 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAWAI_MADHOPUR'))
    end
if (PlotX==0 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AJMER'))
    end
if (PlotX==1 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONK'))
    end
if (PlotX==2 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARAULI'))
    end
if (PlotX==2 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHOLPUR'))
    end
if (PlotX==0 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGAUR'))
    end
if (PlotX==2 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHARATPUR'))
    end
if (PlotX==0 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIKAR'))
    end
if (PlotX==1 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALWAR'))
    end
if (PlotX==0 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHURU'))
    end
if (PlotX==1 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JHUNJHUNUN'))
    end
if (PlotX==0 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HANUMANGARH'))
    end
if (PlotX==7 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUCKNOW'))
    end
if (PlotX==8 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OBRA'))
    end
if (PlotX==4 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LALITPUR'))
    end
if (PlotX==8 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ROBERTSGANJ'))
    end
if (PlotX==3 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JHANSI'))
    end
if (PlotX==5 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAHOBA'))
    end
if (PlotX==6 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BANDA'))
    end
if (PlotX==7 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MIRZAPUR'))
    end
if (PlotX==8 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDAULI'))
    end
if (PlotX==5 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALAUN'))
    end
if (PlotX==6 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAUDAHA'))
    end
if (PlotX==7 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALLAHABAD'))
    end
if (PlotX==8 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VARANASI'))
    end
if (PlotX==3 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AGRA'))
    end
if (PlotX==3 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AGRA2'))
    end
if (PlotX==4 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ETAWAH'))
    end
if (PlotX==5 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANPUR'))
    end
if (PlotX==6 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANPUR2'))
    end
if (PlotX==7 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SULTANPUR'))
    end
if (PlotX==8 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AZAMGARH'))
    end
if (PlotX==9 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALLIA'))
    end
if (PlotX==4 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FIROZABAD'))
    end
if (PlotX==5 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAINPURI'))
    end
if (PlotX==6 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FARRUKHABAD'))
    end
if (PlotX==8 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_FAIZABAD'))
    end
if (PlotX==9 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEORIA'))
    end
if (PlotX==2 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATHURA'))
    end
if (PlotX==3 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HATHRAS'))
    end
if (PlotX==4 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ETAH'))
    end
if (PlotX==5 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUDAUN'))
    end
if (PlotX==6 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SITAPUR'))
    end
if (PlotX==7 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONDA'))
    end
if (PlotX==8 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BASTI'))
    end
if (PlotX==9 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GORAKHPUR'))
    end
if (PlotX==4 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALIGARH'))
    end
if (PlotX==5 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAMPUR'))
    end
if (PlotX==6 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAREILLY'))
    end
if (PlotX==7 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAHRAICH'))
    end
if (PlotX==3 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULANDSHAHAR'))
    end
if (PlotX==4 and PlotY==19) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORADABAD'))
    end
if (PlotX==3 and PlotY==20) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MEERUT'))
    end
if (PlotX==3 and PlotY==21) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAHARANPUR'))
    end
if (PlotX==11 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PATNA'))
    end
if (PlotX==9 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SASARAM'))
    end
if (PlotX==10 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AURANGABAD_BIHAR'))
    end
if (PlotX==11 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GAYA'))
    end
if (PlotX==12 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAWADA'))
    end
if (PlotX==9 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PIRO'))
    end
if (PlotX==10 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JEHANABAD'))
    end
if (PlotX==11 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NALANDA'))
    end
if (PlotX==12 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MUNGER'))
    end
if (PlotX==13 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHAGALPUR'))
    end
if (PlotX==9 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUXAR'))
    end
if (PlotX==10 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARRAH'))
    end
if (PlotX==12 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAMASTIPUR'))
    end
if (PlotX==13 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEGUSARAI'))
    end
if (PlotX==14 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PURNIA'))
    end
if (PlotX==10 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHHAPRA'))
    end
if (PlotX==11 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOTIHARI'))
    end
if (PlotX==12 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SITAMARHI'))
    end
if (PlotX==10 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BETTIAH'))
    end
if (PlotX==14 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOLKATA'))
    end
if (PlotX==15 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOLKATA2'))
    end
if (PlotX==14 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HALDIA'))
    end
if (PlotX==16 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUNDARBANS'))
    end
if (PlotX==13 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHARAGPUR'))
    end
if (PlotX==13 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PURULIA'))
    end
if (PlotX==14 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARDHAMAN'))
    end
if (PlotX==15 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HUGLI'))
    end
if (PlotX==16 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HABRA'))
    end
if (PlotX==13 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ASANSOL'))
    end
if (PlotX==14 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KATWA'))
    end
if (PlotX==15 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KRISHNANAGAR'))
    end
if (PlotX==15 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BERHAMPORE'))
    end
if (PlotX==15 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MALDA'))
    end
if (PlotX==15 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SILIGURI'))
    end
if (PlotX==16 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALPAIGURI'))
    end
if (PlotX==17 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_COOCH_BEHAR'))
    end
if (PlotX==15 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARJEELING'))
    end
if (PlotX==16 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KALIMPONG'))
    end
if (PlotX==16 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GANGTOK'))
    end
if (PlotX==11 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RANCHI'))
    end
if (PlotX==12 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAIBASA'))
    end
if (PlotX==10 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUMLA'))
    end
if (PlotX==12 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAMSHEDPUR'))
    end
if (PlotX==10 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LATEHAR'))
    end
if (PlotX==11 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAMGARH'))
    end
if (PlotX==12 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOKARO'))
    end
if (PlotX==9 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARHWA'))
    end
if (PlotX==10 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHATRA'))
    end
if (PlotX==11 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAZARIBAGH'))
    end
if (PlotX==12 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHANBAD'))
    end
if (PlotX==13 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DEOGHAR'))
    end
if (PlotX==14 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PAKUR'))
    end
if (PlotX==12 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHUBANESWAR'))
    end
if (PlotX==8 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MALKANGIRI'))
    end
if (PlotX==8 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JEYPORE'))
    end
if (PlotX==8 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NABARANGAPUR'))
    end
if (PlotX==9 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHAWANIPATNA'))
    end
if (PlotX==11 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BRAHMAPUR'))
    end
if (PlotX==9 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALANGIR'))
    end
if (PlotX==10 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PHULBANI'))
    end
if (PlotX==11 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAYAGARH'))
    end
if (PlotX==9 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NUAPADA'))
    end
if (PlotX==10 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SONAPUR'))
    end
if (PlotX==11 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAUDHGARH'))
    end
if (PlotX==12 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ANGUL'))
    end
if (PlotX==13 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CUTTACK'))
    end
if (PlotX==9 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARGARH'))
    end
if (PlotX==10 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAMBALPUR'))
    end
if (PlotX==11 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KENDUJHAR'))
    end
if (PlotX==12 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHADRAK'))
    end
if (PlotX==10 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JHARSUGUDA'))
    end
if (PlotX==11 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ROURKELA'))
    end
if (PlotX==13 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALASORE'))
    end
if (PlotX==6 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAIPUR'))
    end
if (PlotX==6 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SUKMA'))
    end
if (PlotX==6 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DANTEWADA'))
    end
if (PlotX==6 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NARAYANPUR'))
    end
if (PlotX==7 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JAGDALPUR'))
    end
if (PlotX==6 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KANKER'))
    end
if (PlotX==7 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KONDAGAON'))
    end
if (PlotX==6 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHILAI'))
    end
if (PlotX==7 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHAMTARI'))
    end
if (PlotX==8 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GARIABAND'))
    end
if (PlotX==7 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAHASAMUND'))
    end
if (PlotX==8 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SARAIPALI'))
    end
if (PlotX==7 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BILASPUR'))
    end
if (PlotX==8 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHAMPA'))
    end
if (PlotX==9 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAIGARH'))
    end
if (PlotX==7 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORBA'))
    end
if (PlotX==8 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMBIKAPUR'))
    end
if (PlotX==9 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JASHPUR'))
    end
if (PlotX==7 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KORIYA'))
    end
if (PlotX==8 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SURAJPUR'))
    end
if (PlotX==9 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALRAMPUR'))
    end
if (PlotX==3 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHOPAL'))
    end
if (PlotX==0 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SENDHWA'))
    end
if (PlotX==1 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURHANPUR'))
    end
if (PlotX==2 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BETUL'))
    end
if (PlotX==3 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHHINDWARA'))
    end
if (PlotX==0 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARWANI'))
    end
if (PlotX==1 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHARGONE'))
    end
if (PlotX==2 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANDWA'))
    end
if (PlotX==1 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANDWA2'))
    end
if (PlotX==3 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HOSHANGABAD'))
    end
if (PlotX==4 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEONI'))
    end
if (PlotX==5 and PlotY==8) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BALAGHAT'))
    end

if (PlotX==4 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JABALPUR'))
    end
if (PlotX==5 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDLA'))
    end
if (PlotX==6 and PlotY==9) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHAHDOL'))
    end
if (PlotX==0 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHAR'))
    end
if (PlotX==2 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_INDORE'))
    end
if (PlotX==4 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NARSINGHPUR'))
    end
if (PlotX==5 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DAMOH'))
    end
if (PlotX==6 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UMARIA'))
    end
if (PlotX==1 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDSAUR'))
    end
if (PlotX==2 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAJGARH'))
    end
if (PlotX==3 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VIDISHA'))
    end
if (PlotX==4 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAGAR'))
    end
if (PlotX==5 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KATNI'))
    end
if (PlotX==6 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIDHI'))
    end
if (PlotX==7 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SINGRAULI'))
    end
if (PlotX==3 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUNA'))
    end
if (PlotX==5 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PANNA'))
    end
if (PlotX==6 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SATNA'))
    end
if (PlotX==7 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_REWA'))
    end
if (PlotX==4 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIWARI'))
    end
if (PlotX==3 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GWALIOR'))
    end
if (PlotX==4 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHIND'))
    end
if (PlotX==4 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGPUR'))
    end
if (PlotX==4 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGPUR2'))
    end
if (PlotX==0 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SOLAPUR'))
    end
if (PlotX==1 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LATUR'))
    end
if (PlotX==0 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BEED'))
    end
if (PlotX==0 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AHMADNAGAR'))
    end
if (PlotX==1 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALNA'))
    end
if (PlotX==2 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NANDED'))
    end
if (PlotX==0 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AURANGABAD'))
    end
if (PlotX==1 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HINGOLI'))
    end
if (PlotX==2 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAVATMAL'))
    end
if (PlotX==3 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_YAVATMAL2'))
    end
if (PlotX==4 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDRAPUR'))
    end
if (PlotX==4 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDRAPUR2'))
    end
if (PlotX==5 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADCHIROLI'))
    end
if (PlotX==5 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GADCHIROLI2'))
    end
if (PlotX==0 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MALEGAON'))
    end
if (PlotX==1 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULDANA'))
    end
if (PlotX==2 and PlotY==4) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WASHIM'))
    end
if (PlotX==0 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALGAON'))
    end
if (PlotX==1 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JALGAON2'))
    end
if (PlotX==1 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKOLA'))
    end
if (PlotX==2 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AKOLA2'))
    end
if (PlotX==3 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WARDHA'))
    end
if (PlotX==0 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHULE'))
    end
if (PlotX==3 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMRAVATI'))
    end
if (PlotX==2 and PlotY==5) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AMRAVATI2'))
    end
if (PlotX==5 and PlotY==6) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHANDARA'))
    end
if (PlotX==5 and PlotY==7) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GONDIA'))
    end
if (PlotX==7 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VISAKHAPATNAM'))
    end
if (PlotX==8 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VISAKHAPATNAM2'))
    end
if (PlotX==7 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_RAJAHMUNDRY'))
    end
if (PlotX==8 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KAKINADA'))
    end
if (PlotX==9 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_VIZIANAGARAM'))
    end
if (PlotX==9 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SRIKAKULAM'))
    end
if (PlotX==10 and PlotY==3) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SRIKAKULAM2'))
    end
if (PlotX==3 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HYDERABAD'))
    end
if (PlotX==2 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NIZAMABAD'))
    end
if (PlotX==4 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_WARANGAL'))
    end
if (PlotX==5 and PlotY==0) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHAMMAM'))
    end
if (PlotX==3 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KARIMNAGAR'))
    end
if (PlotX==4 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANCHERIAL'))
    end
if (PlotX==6 and PlotY==1) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BHADRACHALAM'))
    end
if (PlotX==3 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ADILABAD'))
    end
if (PlotX==4 and PlotY==2) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ASIFABAD'))
    end
if (PlotX==20 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUWAHATI'))
    end
if (PlotX==22 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SILCHAR'))
    end
if (PlotX==22 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORIGAON'))
    end
if (PlotX==22 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAGAON'))
    end
if (PlotX==23 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GOLAGHAT'))
    end
if (PlotX==24 and PlotY==15) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SIVASAGAR'))
    end
if (PlotX==18 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHUBRI'))
    end
if (PlotX==19 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BONGAIGAON'))
    end
if (PlotX==20 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NALBARI'))
    end
if (PlotX==21 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANGALDOI'))
    end
if (PlotX==25 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TINSUKIA'))
    end
if (PlotX==21 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TEZPUR'))
    end
if (PlotX==22 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BISWANATH'))
    end
if (PlotX==23 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MAJULI'))
    end
if (PlotX==24 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DHEMAJI'))
    end
if (PlotX==23 and PlotY==13) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IMPHAL'))
    end
if (PlotX==23 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHURACHANDPUR'))
    end
if (PlotX==24 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_THOUBAL'))
    end
if (PlotX==22 and PlotY==11) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AIZAWL'))
    end
if (PlotX==23 and PlotY==10) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUNGLEI'))
    end
if (PlotX==21 and PlotY==12) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AGARTALA'))
    end
if (PlotX==21 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHILLONG'))
    end
if (PlotX==19 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TURA'))
    end
if (PlotX==24 and PlotY==14) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KOHIMA'))
    end
if (PlotX==26 and PlotY==16) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NAMSAI'))
    end
if (PlotX==26 and PlotY==17) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TEZU'))
    end
if (PlotX==25 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_PASIGHAT'))
    end
if (PlotX==26 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ROING'))
    end
if (PlotX==27 and PlotY==18) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HAWAI'))
    end
if (PlotX==43 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBAATAR'))
    end
if (PlotX==44 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBAATAR2'))
    end
if (PlotX==42 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBAATAR3'))
    end
if (PlotX==43 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBAATAR4'))
    end
if (PlotX==44 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBAATAR5'))
    end
if (PlotX==47 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAGANUUR'))
    end
if (PlotX==59 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIBALSAN'))
    end
if (PlotX==59 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIBALSAN2'))
    end
if (PlotX==60 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIBALSAN3'))
    end
if (PlotX==58 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIBALSAN4'))
    end
if (PlotX==59 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIBALSAN5'))
    end
if (PlotX==60 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIBALSAN6'))
    end
if (PlotX==61 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALKHGOL'))
    end
if (PlotX==62 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALKHGOL2'))
    end
if (PlotX==62 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALKHGOL3'))
    end
if (PlotX==63 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALKHGOL4'))
    end
if (PlotX==64 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALKHGOL5'))
    end
if (PlotX==63 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALKHGOL6'))
    end
if (PlotX==60 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATAD'))
    end
if (PlotX==59 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATAD2'))
    end
if (PlotX==60 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATAD3'))
    end
if (PlotX==61 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATAD4'))
    end
if (PlotX==60 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MATAD5'))
    end
if (PlotX==57 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_DORNOD'))
    end
if (PlotX==58 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_DORNOD2'))
    end
if (PlotX==57 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_DORNOD3'))
    end
if (PlotX==58 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_DORNOD4'))
    end
if (PlotX==56 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOLONBUIR'))
    end
if (PlotX==56 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOLONBUIR2'))
    end
if (PlotX==55 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOLONBUIR3'))
    end
if (PlotX==56 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTUMEN'))
    end
if (PlotX==57 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTUMEN2'))
    end
if (PlotX==52 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONDORKHAAN'))
    end
if (PlotX==53 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONDORKHAAN2'))
    end
if (PlotX==50 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONDORKHAAN3'))
    end
if (PlotX==51 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONDORKHAAN4'))
    end
if (PlotX==52 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONDORKHAAN5'))
    end
if (PlotX==54 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO_K'))
    end
if (PlotX==55 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO_K2'))
    end
if (PlotX==53 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO_K3'))
    end
if (PlotX==54 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO_K4'))
    end
if (PlotX==52 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GALSHAR'))
    end
if (PlotX==53 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GALSHAR2'))
    end
if (PlotX==52 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANKHUTAG'))
    end
if (PlotX==52 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANKHUTAG2'))
    end
if (PlotX==53 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANKHUTAG3'))
    end
if (PlotX==49 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARKHAN'))
    end
if (PlotX==49 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARKHAN2'))
    end
if (PlotX==50 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARKHAN3'))
    end
if (PlotX==50 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANMONKH'))
    end
if (PlotX==51 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANMONKH2'))
    end
if (PlotX==50 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANMONKH3'))
    end
if (PlotX==51 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORON'))
    end
if (PlotX==51 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MORON2'))
    end
if (PlotX==48 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGERKHAAN_K'))
    end
if (PlotX==49 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGERKHAAN_K2'))
    end
if (PlotX==49 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARGALTKHAAN'))
    end
if (PlotX==50 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARGALTKHAAN2'))
    end
if (PlotX==49 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARGALTKHAAN3'))
    end
if (PlotX==48 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSENKHERMANDAL'))
    end
if (PlotX==48 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSENKHERMANDAL2'))
    end
if (PlotX==56 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARUUN_URT'))
    end
if (PlotX==56 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARUUN_URT2'))
    end
if (PlotX==57 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARUUN_URT3'))
    end
if (PlotX==58 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARUUN_URT4'))
    end
if (PlotX==58 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENETSAGAAN'))
    end
if (PlotX==59 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENETSAGAAN2'))
    end
if (PlotX==58 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENETSAGAAN3'))
    end
if (PlotX==59 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENETSAGAAN4'))
    end
if (PlotX==56 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NARAN'))
    end
if (PlotX==57 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARIGANGA'))
    end
if (PlotX==57 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ASGAT'))
    end
if (PlotX==55 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONGON'))
    end
if (PlotX==56 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONGON2'))
    end
if (PlotX==54 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANDELGER'))
    end
if (PlotX==55 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANDELGER2'))
    end
if (PlotX==55 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_HALZAN'))
    end
if (PlotX==54 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UULBAYAN'))
    end
if (PlotX==55 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UULBAYAN2'))
    end
if (PlotX==53 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUVSHINSHIREE'))
    end
if (PlotX==54 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUVSHINSHIREE2'))
    end
if (PlotX==54 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMENTSOGT'))
    end
if (PlotX==55 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TUMENTSOGT2'))
    end
if (PlotX==48 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAINSHAND'))
    end
if (PlotX==49 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAINSHAND2'))
    end
if (PlotX==50 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAINSHAND3'))
    end
if (PlotX==48 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAINSHAND4'))
    end
if (PlotX==49 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAINSHAND5'))
    end
if (PlotX==50 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAINSHAND6'))
    end
if (PlotX==52 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAMYN_UUD'))
    end
if (PlotX==53 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAMYN_UUD2'))
    end
if (PlotX==45 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHATANBULAG'))
    end
if (PlotX==46 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHATANBULAG2'))
    end
if (PlotX==47 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHATANBULAG3'))
    end
if (PlotX==46 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHATANBULAG4'))
    end
if (PlotX==47 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHATANBULAG5'))
    end
if (PlotX==45 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHATANBULAG6'))
    end
if (PlotX==48 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVSGOL'))
    end
if (PlotX==49 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVSGOL2'))
    end
if (PlotX==48 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVSGOL3'))
    end
if (PlotX==49 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVSGOL4'))
    end
if (PlotX==47 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVSGOL5'))
    end
if (PlotX==48 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVSGOL6'))
    end
if (PlotX==50 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBADRAKH'))
    end
if (PlotX==51 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBADRAKH2'))
    end
if (PlotX==49 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBADRAKH3'))
    end
if (PlotX==50 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULAANBADRAKH4'))
    end
if (PlotX==51 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_DG'))
    end
if (PlotX==51 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_DG2'))
    end
if (PlotX==52 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_DG3'))
    end
if (PlotX==51 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ORGON'))
    end
if (PlotX==52 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ORGON2'))
    end
if (PlotX==46 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDAKH'))
    end
if (PlotX==46 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDAKH2'))
    end
if (PlotX==47 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDAKH3'))
    end
if (PlotX==46 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIKHANDULAAN'))
    end
if (PlotX==47 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SAIKHANDULAAN2'))
    end
if (PlotX==48 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AIRAG'))
    end
if (PlotX==49 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_AIRAG2'))
    end
if (PlotX==50 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTANSHIREE'))
    end
if (PlotX==51 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTANSHIREE2'))
    end
if (PlotX==52 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGEREKH'))
    end
if (PlotX==53 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGEREKH2'))
    end
if (PlotX==48 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALANJARGALAN'))
    end
if (PlotX==51 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IKHKHET'))
    end
if (PlotX==47 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIR'))
    end
if (PlotX==47 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIR2'))
    end
if (PlotX==48 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHOIR3'))
    end
if (PlotX==43 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZUUNMOD'))
    end
if (PlotX==44 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZUUNMOD2'))
    end
if (PlotX==45 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZUUNMOD3'))
    end
if (PlotX==40 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGERKHAAN_TOV'))
    end
if (PlotX==41 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUREN'))
    end
if (PlotX==42 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONJUUL'))
    end
if (PlotX==43 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONJUUL2'))
    end
if (PlotX==44 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTSAGAAN_TOV'))
    end
if (PlotX==45 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTSAGAAN_TOV2'))
    end
if (PlotX==46 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN'))
    end
if (PlotX==45 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN2'))
    end
if (PlotX==46 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANJARGALAN'))
    end
if (PlotX==47 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANJARGALAN2'))
    end
if (PlotX==46 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARKHUST'))
    end
if (PlotX==45 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_TOV'))
    end
if (PlotX==46 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_TOV2'))
    end
if (PlotX==47 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONGONMORIT'))
    end
if (PlotX==40 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENESANT'))
    end
if (PlotX==41 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ONDORSHIREET'))
    end
if (PlotX==42 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTANBULAG'))
    end
if (PlotX==42 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTANBULAG2'))
    end
if (PlotX==40 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUN'))
    end
if (PlotX==41 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LUN2'))
    end
if (PlotX==40 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAAMAR'))
    end
if (PlotX==41 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARGALANT'))
    end
if (PlotX==39 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALANZADGAD'))
    end
if (PlotX==39 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALANZADGAD2'))
    end
if (PlotX==40 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DALANZADGAD3'))
    end
if (PlotX==40 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHAN_KHONGOR'))
    end
if (PlotX==41 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHAN_KHONGOR2'))
    end
if (PlotX==39 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHAN_KHONGOR3'))
    end
if (PlotX==40 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHAN_KHONGOR4'))
    end
if (PlotX==36 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_OG'))
    end
if (PlotX==37 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_OG2'))
    end
if (PlotX==38 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_OG3'))
    end
if (PlotX==37 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_OG4'))
    end
if (PlotX==38 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDAL_OVOO'))
    end
if (PlotX==39 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDAL_OVOO2'))
    end
if (PlotX==38 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANDAL_OVOO3'))
    end
if (PlotX==40 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGT_OVOO'))
    end
if (PlotX==41 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGT_OVOO2'))
    end
if (PlotX==42 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGTTSETSII'))
    end
if (PlotX==43 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGTTSETSII2'))
    end
if (PlotX==41 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGTTSETSII3'))
    end
if (PlotX==42 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGTTSETSII4'))
    end
if (PlotX==43 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANLAI'))
    end
if (PlotX==44 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANLAI2'))
    end
if (PlotX==43 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANBOGD'))
    end
if (PlotX==44 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANBOGD2'))
    end
if (PlotX==44 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANBOGD3'))
    end
if (PlotX==45 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANBOGD4'))
    end
if (PlotX==42 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO_OG'))
    end
if (PlotX==41 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO_OG2'))
    end
if (PlotX==42 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO_OG3'))
    end
if (PlotX==39 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOMGON'))
    end
if (PlotX==40 and PlotY==53) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOMGON2'))
    end
if (PlotX==40 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOMGON3'))
    end
if (PlotX==41 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOMGON4'))
    end
if (PlotX==38 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHURMEN'))
    end
if (PlotX==38 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHURMEN2'))
    end
if (PlotX==38 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHURMEN3'))
    end
if (PlotX==37 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANDALAI'))
    end
if (PlotX==36 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANDALAI2'))
    end
if (PlotX==37 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANDALAI3'))
    end
if (PlotX==37 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANDALAI4'))
    end
if (PlotX==38 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANDALAI5'))
    end
if (PlotX==35 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEVREI'))
    end
if (PlotX==36 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEVREI2'))
    end
if (PlotX==34 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEVREI3'))
    end
if (PlotX==35 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SEVREI4'))
    end
if (PlotX==35 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOYON'))
    end
if (PlotX==36 and PlotY==54) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOYON2'))
    end
if (PlotX==34 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOYON3'))
    end
if (PlotX==35 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NOYON4'))
    end
if (PlotX==31 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES'))
    end
if (PlotX==32 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES2'))
    end
if (PlotX==33 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES3'))
    end
if (PlotX==32 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES4'))
    end
if (PlotX==33 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES5'))
    end
if (PlotX==34 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES6'))
    end
if (PlotX==31 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES7'))
    end
if (PlotX==32 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES8'))
    end
if (PlotX==33 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES9'))
    end
if (PlotX==32 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVAN_TES10'))
    end
if (PlotX==37 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARVAIKHEER'))
    end
if (PlotX==37 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ARVAIKHEER2'))
    end
if (PlotX==36 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHARKHORIN'))
    end
if (PlotX==37 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHARKHORIN2'))
    end
if (PlotX==38 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURD'))
    end
if (PlotX==39 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BURD2'))
    end
if (PlotX==38 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OLZIIT_OK'))
    end
if (PlotX==38 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OLZIIT_OK2'))
    end
if (PlotX==39 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_OK'))
    end
if (PlotX==39 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_OK2'))
    end
if (PlotX==39 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SANT'))
    end
if (PlotX==37 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANGOL'))
    end
if (PlotX==38 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANGOL2'))
    end
if (PlotX==35 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOGD_OK'))
    end
if (PlotX==36 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOGD_OK2'))
    end
if (PlotX==34 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BARUUN_BAYAN_ULAAN'))
    end
if (PlotX==35 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GUCHIN_US'))
    end
if (PlotX==36 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOGROG_OK'))
    end
if (PlotX==34 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_NARIINTEEL'))
    end
if (PlotX==35 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHAIRKHANDULAAN'))
    end
if (PlotX==36 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TARAGT'))
    end
if (PlotX==34 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UYANGA'))
    end
if (PlotX==34 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAT_OLZII'))
    end
if (PlotX==35 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAT_OLZII2'))
    end
if (PlotX==36 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHUJIRT'))
    end
if (PlotX==35 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHUJIRT2'))
    end
if (PlotX==37 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN'))
    end
if (PlotX==38 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN2'))
    end
if (PlotX==39 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DASHINCHILEN'))
    end
if (PlotX==34 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSETSERLEG'))
    end
if (PlotX==29 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSAKHIR'))
    end
if (PlotX==31 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANGAI'))
    end
if (PlotX==30 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANGAI2'))
    end
if (PlotX==31 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHANGAI3'))
    end
if (PlotX==32 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHULUUT'))
    end
if (PlotX==32 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHULUUT2'))
    end
if (PlotX==33 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IKH_TAMIR'))
    end
if (PlotX==33 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_IKH_TAMIR2'))
    end
if (PlotX==34 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_ARKHANGAI'))
    end
if (PlotX==35 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSENKHER'))
    end
if (PlotX==36 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOTONT'))
    end
if (PlotX==38 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHASHAAT'))
    end
if (PlotX==26 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULIASTAI'))
    end
if (PlotX==26 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULIASTAI2'))
    end
if (PlotX==27 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ULIASTAI3'))
    end
if (PlotX==25 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORVOLJIN'))
    end
if (PlotX==24 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORVOLJIN2'))
    end
if (PlotX==25 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DORVOLJIN3'))
    end
if (PlotX==26 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSAGAANCHULUUT'))
    end
if (PlotX==27 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHILUUSTEI'))
    end
if (PlotX==27 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSAGAANKHAIRKHAN'))
    end
if (PlotX==28 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTGON'))
    end
if (PlotX==28 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OTGON2'))
    end
if (PlotX==21 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVD'))
    end
if (PlotX==20 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOVD2'))
    end
if (PlotX==20 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_KHOVD'))
    end
if (PlotX==21 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_KHOVD2'))
    end
if (PlotX==20 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_KHOVD3'))
    end
if (PlotX==21 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UYENCH'))
    end
if (PlotX==22 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UYENCH2'))
    end
if (PlotX==21 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_UYENCH3'))
    end
if (PlotX==22 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_KHOVD'))
    end
if (PlotX==23 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_KHOVD2'))
    end
if (PlotX==22 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MOST'))
    end
if (PlotX==23 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSETSEG'))
    end
if (PlotX==22 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MONKHKHAIRKHAN'))
    end
if (PlotX==24 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARVI'))
    end
if (PlotX==23 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARVI2'))
    end
if (PlotX==21 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DUUT'))
    end
if (PlotX==22 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_MANKHAN'))
    end
if (PlotX==23 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDMANI_KHOVD'))
    end
if (PlotX==22 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDMANI_KHOVD2'))
    end
if (PlotX==23 and PlotY==65) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDMANI_KHOVD3'))
    end
if (PlotX==21 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BULGAN_OLGII'))
    end
if (PlotX==26 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_CITY'))
    end
if (PlotX==27 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_CITY2'))
    end
if (PlotX==26 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_CITY3'))
    end
if (PlotX==25 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_GOVI_ALTAI'))
    end
if (PlotX==25 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_GOVI_ALTAI2'))
    end
if (PlotX==24 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_GOVI_ALTAI3'))
    end
if (PlotX==25 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ALTAI_GOVI_ALTAI4'))
    end
if (PlotX==26 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGT'))
    end
if (PlotX==26 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGT2'))
    end
if (PlotX==26 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGT3'))
    end
if (PlotX==27 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSOGT4'))
    end
if (PlotX==27 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_GOVI_ALTAI'))
    end
if (PlotX==27 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_GOVI_ALTAI2'))
    end
if (PlotX==28 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_GOVI_ALTAI3'))
    end
if (PlotX==27 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_GOVI_ALTAI4'))
    end
if (PlotX==28 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENE_GOVI_ALTAI5'))
    end
if (PlotX==23 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUGAT'))
    end
if (PlotX==24 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUGAT2'))
    end
if (PlotX==25 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSEEL'))
    end
if (PlotX==26 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TSEEL2'))
    end
if (PlotX==23 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONKHIL'))
    end
if (PlotX==24 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TONKHIL2'))
    end
if (PlotX==24 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOGROG_GOVI_ALTAI'))
    end
if (PlotX==25 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TOGROG_GOVI_ALTAI2'))
    end
if (PlotX==25 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALIUN'))
    end
if (PlotX==26 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHALIUN2'))
    end
if (PlotX==27 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BIGER'))
    end
if (PlotX==28 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_CHANDMANI_GOVI_ALTAI'))
    end
if (PlotX==24 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DARVI3'))
    end
if (PlotX==25 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHARGA'))
    end
if (PlotX==28 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGER'))
    end
if (PlotX==27 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGER2'))
    end
if (PlotX==27 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_DELGER3'))
    end
if (PlotX==25 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_UUL'))
    end
if (PlotX==24 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_UUL3'))
    end
if (PlotX==25 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARGALAN'))
    end
if (PlotX==26 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_TAISHIR'))
    end
if (PlotX==24 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_KHOKH_MORIT'))
    end
if (PlotX==31 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANKHONGOR'))
    end
if (PlotX==32 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANKHONGOR2'))
    end
if (PlotX==32 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANKHONGOR3'))
    end
if (PlotX==29 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTSAGAAN_BK'))
    end
if (PlotX==30 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTSAGAAN_BK2'))
    end
if (PlotX==29 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANTSAGAAN_BK3'))
    end
if (PlotX==31 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANGOVI'))
    end
if (PlotX==32 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANGOVI2'))
    end
if (PlotX==33 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANLIG'))
    end
if (PlotX==34 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANLIG2'))
    end
if (PlotX==33 and PlotY==59) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANLIG3'))
    end
if (PlotX==30 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAATSAGAAN'))
    end
if (PlotX==29 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAATSAGAAN2'))
    end
if (PlotX==30 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAATSAGAAN3'))
    end
if (PlotX==31 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINST'))
    end
if (PlotX==32 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JINST2'))
    end
if (PlotX==33 and PlotY==60) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOGD_BK'))
    end
if (PlotX==28 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYANBULAG'))
    end
if (PlotX==28 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUUTSAGAAN'))
    end
if (PlotX==29 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BUUTSAGAAN2'))
    end
if (PlotX==30 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BOMBOGOR'))
    end
if (PlotX==31 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_OVOO'))
    end
if (PlotX==33 and PlotY==62) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OLZIIT_BK'))
    end
if (PlotX==33 and PlotY==61) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_OLZIIT_BK2'))
    end
if (PlotX==28 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVANBULAG'))
    end
if (PlotX==29 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GURVANBULAG2'))
    end
if (PlotX==29 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ZAG'))
    end
if (PlotX==30 and PlotY==64) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_JARGALANT'))
    end
if (PlotX==30 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GALUUT'))
    end
if (PlotX==31 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_GALUUT2'))
    end
if (PlotX==32 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENETSOGT'))
    end
if (PlotX==33 and PlotY==63) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_ERDENETSOGT2'))
    end
if (PlotX==28 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_BK'))
    end
if (PlotX==29 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_BK2'))
    end
if (PlotX==29 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_BK3'))
    end
if (PlotX==28 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_BK4'))
    end
if (PlotX==29 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_BK5'))
    end
if (PlotX==29 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_BAYAN_ONDOR_BK6'))
    end
if (PlotX==30 and PlotY==55) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINEJINST'))
    end
if (PlotX==30 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINEJINST2'))
    end
if (PlotX==31 and PlotY==56) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINEJINST3'))
    end
if (PlotX==30 and PlotY==57) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINEJINST4'))
    end
if (PlotX==30 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINEJINST5'))
    end
if (PlotX==31 and PlotY==58) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_SHINEJINST6'))
    end





	if (PlotX==32 and PlotY==23) then
        local pCity=CityManager.GetCityAt(PlotX,PlotY) 
pCity:SetName(Locale.Lookup('LOC_NEACITYNAME_LITANG'))
    end




end



--Events.CityAddedToMap.Add(Citynameset01)

--GameEvents.CityBuilt.Add(Citynameset01)

GameEvents.CityBuilt.Add(Citynameset02)



