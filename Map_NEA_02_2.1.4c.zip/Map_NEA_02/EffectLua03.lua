-- EffectLuaScript03
-- Author: bottlep
-- DateCreated: 7/30/2022 12:12:22 AM
--------------------------------------------------------------

local m_NEA_MountainClass = GameInfo.TerrainClasses["TERRAIN_CLASS_NEA_MOUNTAIN"].Index
local m_NEA_MountainTunnel = GameInfo.Improvements["IMPROVEMENT_MOUNTAIN_TUNNEL"].Index
local m_NEA_MountainRoad = GameInfo.Improvements["IMPROVEMENT_MOUNTAIN_ROAD"].Index


function NEA_MountainRouteRemove(PlotX,PlotY)
    local pPlot = Map.GetPlot(PlotX,PlotY)
	
    local iTerClasIndex = pPlot:GetTerrainClassType()
	local iImpIndex = pPlot:GetImprovementType()

	 if (iTerClasIndex == m_NEA_MountainClass) and (iImpIndex ~= m_NEA_MountainTunnel) and (iImpIndex ~= m_NEA_MountainRoad)  then
        RouteBuilder.SetRouteType(pPlot, RouteTypes.NONE)
    end
	
end

Events.RouteChanged.Add( NEA_MountainRouteRemove );
Events.RouteAddedToMap.Add( NEA_MountainRouteRemove );

--
--function NeaMountainMovement1(iPlayerID, iUnitID, iMovm)
	--local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
    --local pPlot = Map.GetPlot(pUnit:GetX(),pUnit:GetY())
    --local iTerClasIndex = pPlot:GetTerrainClassType()
    --
    --if (iTerClasIndex == m_NEA_MountainClass) then
        ----local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
        --
        --if pUnit ~= nil then
			--UnitManager.ChangeMovesRemaining(pUnit, -25)
			--UnitManager.FinishMoves(pUnit)
--
			----pUnit:ChangeMovesRemaining(-22)
        --end
    --end
--
--end
--
--
----Events.UnitMovementPointsChanged.Add(NeaMountainMovement1)
--Events.UnitActivityChanged.Add(NeaMountainMovement1)
--
--
--
--
--
--
--local m_NEA_MountainClass = GameInfo.TerrainClasses["TERRAIN_CLASS_NEA_MOUNTAIN"].Index
--
--function NeaMountainMovement(iPlayerID, iUnitID, PlotX, PlotY,ijj,ikk)
    --local pPlot = Map.GetPlot(PlotX, PlotY)
    --local iTerClasIndex = pPlot:GetTerrainClassType()
    --
    --if (iTerClasIndex == m_NEA_MountainClass) then
        --local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
        --
        --if pUnit ~= nil then
			----UnitManager.ChangeMovesRemaining(pUnit, -25)
			----UnitManager.FinishMoves(pUnit)
--
			----pUnit:ChangeMovesRemaining(-22)
        --end
    --end
--
--end
--
--
--Events.UnitMoved.Add(NeaMountainMovement)
--


--local m_NEA_MountainClass = GameInfo.TerrainClasses["TERRAIN_CLASS_NEA_MOUNTAIN"].Index

function NeaMountainEntreDamage(iPlayerID, iUnitID, PlotX, PlotY,ijj,ikk)
    local pPlot = Map.GetPlot(PlotX, PlotY)
    local iTerClasIndex = pPlot:GetTerrainClassType()

	local iImpIndex = pPlot:GetImprovementType()
    local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
        
    if (iTerClasIndex == m_NEA_MountainClass) and (iImpIndex ~= m_NEA_MountainTunnel) and (iImpIndex ~= m_NEA_MountainRoad) and pUnit ~= nil then
        
        local iMoveRemain=pUnit:GetMovementMovesRemaining();
		local iMaxMov=pUnit:GetMaxMoves();
		pUnit:ChangeExtraMoves(-iMaxMov+1);

		pUnit:ChangeDamage(20);
		UnitManager.FinishMoves(pUnit);
	else
		local iExtraMov=pUnit:GetExtraMoves();
		pUnit:ChangeExtraMoves(-iExtraMov);
		--pUnit:ChangeDamage(2);
		
		
    end

end


Events.UnitMoved.Add(NeaMountainEntreDamage)



--
--local m_FarmIndex = GameInfo.Improvements["IMPROVEMENT_FARM"].Index
--
--function HealAtPlot(iPlayerID, iUnitID, PlotX, PlotY)
    --local pPlot = Map.GetPlot(PlotX, PlotY)
    --local iImpIndex = pPlot:GetImprovementType()
    --
    --if (iImpIndex == m_FarmIndex) then
        --local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
        --
        --if pUnit ~= nil then
            --pUnit:SetDamage(0)
        --end
    --end
--
--end
--

--Events.UnitMoveComplete.Add(HealAtPlot)





function NeaMountainMovement(iPlayerID, iUnitID, iMovm)
	local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
    local pPlot = Map.GetPlot(pUnit:GetX(),pUnit:GetY())
    local iTerClasIndex = pPlot:GetTerrainClassType()
	local iExtraMov=pUnit:GetExtraMoves()
    
    if (iTerClasIndex == m_NEA_MountainClass) and (iImpIndex ~= m_NEA_MountainTunnel) and (iImpIndex ~= m_NEA_MountainRoad) and pUnit ~= nil then
        
        local iMoveRemain=pUnit:GetMovementMovesRemaining();
		local iMaxMov=pUnit:GetMaxMoves();
		
		--pUnit:ChangeDamage(-iMaxMov)
		pUnit:ChangeExtraMoves(-iMaxMov+1);

		UnitManager.ChangeMovesRemaining(pUnit,-iMoveRemain + 1);

		--function()
				--Events.UnitMoved.Add(NeaMountainOutMovement);
			--end);
			--UnitManager.FinishMoves(pUnit)  -iExtraMov
			
--and imove ~= 0
			--pUnit:ChangeMovesRemaining(-22)
	elseif iExtraMov ~= 0 then

        --local imovei=pUnit:GetMovementMovesRemaining()
		local iMaxMov=pUnit:GetMaxMoves();
		
		--pUnit:ChangeDamage(-iExtraMov);
		pUnit:ChangeExtraMoves(-iExtraMov);

		UnitManager.ChangeMovesRemaining(pUnit, -iExtraMov);
			--UnitManager.FinishMoves(pUnit)
			
--and imove ~= 0
			--pUnit:ChangeMovesRemaining(-22)
    end

end


--Events.UnitSelectionChanged.Add(NeaMountainMovement)
--Events.UnitMovementPointsRestored.Add(NeaMountainMovement)

